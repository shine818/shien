"""
OKX API 客户端封装
提供统一的 API 调用接口，包含签名、代理、错误处理
"""
import json
import hmac
import hashlib
import base64
import os
import time
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
import requests
from risk_manager import rate_limiter


class OKXClient:
    """OKX REST API 客户端"""
    
    def __init__(self, config_path: str = "config.json"):
        self.config = self._load_config(config_path)
        self.api_key = self.config["api_key"]
        self.secret_key = self.config["secret_key"]
        self.passphrase = self.config["passphrase"]
        self.is_simulated = self.config.get("is_simulated", False)
        self.base_url = "https://www.okx.com"
        self.proxies = self.config.get("proxy", {
            'http': 'http://127.0.0.1:7897',
            'https': 'http://127.0.0.1:7897',
        })
        self._session_local = threading.local()
    
    def _load_config(self, path: str) -> dict:
        config_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(config_dir, path)
        with open(full_path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def _get_timestamp(self) -> str:
        now = datetime.now(timezone.utc)
        return now.strftime('%Y-%m-%dT%H:%M:%S.') + now.strftime('%f')[:3] + 'Z'
    
    def _sign(self, timestamp: str, method: str, request_path: str, body: str = "") -> str:
        message = timestamp + method + request_path + body
        mac = hmac.new(
            self.secret_key.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        )
        return base64.b64encode(mac.digest()).decode('utf-8')
    
    def _get_headers(self, method: str, request_path: str, body: str = "") -> dict:
        timestamp = self._get_timestamp()
        signature = self._sign(timestamp, method, request_path, body)
        headers = {
            "OK-ACCESS-KEY": self.api_key,
            "OK-ACCESS-SIGN": signature,
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": self.passphrase,
            "Content-Type": "application/json"
        }
        if self.is_simulated:
            headers["x-simulated-trading"] = "1"
        return headers
    
    def _create_session(self):
        session = requests.Session()
        session.proxies = self.proxies
        return session

    def _get_session(self):
        session = getattr(self._session_local, "session", None)
        if session is None:
            session = self._create_session()
            self._session_local.session = session
        return session

    def _rebuild_session(self):
        """重建当前线程的 HTTP Session (代理断线恢复)"""
        old_session = getattr(self._session_local, "session", None)
        if old_session is not None:
            try:
                old_session.close()
            except Exception:
                pass
        self._session_local.session = self._create_session()
        print("🔄 HTTP Session 已重建")

    def _request(self, method: str, path: str, params: dict = None, body: dict = None) -> dict:
        """发送 API 请求 (含自动重建 Session)"""
        url = self.base_url + path
        body_str = json.dumps(body) if body else ""
        
        if params:
            query = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
            if query:
                path = path + "?" + query
                url = self.base_url + path
        
        headers = self._get_headers(method, path, body_str)

        # API 限速保护
        rate_limiter.wait()
        
        for attempt in range(3):
            try:
                session = self._get_session()
                if method == "GET":
                    resp = session.get(url, headers=headers, timeout=15)
                elif method == "POST":
                    resp = session.post(url, headers=headers, data=body_str, timeout=15)
                else:
                    raise ValueError(f"Unsupported method: {method}")
                
                data = resp.json()
                if data.get("code") != "0":
                    print(f"❌ API错误 [{path}]: {data.get('code')} - {data.get('msg')}")
                return data
            except (OSError, requests.exceptions.ConnectionError,
                    requests.exceptions.ProxyError,
                    requests.exceptions.Timeout) as e:
                if attempt < 2:
                    print(f"⚠️ 网络异常 [{path}] (重试{attempt+1}/3): {e}")
                    self._rebuild_session()
                    headers = self._get_headers(method, path, body_str)
                    time.sleep(2)  # 等代理恢复
                    continue
                print(f"❌ 请求失败 [{path}]: {e}")
                return {"code": "-1", "msg": str(e), "data": []}
            except Exception as e:
                print(f"❌ 请求失败 [{path}]: {e}")
                return {"code": "-1", "msg": str(e), "data": []}
    
    # ==================== 账户相关 ====================
    
    def get_balance(self, ccy: str = None) -> dict:
        """获取账户余额"""
        params = {"ccy": ccy} if ccy else None
        return self._request("GET", "/api/v5/account/balance", params=params)
    
    def get_positions(self, inst_type: str = None, inst_id: str = None) -> dict:
        """获取持仓信息"""
        params = {}
        if inst_type:
            params["instType"] = inst_type
        if inst_id:
            params["instId"] = inst_id
        return self._request("GET", "/api/v5/account/positions", params=params or None)
    
    def get_account_config(self) -> dict:
        """获取账户配置"""
        return self._request("GET", "/api/v5/account/config")
    
    def set_leverage(self, inst_id: str, lever: str, mgn_mode: str = "cross") -> dict:
        """设置杠杆"""
        body = {
            "instId": inst_id,
            "lever": lever,
            "mgnMode": mgn_mode,
        }
        return self._request("POST", "/api/v5/account/set-leverage", body=body)
    
    # ==================== 行情相关 ====================
    
    def get_ticker(self, inst_id: str) -> dict:
        """获取单个产品行情"""
        return self._request("GET", "/api/v5/market/ticker", params={"instId": inst_id})
    
    def get_tickers(self, inst_type: str = "SPOT") -> dict:
        """获取所有产品行情"""
        return self._request("GET", "/api/v5/market/tickers", params={"instType": inst_type})
    
    def get_candles(self, inst_id: str, bar: str = "1H", limit: str = "100") -> dict:
        """获取K线数据
        bar: 1m/3m/5m/15m/30m/1H/2H/4H/6H/12H/1D/1W/1M
        """
        return self._request("GET", "/api/v5/market/candles", params={
            "instId": inst_id,
            "bar": bar,
            "limit": limit,
        })
    
    def get_mark_price(self, inst_id: str = None, inst_type: str = "SWAP") -> dict:
        """获取标记价格"""
        params = {"instType": inst_type}
        if inst_id:
            params["instId"] = inst_id
        return self._request("GET", "/api/v5/public/mark-price", params=params)
    
    # ==================== 交易相关 ====================
    
    def place_order(self, inst_id: str, td_mode: str, side: str, ord_type: str,
                    sz: str, px: str = None, pos_side: str = None,
                    reduce_only: bool = False, **kwargs) -> dict:
        """下单 (不含止盈止损, SL/TP 需用 place_stop_order 单独下)"""
        body = {
            "instId": inst_id,
            "tdMode": td_mode,
            "side": side,
            "ordType": ord_type,
            "sz": sz,
        }
        if px:
            body["px"] = px
        if pos_side:
            body["posSide"] = pos_side
        if reduce_only:
            body["reduceOnly"] = True
        
        return self._request("POST", "/api/v5/trade/order", body=body)

    def place_stop_order(self, inst_id: str, td_mode: str, side: str,
                         sz: str, sl_trigger_px: str = None, sl_ord_px: str = None,
                         tp_trigger_px: str = None, tp_ord_px: str = None) -> dict:
        """下止盈止损单 (algo order)
        side: 平仓方向 (buy=止盈止损空头, sell=止盈止损多头)
        sl_ord_px/tp_ord_px: -1 表示市价触发
        """
        body = {
            "instId": inst_id,
            "tdMode": td_mode,
            "side": side,
            "ordType": "conditional",
            "sz": sz,
        }
        if sl_trigger_px:
            body["slTriggerPx"] = sl_trigger_px
            body["slOrdPx"] = sl_ord_px or "-1"  # -1=市价
        if tp_trigger_px:
            body["tpTriggerPx"] = tp_trigger_px
            body["tpOrdPx"] = tp_ord_px or "-1"
        
        return self._request("POST", "/api/v5/trade/order-algo", body=body)
    
    def cancel_order(self, inst_id: str, ord_id: str = None, cl_ord_id: str = None) -> dict:
        """撤单"""
        body = {"instId": inst_id}
        if ord_id:
            body["ordId"] = ord_id
        if cl_ord_id:
            body["clOrdId"] = cl_ord_id
        return self._request("POST", "/api/v5/trade/cancel-order", body=body)
    
    def get_order(self, inst_id: str, ord_id: str = None, cl_ord_id: str = None) -> dict:
        """查询订单"""
        params = {"instId": inst_id}
        if ord_id:
            params["ordId"] = ord_id
        if cl_ord_id:
            params["clOrdId"] = cl_ord_id
        return self._request("GET", "/api/v5/trade/order", params=params)
    
    def get_pending_orders(self, inst_type: str = None, inst_id: str = None) -> dict:
        """获取未成交订单"""
        params = {}
        if inst_type:
            params["instType"] = inst_type
        if inst_id:
            params["instId"] = inst_id
        return self._request("GET", "/api/v5/trade/orders-pending", params=params or None)
    
    def cancel_all_orders(self, inst_id: str) -> list:
        """撤销指定产品的所有挂单"""
        result = self.get_pending_orders(inst_id=inst_id)
        cancelled = []
        if result.get("code") == "0" and result.get("data"):
            for order in result["data"]:
                resp = self.cancel_order(inst_id, ord_id=order["ordId"])
                cancelled.append(resp)
        return cancelled

    def cancel_algo_orders(self, inst_id: str) -> list:
        """撤销指定产品的所有止盈止损 algo 挂单 (conditional)"""
        cancelled = []
        try:
            result = self._request("GET", "/api/v5/trade/orders-algo-pending",
                                   params={"instId": inst_id, "ordType": "conditional"})
            if result.get("code") != "0" or not result.get("data"):
                return cancelled

            for algo in result["data"]:
                algo_id = algo.get("algoId")
                if not algo_id:
                    continue
                resp = self._request("POST", "/api/v5/trade/cancel-algos",
                                     body=[{"instId": inst_id, "algoId": algo_id}])
                if resp.get("code") == "0":
                    print(f"🧹 已取消 algo 委托 {algo_id}")
                else:
                    print(f"⚠️ 取消 algo 委托失败 {algo_id}: {resp.get('msg')}")
                cancelled.append(resp)
        except Exception as e:
            print(f"⚠️ 取消 algo 委托异常: {e}")
        return cancelled
    
    def close_position(self, inst_id: str, mgn_mode: str = "isolated",
                       pos_side: str = None) -> dict:
        """平仓"""
        body = {
            "instId": inst_id,
            "mgnMode": mgn_mode,
        }
        if pos_side:
            body["posSide"] = pos_side
        return self._request("POST", "/api/v5/trade/close-position", body=body)
    
    # ==================== 产品信息 ====================
    
    def get_instruments(self, inst_type: str = "SWAP", inst_id: str = None) -> dict:
        """获取产品信息"""
        params = {"instType": inst_type}
        if inst_id:
            params["instId"] = inst_id
        return self._request("GET", "/api/v5/public/instruments", params=params)
    
    # ==================== 工具方法 ====================
    
    def get_current_price(self, inst_id: str) -> Optional[float]:
        """获取当前价格（简便方法）"""
        result = self.get_ticker(inst_id)
        if result.get("code") == "0" and result.get("data"):
            return float(result["data"][0]["last"])
        return None
    
    def get_contract_val(self, inst_id: str) -> float:
        """获取合约面值"""
        result = self.get_instruments("SWAP", inst_id)
        if result.get("code") == "0" and result.get("data"):
            return float(result["data"][0].get("ctVal", "1"))
        return 1.0

    def get_usdt_balance(self) -> float:
        """获取账户总权益 (totalEq), 包含保证金+浮盈亏"""
        result = self.get_balance("USDT")
        if result.get("code") == "0" and result.get("data"):
            # 优先用 totalEq (账户总权益 = 可用 + 保证金 + 浮盈亏)
            total_eq = result["data"][0].get("totalEq", "")
            if total_eq:
                return float(total_eq)
            # 降级: 用 details 中的 eq (币种权益)
            details = result["data"][0].get("details", [])
            for d in details:
                if d["ccy"] == "USDT":
                    return float(d.get("eq", d.get("availBal", "0")))
        return -1.0
