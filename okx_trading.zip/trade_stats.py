"""
交易绩效分析引擎 v2.0
从 OKX API 成交记录 + 本地 CSV 综合分析，计算完整绩效指标

指标清单:
- 胜率 / 盈亏比 / 利润因子
- Sharpe Ratio (年化)
- 最大回撤 / 最大连胜连亏
- 日/周维度分析
- 持仓时间统计
- 手续费统计
"""
import csv
import os
import math
import json
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from collections import defaultdict

logger = logging.getLogger(__name__)


def load_csv_trades(csv_path: str = "trades.csv") -> List[Dict]:
    """从本地 CSV 加载交易记录"""
    if not os.path.exists(csv_path):
        return []
    trades = []
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            trades.append(row)
    return trades


def load_okx_fills(client, inst_type: str = "SWAP", limit: int = 100) -> List[Dict]:
    """从 OKX API 拉取真实成交记录"""
    try:
        result = client._request("GET", "/api/v5/trade/fills-history",
                                 params={"instType": inst_type, "limit": str(limit)})
        fills = []
        if result.get("code") == "0":
            for f in result.get("data", []):
                ts_ms = int(f.get("ts", "0"))
                fills.append({
                    "time": datetime.fromtimestamp(ts_ms / 1000).strftime("%Y-%m-%d %H:%M:%S") if ts_ms else "",
                    "date": datetime.fromtimestamp(ts_ms / 1000).strftime("%Y-%m-%d") if ts_ms else "",
                    "instId": f.get("instId", ""),
                    "side": f.get("side", ""),
                    "price": float(f.get("fillPx", "0")),
                    "size": float(f.get("fillSz", "0")),
                    "pnl": float(f.get("pnl", "0")),
                    "fee": float(f.get("fee", "0")),
                    "ordId": f.get("ordId", ""),
                })
        return fills
    except Exception as e:
        logger.warning(f"OKX fills 获取失败: {e}")
        return []


def calculate_stats(fills: List[Dict]) -> Dict:
    """计算完整绩效指标"""
    if not fills:
        return {"总交易数": 0, "提示": "暂无交易记录"}

    # 按有 PnL 的记录 (平仓交易) 筛选
    pnl_trades = [f for f in fills if f.get("pnl", 0) != 0]
    all_pnl = [f["pnl"] for f in pnl_trades]
    all_fees = [f.get("fee", 0) for f in fills]

    total_trades = len(fills)
    close_trades = len(pnl_trades)

    if not all_pnl:
        total_fee = sum(all_fees)
        return {
            "总交易数": total_trades,
            "平仓交易": 0,
            "总手续费": f"{total_fee:.4f} USDT",
            "提示": "暂无平仓记录"
        }

    # ─── 基础指标 ───
    wins = [p for p in all_pnl if p > 0]
    losses = [p for p in all_pnl if p < 0]
    win_count = len(wins)
    loss_count = len(losses)
    win_rate = win_count / len(all_pnl) * 100

    avg_win = sum(wins) / win_count if wins else 0
    avg_loss = sum(losses) / loss_count if losses else 0
    profit_factor = abs(sum(wins) / sum(losses)) if losses else float("inf")

    total_pnl = sum(all_pnl)
    total_fee = sum(all_fees)
    net_pnl = total_pnl + total_fee  # fee 是负数

    # ─── 最大连胜/连亏 ───
    max_win_streak = 0
    max_loss_streak = 0
    cur_win = 0
    cur_loss = 0
    for p in all_pnl:
        if p > 0:
            cur_win += 1
            cur_loss = 0
            max_win_streak = max(max_win_streak, cur_win)
        elif p < 0:
            cur_loss += 1
            cur_win = 0
            max_loss_streak = max(max_loss_streak, cur_loss)
        else:
            cur_win = 0
            cur_loss = 0

    # ─── 最大回撤 (基于累计 PnL) ───
    cumulative = []
    running = 0
    for p in all_pnl:
        running += p
        cumulative.append(running)

    peak = cumulative[0]
    max_drawdown = 0
    for val in cumulative:
        if val > peak:
            peak = val
        dd = peak - val
        if dd > max_drawdown:
            max_drawdown = dd

    # ─── Sharpe Ratio (年化, 基于日收益率) ───
    daily_pnl = defaultdict(float)
    for f in pnl_trades:
        date = f.get("date", "")
        if date:
            daily_pnl[date] += f["pnl"]

    daily_returns = list(daily_pnl.values())
    sharpe = 0.0
    if len(daily_returns) >= 2:
        mean_r = sum(daily_returns) / len(daily_returns)
        std_r = math.sqrt(sum((r - mean_r) ** 2 for r in daily_returns) / (len(daily_returns) - 1))
        if std_r > 0:
            sharpe = (mean_r / std_r) * math.sqrt(365)

    # ─── 日维度汇总 ───
    daily_summary = {}
    daily_counts = defaultdict(lambda: {"trades": 0, "wins": 0, "pnl": 0.0, "fee": 0.0})
    for f in fills:
        date = f.get("date", "")
        if not date:
            continue
        daily_counts[date]["trades"] += 1
        daily_counts[date]["fee"] += f.get("fee", 0)
        if f.get("pnl", 0) != 0:
            daily_counts[date]["pnl"] += f["pnl"]
            if f["pnl"] > 0:
                daily_counts[date]["wins"] += 1

    for date in sorted(daily_counts.keys())[-7:]:  # 最近 7 天
        d = daily_counts[date]
        daily_summary[date] = {
            "交易": d["trades"],
            "盈亏": f"{d['pnl']:+.4f}",
            "手续费": f"{d['fee']:.4f}",
            "净收益": f"{d['pnl'] + d['fee']:+.4f}",
        }

    # ─── 汇总 ───
    return {
        "总交易数": total_trades,
        "平仓交易": close_trades,
        "胜率": f"{win_rate:.1f}%",
        "盈利笔数": win_count,
        "亏损笔数": loss_count,
        "平均盈利": f"{avg_win:+.4f} USDT",
        "平均亏损": f"{avg_loss:+.4f} USDT",
        "盈亏比": f"{abs(avg_win / avg_loss):.2f}" if avg_loss != 0 else "∞",
        "利润因子": f"{profit_factor:.2f}" if profit_factor != float("inf") else "∞",
        "总盈亏": f"{total_pnl:+.4f} USDT",
        "总手续费": f"{total_fee:.4f} USDT",
        "净盈亏": f"{net_pnl:+.4f} USDT",
        "最大回撤": f"{max_drawdown:.4f} USDT",
        "最大连胜": max_win_streak,
        "最大连亏": max_loss_streak,
        "Sharpe": f"{sharpe:.2f}",
        "近7日": daily_summary,
    }


def calculate_daily_report(fills: List[Dict], balance: float = 0) -> Dict:
    """
    计算今日绩效 (UTC 日期)
    用于 Telegram 每日报告
    """
    today = datetime.utcnow().strftime("%Y-%m-%d")
    today_fills = [f for f in fills if f.get("date", "") == today]

    today_pnl = sum(f.get("pnl", 0) for f in today_fills)
    today_fee = sum(f.get("fee", 0) for f in today_fills)
    today_net = today_pnl + today_fee
    today_wins = sum(1 for f in today_fills if f.get("pnl", 0) > 0)
    today_losses = sum(1 for f in today_fills if f.get("pnl", 0) < 0)
    today_count = len(today_fills)

    # 全历史
    all_pnl = sum(f.get("pnl", 0) for f in fills)
    all_fee = sum(f.get("fee", 0) for f in fills)
    all_net = all_pnl + all_fee
    all_close = [f for f in fills if f.get("pnl", 0) != 0]
    all_wins = sum(1 for f in all_close if f["pnl"] > 0)
    all_win_rate = (all_wins / len(all_close) * 100) if all_close else 0

    return {
        "date": today,
        "today_trades": today_count,
        "today_pnl": round(today_pnl, 4),
        "today_fee": round(today_fee, 4),
        "today_net": round(today_net, 4),
        "today_wins": today_wins,
        "today_losses": today_losses,
        "today_win_rate": round(today_wins / (today_wins + today_losses) * 100, 1) if (today_wins + today_losses) > 0 else 0,
        "total_net": round(all_net, 4),
        "total_win_rate": round(all_win_rate, 1),
        "total_close_trades": len(all_close),
        "balance": round(balance, 2),
    }


def format_daily_report_text(report: Dict) -> str:
    """格式化每日报告为 Telegram HTML 消息"""
    pnl_emoji = "📈" if report["today_net"] >= 0 else "📉"
    lines = [
        f"📋 <b>每日报告</b> | {report['date']}",
        f"━━━━━━━━━━━━━━",
    ]

    if report["today_trades"] > 0:
        lines.extend([
            f"{pnl_emoji} 今日: <b>{report['today_net']:+.4f} USDT</b>",
            f"📊 {report['today_trades']}笔 | 胜率 {report['today_win_rate']:.0f}%",
            f"💸 手续费: {report['today_fee']:.4f}",
        ])
    else:
        lines.append("📊 今日无交易")

    lines.extend([
        f"━━━━━━━━━━━━━━",
        f"📈 累计净收益: <b>{report['total_net']:+.4f} USDT</b>",
        f"📊 总胜率: {report['total_win_rate']:.0f}% ({report['total_close_trades']}笔)",
    ])

    if report["balance"] > 0:
        lines.append(f"💰 余额: <b>${report['balance']:.2f}</b>")

    return "\n".join(lines)


def print_report(csv_path: str = "trades.csv", client=None):
    """打印完整交易报告"""
    # 优先用 OKX API 数据
    if client:
        fills = load_okx_fills(client)
        if fills:
            print("\n[数据源: OKX API 成交记录]")
        else:
            fills = _csv_to_fills(csv_path)
            print("\n[数据源: 本地 CSV]")
    else:
        fills = _csv_to_fills(csv_path)
        print("\n[数据源: 本地 CSV]")

    stats = calculate_stats(fills)

    print("=" * 50)
    print("  📊 交易绩效分析报告")
    print("=" * 50)

    for k, v in stats.items():
        if k == "近7日":
            print(f"\n  📅 近7日明细:")
            for date, detail in v.items():
                print(f"    {date}: {detail['交易']}笔 | PnL={detail['盈亏']} | 净={detail['净收益']}")
        else:
            print(f"  {k}: {v}")

    print("=" * 50)
    return stats


def _csv_to_fills(csv_path: str) -> List[Dict]:
    """将 CSV 交易记录转换为 fills 格式 (兼容旧数据)"""
    trades = load_csv_trades(csv_path)
    fills = []
    for t in trades:
        if t.get("status") != "success":
            continue
        time_str = t.get("time", "")
        date_str = time_str[:10] if len(time_str) >= 10 else ""
        try:
            pnl_pct = float(t.get("pnl_pct", "0"))
        except (ValueError, TypeError):
            pnl_pct = 0

        fills.append({
            "time": time_str,
            "date": date_str,
            "instId": t.get("inst_id", ""),
            "side": t.get("side", ""),
            "price": float(t.get("price", "0") or "0"),
            "size": float(t.get("size", "0") or "0"),
            "pnl": pnl_pct,  # CSV 中是 pnl_pct 百分比
            "fee": 0,
            "ordId": t.get("ord_id", ""),
        })
    return fills


# ─── 资金曲线记录 ───

EQUITY_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "equity_curve.csv")


def record_equity(balance: float, drawdown_pct: float = 0, daily_pnl_pct: float = 0):
    """记录权益到 CSV (由 main.py 每小时调用)"""
    try:
        write_header = not os.path.exists(EQUITY_CSV)
        with open(EQUITY_CSV, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if write_header:
                writer.writerow(["timestamp", "balance", "drawdown_pct", "daily_pnl_pct"])
            writer.writerow([
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                f"{balance:.4f}",
                f"{drawdown_pct:.2f}",
                f"{daily_pnl_pct:.2f}",
            ])
    except Exception as e:
        logger.warning(f"资金曲线记录失败: {e}")


if __name__ == "__main__":
    # 直接运行: 尝试连接 OKX API
    try:
        from okx_client import OKXClient
        client = OKXClient()
        print_report(client=client)
    except Exception:
        print_report()
