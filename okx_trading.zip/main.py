"""
OKX 自动交易系统主程序 v5.0 - 量化管线架构
集成: Kalman 滤波 + 状态机二次确认 + 动态 RR 引擎 + 组合 VaR 风控
v5.0: 全面升级为定量分析驱动，支持跨币种相关性压缩，提升横盘抗噪能力。
"""
import fix_encoding  # noqa: F401  — 修复 Windows 控制台 emoji 编码
import time
import threading
import argparse
import logging
import json
import os
from datetime import datetime, timezone
from okx_client import OKXClient
from risk_manager import RiskManager
from trader import Trader
from strategies.ma_cross import MACrossStrategy
from strategies.grid import GridStrategy
from strategies.signal_strategy import SignalStrategy
from strategies.funding_rate import FundingRateStrategy
from strategies.portfolio_risk import PortfolioRiskManager
from position_guard import PositionGuard
from logging.handlers import RotatingFileHandler

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        RotatingFileHandler("trading.log", maxBytes=5*1024*1024, backupCount=3, encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

from notifier import TelegramNotifier, TelegramCommandHandler
from ml_signal import MLSignalScorer
from market_sentiment import MarketSentiment
from ws_feed import OKXWebSocketFeed
from news_sentiment import NewsSentiment
from trade_stats import load_okx_fills, calculate_daily_report, format_daily_report_text, record_equity


# ─── ADX 策略切换 ───

def calc_adx_from_client(client, inst_id, bar="1H", period=14):
    """从API获取K线并计算ADX，用于判断当前行情类型"""
    try:
        result = client.get_candles(inst_id, bar=bar, limit="50")
        if result.get("code") != "0" or not result.get("data"):
            return 25.0
        # OKX K线返回 newest first，需要倒序为 oldest→newest
        highs = [float(c[2]) for c in result["data"]][::-1]
        lows = [float(c[3]) for c in result["data"]][::-1]
        closes = [float(c[4]) for c in result["data"]][::-1]
        if len(highs) < period * 2:
            return 25.0
        plus_dm, minus_dm, tr_list = [], [], []
        for i in range(1, len(highs)):
            up = highs[i] - highs[i - 1]
            down = lows[i - 1] - lows[i]
            plus_dm.append(up if up > down and up > 0 else 0)
            minus_dm.append(down if down > up and down > 0 else 0)
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
            tr_list.append(tr)
        atr_val = sum(tr_list[-period:]) / period
        if atr_val == 0:
            return 25.0
        plus_di = (sum(plus_dm[-period:]) / period) / atr_val * 100
        minus_di = (sum(minus_dm[-period:]) / period) / atr_val * 100
        return abs(plus_di - minus_di) / (plus_di + minus_di + 0.0001) * 100
    except Exception:
        return 25.0


def decide_strategy_mode(adx, config=None):
    """
    ADX 联动策略切换 (方案C):
    - ADX < deadzone: 死区 → 暂停所有 (无波动, 手续费>利润)
    - ADX deadzone-trend: 震荡 → 网格
    - ADX > trend: 趋势 → 暂停+通知
    """
    deadzone = 15
    trend = 25
    if config and "strategy" in config:
        deadzone = config["strategy"].get("adx_deadzone", 15)
        trend = config["strategy"].get("adx_trend", 25)

    if adx > trend:
        return "trend", f"📈强势趋势 ADX={adx:.0f} 策略运行"
    elif adx < deadzone:
        return "dead", f"💤低波动 ADX={adx:.0f} 暂停"
    else:
        return "range", f"📊震荡市 ADX={adx:.0f}"


# ─── 持仓同步 ───

def sync_position(client, strategy, notifier=None):
    try:
        result = client.get_positions(inst_id=strategy.inst_id)
        if result.get("code") == "0" and result.get("data"):
            for pos in result["data"]:
                pos_amt = float(pos.get("pos", "0"))
                avg_px = float(pos.get("avgPx", "0"))
                if pos_amt > 0:
                    strategy.current_position = "long"
                    strategy.entry_price = avg_px
                    strategy.highest_since_entry = avg_px
                    logger.info(f"🔄 同步 {strategy.inst_id}: 多头 @ {avg_px}")
                elif pos_amt < 0:
                    strategy.current_position = "short"
                    strategy.entry_price = avg_px
                    strategy.lowest_since_entry = avg_px
                    logger.info(f"🔄 同步 {strategy.inst_id}: 空头 @ {avg_px}")
                else:
                    strategy.current_position = None
        else:
            logger.info(f"🔄 {strategy.inst_id}: 无持仓")
    except Exception as e:
        logger.warning(f"⚠️ 同步 {strategy.inst_id} 失败: {e}")


# ─── 策略参数热重载 ───

def check_config_reload(all_strategies, last_applied_cache, notifier=None):
    """
    检查 config.json 中的 strategy.last_applied 时间戳,
    如果发现变化则热更新所有 MACrossStrategy 的参数, 无需重启。
    返回更新后的 last_applied 时间戳。
    """
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    try:
        current_mtime = os.path.getmtime(config_path)
        if getattr(check_config_reload, "_last_mtime", None) == current_mtime:
            return last_applied_cache
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        check_config_reload._last_mtime = current_mtime
    except Exception:
        return last_applied_cache

    strategy_cfg = config.get("strategy", {})
    current_applied = strategy_cfg.get("last_applied", "")

    # 没变化, 跳过
    if current_applied == last_applied_cache:
        return last_applied_cache

    # 有变化 → 热更新参数
    fast = strategy_cfg.get("fast_period")
    slow = strategy_cfg.get("slow_period")
    atr_sl = strategy_cfg.get("atr_sl")
    atr_tp = strategy_cfg.get("atr_tp")

    updated_count = 0
    for inst_id, strats in all_strategies.items():
        for stype, strat in strats:
            if stype == "ma":
                if fast is not None:
                    strat.fast_period = int(fast)
                if slow is not None:
                    strat.slow_period = int(slow)
                if atr_sl is not None:
                    strat.atr_sl_mult = float(atr_sl)
                if atr_tp is not None:
                    strat.atr_tp_mult = float(atr_tp)
                updated_count += 1

    logger.info(f"🔄 策略参数热重载成功! fast={fast} slow={slow} "
                f"SL={atr_sl}×ATR TP={atr_tp}×ATR → 已更新 {updated_count} 个策略")

    if notifier:
        try:
            notifier.send_text(
                f"🔄 策略参数已热重载\n"
                f"快线: {fast} | 慢线: {slow}\n"
                f"止损: {atr_sl}×ATR | 止盈: {atr_tp}×ATR\n"
                f"已更新 {updated_count} 个策略, 无需重启"
            )
        except Exception:
            pass

    return current_applied


# ─── 多币种策略工厂 ───

def create_strategies_for_instrument(inst_id, ml_scorer, risk_manager, notifier, sentiment, strategy_mode, user_bias=None, trader=None, threshold=55.0):
    """为单个币种创建策略组"""
    strategies = []
    
    if strategy_mode in ("ma", "both"):
        ma = MACrossStrategy(
            inst_id=inst_id,
            bar="1H",
            ml_scorer=ml_scorer,
            risk_manager=risk_manager,
            sentiment=sentiment
        )
        ma.notifier = notifier
        ma.start()
        strategies.append(("ma", ma))
    
    if strategy_mode in ("grid", "both"):
        # 精准信号策略 (替代旧网格)
        sig = SignalStrategy(
            inst_id=inst_id,
            leverage=10,         # 10x 杠杆
            position_pct=0.10,     # 10% 资金仓位
            sl_pct=0.02,         # 2% 止损
            tp_pct=0.04,          # 4% 默认止盈 (动态调整)
            cooldown_hours=0.0,   # 冷却时间（0=关闭）
            daily_loss_limit=10.0, # 10U日限额 (以实际平仓为准)
            sentiment=sentiment,
            risk_manager=risk_manager,
            user_bias=user_bias,
            notifier=notifier,
            trader=trader,
            threshold=threshold
        )
        sig.start()
        strategies.append(("signal", sig))
    
    funding = FundingRateStrategy(inst_id=inst_id)
    ma_strat = next((s for t, s in strategies if t == "ma"), None)
    if ma_strat:
        funding.set_ma_strategy(ma_strat)
    funding.start()
    strategies.append(("funding", funding))
    
    return strategies


def main():
    parser = argparse.ArgumentParser(description="OKX 自动交易系统 v3.1")
    parser.add_argument("--strategy", type=str, default="both",
                        choices=["ma", "grid", "both"],
                        help="选择策略: ma, grid, both")
    parser.add_argument("--backtest", action="store_true", help="回测模式")
    parser.add_argument("--search", action="store_true", help="参数搜索")
    parser.add_argument("--no-adx-switch", action="store_true", help="禁用ADX自动切换")
    parser.add_argument("--no-ws", action="store_true", help="禁用WebSocket(回退到轮询模式)")
    args = parser.parse_args()

    if args.backtest:
        from backtest import run_backtest
        client = OKXClient()
        run_backtest(client)
        return

    if args.search:
        from backtest import grid_search
        client = OKXClient()
        grid_search(client)
        return

    logger.info("🚀 OKX 自动交易系统 v3.0 启动中...")
    logger.info("   ✨ 新增: 多币种 | ADX联动 | 限价单 | 金字塔加仓 | 时间过滤")

    retry_count = 0
    while True:
        try:
            # 1. 初始化
            client = OKXClient()
            config = client.config

            # 通知器 (Telegram, 无配置则 notifier=None 静默运行)
            tg_cfg = config.get("telegram", {})
            telegram = TelegramNotifier(
                bot_token=tg_cfg.get("bot_token"),
                chat_id=tg_cfg.get("chat_id"),
                proxy=config.get("proxy")
            )
            notifier = telegram if (telegram.bot_token and telegram.chat_id) else None
            if notifier:
                logger.info("📨 使用 Telegram 通知")
            else:
                logger.info("📨 通知已关闭 (无 Telegram 配置)")

            # ML
            ml_scorer = MLSignalScorer()

            # 风控
            risk_cfg = config.get("risk", {})
            risk_manager = RiskManager(
                max_drawdown=risk_cfg.get("max_drawdown", 0.15),
                daily_loss_limit=risk_cfg.get("daily_loss_limit", 0.10),
                max_consecutive_losses=risk_cfg.get("max_consecutive_losses", 3),
                cooldown_seconds=risk_cfg.get("cooldown_seconds", 3600),
                notifier=notifier,
                max_positions=risk_cfg.get("max_positions", 2),
                equity_stop_drawdown=risk_cfg.get("equity_stop_drawdown", 0.15)
            )
            
            # 组合风控管理器
            portfolio_risk = PortfolioRiskManager(
                max_portfolio_risk_pct=risk_cfg.get("max_portfolio_risk_pct", 0.06),
                corr_window=risk_cfg.get("corr_window", 60),
                corr_high_threshold=risk_cfg.get("corr_high_threshold", 0.75)
            )
            logger.info(f"🛡️ 组合风控: 已启用 (VaR<={risk_cfg.get('max_portfolio_risk_pct', 0.06)*100:.0f}%, 相关性阈值={risk_cfg.get('corr_high_threshold', 0.75)})")

            # 市场情绪分析器
            sentiment = MarketSentiment(client, cache_seconds=300)

            # 📰 新闻情绪分析器 (含 BlockBeats 快讯)
            bb_key = config.get("blockbeats", {}).get("api_key", "")
            news = NewsSentiment(proxy=config.get("proxy"), cache_seconds=900,
                                blockbeats_api_key=bb_key)
            sentiment.set_news_analyzer(news)
            logger.info(f"📡 市场情绪分析器: 已启用 (BlockBeats: {'✅' if bb_key else '❌'})")

            balance = client.get_usdt_balance()

            # 多币种
            instruments = config.get("instruments", ["DOGE-USDT-SWAP"])
            logger.info(f"📋 交易品种: {instruments}")

            # 🛡️ 持仓安全守卫
            ignore_pos = config.get("ignore_positions", [])
            dry_run = config.get("dry_run", False)
            guard = PositionGuard(client, notifier=notifier,
                                  max_consecutive_failures=10,
                                  naked_check_interval=300,
                                  ignore_instruments=ignore_pos,
                                  dry_run=dry_run)
            orphans = guard.scan_on_startup(instruments)
            if orphans:
                logger.warning(f"⚠️ 发现 {len(orphans)} 个孤儿仓位, 请手动处理!")

            # Trader v2.1 (限价单 + 金字塔 + 时间过滤 + 安全守卫 + dry-run)
            dry_bal = config.get("dry_run_initial_balance", 134.0)
            if dry_run:
                # 🧪 Dry-run 模式下，报告和初识资金统一为虚拟资金
                balance = dry_bal
                logger.info(f"🧪 DRY-RUN 模式: 固定虚拟资金 {balance} USDT")
            
            trader = Trader(client, risk_manager, notifier=notifier, guard=guard,
                            use_limit=True, pyramid_enabled=True, time_filter=True,
                            dry_run=dry_run, dry_run_balance=dry_bal)
            if dry_run:
                balance = trader._virtual_balance

            if notifier:
                notifier.trader = trader
                notifier.client = client

            if notifier:
                try:
                    notifier.send_startup(
                        strategy=args.strategy,
                        balance=balance,
                        inst_id=", ".join(instruments)
                    )
                except Exception as e:
                    logger.error(f"启动通知失败: {e}")

            # 2. 为每个币种创建策略
            all_strategies = {}  # {inst_id: [("type", strategy), ...]}
            user_bias_cfg = config.get("user_bias", {})
            strategy_cfg = config.get("strategy", {})
            threshold = strategy_cfg.get("threshold", 55.0)
            
            for inst in instruments:
                bias = user_bias_cfg.get(inst)
                if bias:
                    logger.info(f"📋 {inst} 用户偏好: {bias}")
                strats = create_strategies_for_instrument(
                    inst, ml_scorer, risk_manager, notifier, sentiment, args.strategy,
                    user_bias=bias, trader=trader, threshold=threshold
                )
                all_strategies[inst] = strats
                logger.info(f"✅ {inst}: 加载了 {len(strats)} 个策略")
                # 🧪 Dry-run: 传递标志给信号策略
                if dry_run:
                    for stype, strat in strats:
                        if stype == "signal":
                            strat.dry_run = True

            # 3. 初始化杠杆 (不撤单, 保留上次的 SL/TP)
            logger.info("🧹 初始化杠杆...")
            for inst in instruments:
                try:
                    client.set_leverage(inst, "10")
                except Exception as e:
                    logger.warning(f"⚠️ {inst} 初始化问题: {e}")

            # 📱 Telegram 命令监听
            tg_cmd = TelegramCommandHandler(
                notifier=notifier, client=client,
                risk_manager=risk_manager, all_strategies=all_strategies,
                sentiment=sentiment, trader=trader
            )
            if notifier:
                tg_cmd.start()

            # 4. 主循环
            logger.info("-" * 50)
            logger.info(f"✅ v3.0 运行中 | {len(instruments)} 币种 | 策略: {args.strategy}"
                        f"{' | 🧪 DRY-RUN 模拟模式' if dry_run else ''}")
            adx_switch_enabled = not args.no_adx_switch
            if adx_switch_enabled:
                logger.info("🔀 ADX 策略联动: 已启用")
            logger.info("🔄 策略参数热重载: 已启用 (修改 config.json 自动生效)")

            error_count = 0
            cycle_count = 0
            last_report_time = time.time()
            last_adx_check = 0
            report_interval = 3600
            adx_check_interval = 900

            # 💓 心跳通知 (每小时, 有交易后停止)
            last_heartbeat_time = 0  # 立即发送第一次
            heartbeat_interval = 3600  # 1小时
            trade_triggered = False  # 有交易触发后设为 True, 停止心跳
            last_signal_info = ""  # 最近的策略分析结果
            current_strategy_mode = args.strategy  # 当前策略模式
            last_status_log_time = 0  # 定期状态日志 (每10分钟)
            last_equity_record_time = 0  # 资金曲线记录 (每小时)
            last_daily_report_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")  # 每日报告 (每天 UTC 0:00)

            # 读取初始 last_applied 时间戳 (用于检测变化)
            _last_applied = ""
            try:
                _cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
                with open(_cfg_path, "r", encoding="utf-8") as _f:
                    _last_applied = json.load(_f).get("strategy", {}).get("last_applied", "")
                check_config_reload._last_mtime = os.path.getmtime(_cfg_path)
            except Exception:
                pass

            # ─── WebSocket 实时行情 ───
            ws_signal_received = threading.Event()  # K线收盘信号

            def _candle_close_worker(inst_id, candle_data):
                """K线收盘处理 (独立线程, 不阻塞 WS)"""
                nonlocal trade_triggered, last_signal_info
                try:
                    if dry_run:
                        pass  # 🧪 Dry-run: 跳过风控
                    else:
                        current_bal = client.get_usdt_balance()
                        if not risk_manager.is_risk_ok(current_bal):
                            logger.warning(f"⚠️ 风控拦截 {inst_id} (仍检查持仓)")
                            # 风控下仍执行持仓检查 (教训#34: 不能阻断平仓)
                            if inst_id in all_strategies:
                                for stype, strat in all_strategies[inst_id]:
                                    if stype == "signal" and hasattr(strat, '_check_position_exit') and strat.has_position:
                                        try:
                                            exit_action = strat._check_position_exit(client)
                                            if exit_action:
                                                trader.execute_actions([exit_action], strategies=all_strategies)
                                        except Exception:
                                            pass
                            return

                    if inst_id not in all_strategies:
                        return

                    for stype, strat in all_strategies[inst_id]:
                        if not strat.is_running:
                            continue
                        try:
                            actions = strat.analyze(client)
                            if actions:
                                logger.info(f"💡 WS 触发 {len(actions)} 个交易信号 | {inst_id}/{stype}")
                                is_grid = (stype == "grid")
                                trader.execute_actions(actions,
                                    skip_pyramid=is_grid,
                                    skip_limit_timeout=is_grid,
                                    strategies=all_strategies)
                                trade_triggered = True  # 💓 有交易 → 停止心跳
                            else:
                                last_signal_info = f"{inst_id}/{stype} 无信号 C={candle_data['close']}"
                        except Exception as e:
                            logger.error(f"⚠️ WS 策略异常 {inst_id}/{stype}: {e}")
                except Exception as e:
                    logger.error(f"❌ WS 回调异常: {e}")
                ws_signal_received.set()

            def on_candle_close(inst_id, candle_data):
                """实时回调: K线收盘 → 独立线程处理 (不阻塞 WS)"""
                logger.info(f"\n🔔 WS K线收盘 | {inst_id} | C={candle_data['close']}")
                t = threading.Thread(
                    target=_candle_close_worker,
                    args=(inst_id, candle_data),
                    daemon=True
                )
                t.start()

            def on_price_update(inst_id, price, ts):
                """实时回调: 价格更新 → 检查追踪止盈 + Dry-run SL/TP"""
                if inst_id not in all_strategies:
                    return
                # 同步更新风控价格一次即可，避免同一 tick 随策略数重复写入
                risk_manager.update_price(inst_id, price)

                # 🧪 Dry-run SL/TP 模拟检查
                if trader.dry_run:
                    trader.check_virtual_sl_tp(inst_id, price, all_strategies)

                for stype, strat in all_strategies[inst_id]:
                    if stype == "ma" and strat.is_running and strat.current_position:
                        try:
                            atr = strat.current_atr
                            if atr and atr > 0:
                                trail_action = strat._check_trailing_stop(price, atr)
                                if trail_action:
                                    logger.info(f"🚨 WS 追踪止盈触发 | {inst_id} @ {price}")
                                    trader.execute_actions([trail_action])
                        except Exception as e:
                            logger.error(f"追踪止盈异常: {e}")


            ws_feed = None
            if not args.no_ws:
                try:
                    proxy_cfg = client.proxies if hasattr(client, 'proxies') else None
                    ws_feed = OKXWebSocketFeed(
                        instruments=instruments,
                        on_candle_close=on_candle_close,
                        on_price_update=on_price_update,
                        proxy=proxy_cfg,
                        bar="1H",
                        price_throttle=5.0
                    )
                    ws_feed.start()
                    logger.info("📡 WebSocket 实时行情: 已启用")
                except Exception as e:
                    logger.warning(f"⚠️ WebSocket 启动失败, 回退轮询模式: {e}")
                    ws_feed = None
            else:
                logger.info("📡 WebSocket: 已禁用 (轮询模式)")

            _proxy_fail_count = 0  # 代理连续失败计数

            while True:
                try:
                    # 风控 (代理断线保护: 余额获取失败时跳过本轮)
                    if dry_run:
                        # 🧪 Dry-run: 用虚拟余额，跳过真实风控
                        current_bal = trader._virtual_balance
                    else:
                        current_bal = client.get_usdt_balance()
                    if current_bal < 0:
                        _proxy_fail_count += 1
                        if _proxy_fail_count <= 3:
                            logger.warning(f"⚠️ 余额获取失败 (代理断线? 第{_proxy_fail_count}次), 跳过本轮")
                        elif _proxy_fail_count % 10 == 0:
                            logger.warning(f"⚠️ 代理持续断线 (第{_proxy_fail_count}次), 等待恢复...")
                            try:
                                client._rebuild_session()
                            except Exception:
                                pass
                        time.sleep(30)
                        continue
                    else:
                        if _proxy_fail_count > 0:
                            logger.info(f"✅ 代理恢复! (断线 {_proxy_fail_count} 次后)")
                            _proxy_fail_count = 0

                    if dry_run:
                        risk_blocked = False  # 🧪 Dry-run: 不阻止交易
                    else:
                        risk_blocked = not risk_manager.is_risk_ok(current_bal)
                    if risk_blocked:
                        logger.warning("⚠️ 风控拦截 (仅阻止新开仓, 持仓检查继续)")
                        # 风控触发时: 仍然执行持仓平仓检查 (情绪反转/移动止盈)
                        for inst in instruments:
                            for stype, strat in all_strategies[inst]:
                                if stype == "signal" and hasattr(strat, '_check_position_exit') and strat.has_position:
                                    try:
                                        exit_action = strat._check_position_exit(client)
                                        if exit_action:
                                            logger.info(f"🛡️ 风控下仍执行平仓: {exit_action.reason}")
                                            trader.execute_actions([exit_action], strategies=all_strategies)
                                    except Exception as e:
                                        logger.warning(f"⚠️ 风控下持仓检查异常: {e}")
                        # 检测交所端止损止盈
                        try:
                            trader.check_algo_fills(instruments, all_strategies)
                        except Exception:
                            pass
                        time.sleep(60)
                        continue

                    # 📱 Telegram 暂停检查
                    if tg_cmd.is_paused:
                        time.sleep(30)
                        continue

                    # 🛡️ 持仓安全检查
                    if not guard.is_trading_allowed():
                        logger.warning(f"🛑 交易暂停中 (原因: {guard.pause_reason})")
                        time.sleep(60)
                        continue
                    guard.check_naked_positions(instruments)

                    # 📰 黑天鹅检测
                    should_pause, pause_reason = news.should_pause_trading()
                    if should_pause:
                        logger.warning(f"🚨 黑天鹅暂停: {pause_reason}")
                        if notifier:
                            notifier.send_risk_alert("🚨 黑天鹅检测", pause_reason)
                        time.sleep(300)  # 暂停 5 分钟
                        continue

                    now = time.time()

                    # ADX 策略联动 (仅网格模式: 趋势→暂停+通知)
                    if adx_switch_enabled and (now - last_adx_check >= adx_check_interval):
                        for inst in instruments:
                            adx = calc_adx_from_client(client, inst)
                            mode, label = decide_strategy_mode(adx, config=config)
                            current_strategy_mode = f"{mode} ({label})"
                            logger.info(f"📊 {inst} {label}")

                            for stype, strat in all_strategies[inst]:
                                if stype == "signal":
                                    if mode == "dead":
                                        logger.info(f"💤 {inst} ADX={adx:.0f} 无波动，信号策略暂停")
                                        strat.is_running = False
                                    else:
                                        if mode == "trend":
                                            logger.info(f"📈 {inst} ADX={adx:.0f} 趋势中，信号策略正常运行")
                                        else:
                                            logger.info(f"📊 {inst} ADX={adx:.0f} 震荡，信号策略正常运行")
                                        strat.is_running = True
                                elif stype == "grid":
                                    # 兼容旧网格（如果还在）
                                    strat.is_running = (mode == "range")
                                elif stype == "funding":
                                    strat.is_running = True
                                else:
                                    strat.is_running = False

                        last_adx_check = now

                    # 运行所有活跃策略 (轮询模式 / WS 断线回退)
                    ws_healthy = ws_feed and ws_feed.is_healthy(timeout=120) if ws_feed else False
                    
                    # WS 不健康时强制重连
                    if ws_feed and not ws_healthy and ws_feed.is_connected:
                        logger.warning("⚠️ WebSocket 不健康 (超过 120s 无消息), 强制重连...")
                        ws_feed.force_reconnect()
                    
                    if not ws_healthy:
                        # WS 未连接/不健康 → 轮询模式 (ALL 策略)
                        for inst in instruments:
                            # 更新组合风控价格数据
                            try:
                                ticker = client.get_ticker(inst)
                                if ticker and ticker.get("data"):
                                    price = float(ticker["data"][0]["last"])
                                    portfolio_risk.update_price(inst, price)
                            except Exception:
                                pass
                            for stype, strat in all_strategies[inst]:
                                if not strat.is_running:
                                    continue
                                try:
                                    actions = strat.analyze(client)
                                    if actions:
                                        # 组合风控：检查相关性并调整仓位
                                        if portfolio_risk and strat.has_position == False:
                                            # 获取当前余额
                                            current_bal = trader._virtual_balance if dry_run else client.get_usdt_balance()
                                            scale_info = portfolio_risk.get_position_scale_factor(inst, 1, current_bal)
                                            if scale_info["scale"] < 1.0:
                                                logger.warning(f"🛡️ 组合风控: 相关性压缩仓位至 {scale_info['scale']*100:.0f}% ({scale_info['reason']})")
                                                # 调整仓位
                                                for action in actions:
                                                    if hasattr(action, 'size'):
                                                        action.size = int(action.size * scale_info['scale'])
                                        
                                        # 网格策略: 跳过金字塔+限价超时 (grid 挂单应留在订单簿)
                                        is_grid = (stype == "grid")
                                        trader.execute_actions(actions,
                                            skip_pyramid=is_grid,
                                            skip_limit_timeout=is_grid,
                                            strategies=all_strategies)
                                        trade_triggered = True  # 💓 有交易 → 停止心跳
                                    else:
                                        last_signal_info = f"{inst}/{stype} 无信号"
                                except Exception as e:
                                    logger.error(f"⚠️ {inst}/{stype} 出错: {e}")
                    else:
                        # WS 已连接 → K线收盘会自动触发, 这里只跑网格策略(网格还是需要定期检查)
                        for inst in instruments:
                            for stype, strat in all_strategies[inst]:
                                if stype == "grid" and strat.is_running:
                                    try:
                                        actions = strat.analyze(client)
                                        if actions:
                                            # 网格策略: 跳过金字塔+限价超时
                                            trader.execute_actions(actions,
                                                skip_pyramid=True,
                                                skip_limit_timeout=True,
                                                strategies=all_strategies)
                                            trade_triggered = True
                                    except Exception as e:
                                        logger.error(f"⚠️ {inst}/grid 出错: {e}")

                    if dry_run:
                        # 本轮策略可能已经触发模拟平仓，状态展示前刷新已实现余额。
                        current_bal = trader._virtual_balance

                    # 📝 定期状态日志 (每10分钟, 保持日志文件活跃)
                    if now - last_status_log_time >= 600:
                        ws_status_str = "WS健康" if ws_healthy else ("轮询模式" if not ws_feed else "WS断线/重连中")
                        balance_text = f"余额={current_bal:.2f}U"
                        if dry_run:
                            try:
                                virtual_upl, _ = trader.calculate_virtual_upl()
                                balance_text = (
                                    f"余额={current_bal:.2f}U | "
                                    f"浮盈={virtual_upl:+.2f}U | "
                                    f"净值={current_bal + virtual_upl:.2f}U"
                                )
                            except Exception:
                                pass
                        logger.info(f"📊 循环#{cycle_count} | {ws_status_str} | "
                                    f"{balance_text} | 策略={current_strategy_mode}")
                        last_status_log_time = now

                    error_count = 0
                    retry_count = 0
                    cycle_count += 1

                    # 🚨 检测交所端止损止盈触发 (每个循环)
                    try:
                        trader.check_algo_fills(instruments, all_strategies)
                    except Exception as e:
                        logger.warning(f"⚠️ 止损止盈检测异常: {e}")

                    # 策略参数热重载检查 (每个循环检查一次)
                    _last_applied = check_config_reload(all_strategies, _last_applied, notifier)

                    # 💓 每小时心跳通知 (有交易后停止)
                    if notifier and not trade_triggered and (now - last_heartbeat_time >= heartbeat_interval):
                        try:
                            # 收集当前状态
                            hb_position = "空仓"
                            if trader.dry_run:
                                # 模拟盘: 从 trader 获取虚拟持仓
                                v_pos = trader._virtual_position
                                if v_pos:
                                    pos_parts = []
                                    for p_inst, p_info in v_pos.items():
                                        p_side = "多" if p_info["side"] == "long" else "空"
                                        pos_parts.append(f"{p_inst} {p_side}×{p_info['size']:.0f}")
                                    hb_position = " | ".join(pos_parts)
                            else:
                                # 实盘: 正常查询 API
                                try:
                                    pos_result = client.get_positions()
                                    if pos_result.get("code") == "0" and pos_result.get("data"):
                                        pos_parts = []
                                        for p in pos_result["data"]:
                                            p_amt = float(p.get("pos", "0"))
                                            if p_amt == 0:
                                                continue
                                            p_inst = p.get("instId", "?")
                                            p_dir = "多" if p_amt > 0 else "空"
                                            p_upl = float(p.get("upl", "0"))
                                            pos_parts.append(f"{p_inst} {p_dir}×{abs(p_amt):.0f} ({p_upl:+.2f}U)")
                                        if pos_parts:
                                            hb_position = " | ".join(pos_parts)
                                except Exception:
                                    pass

                            ws_status = ws_feed.get_status() if ws_feed else {"connected": False}
                            notifier.send_heartbeat(
                                balance=current_bal,
                                position=hb_position,
                                strategy_mode=current_strategy_mode,
                                ws_status=ws_status,
                                last_signal=last_signal_info,
                                cycle_count=cycle_count
                            )
                            last_heartbeat_time = now
                            logger.info("💓 心跳通知已发送")
                        except Exception as e:
                            logger.error(f"心跳通知失败: {e}")

                    # 状态报告
                    if now - last_report_time >= report_interval and notifier:
                        try:
                            dd = risk_manager.current_drawdown * 100
                            ma_st = {}
                            grid_st = None
                            for inst in instruments:
                                for stype, strat in all_strategies[inst]:
                                    if stype == "ma":
                                        ma_st = strat.get_status()
                                    elif stype == "grid":
                                        grid_st = strat.get_status()

                            report = trader.get_summary()
                            ws_status = ws_feed.get_status() if ws_feed else {"connected": False}
                            notifier.send_status_report(
                                balance=current_bal,
                                drawdown=dd,
                                ma_status=ma_st,
                                grid_status=grid_st,
                                trade_count=len(trader.trade_history)
                            )
                            last_report_time = now
                        except Exception as e:
                            logger.error(f"报告失败: {e}")

                    # 📈 资金曲线记录 (每小时)
                    if now - last_equity_record_time >= 3600:
                        try:
                            dd = risk_manager.current_drawdown * 100
                            record_equity(current_bal, drawdown_pct=dd)
                            last_equity_record_time = now
                        except Exception as e:
                            logger.error(f"资金曲线记录失败: {e}")

                    # 📋 每日绩效报告 (UTC 日切时发送)
                    # datetime/timezone 已在文件顶部导入
                    utc_today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                    if notifier and last_daily_report_date and utc_today != last_daily_report_date:
                        try:
                            fills = load_okx_fills(client)
                            if fills:
                                daily_rpt = calculate_daily_report(fills, balance=current_bal)
                                rpt_text = format_daily_report_text(daily_rpt)
                                notifier.send_daily_report(rpt_text)
                                logger.info("📋 每日报告已发送")
                        except Exception as e:
                            logger.error(f"每日报告失败: {e}")
                    last_daily_report_date = utc_today

                    time.sleep(60)

                except Exception as e:
                    error_count += 1
                    logger.error(f"⚠️ 循环异常 (第 {error_count} 次): {e}")
                    if error_count >= 5:
                        logger.error("🚨 连续错误过多，重新初始化...")
                        break
                    time.sleep(10)

        except KeyboardInterrupt:
            logger.info("\n👋 用户停止系统")
            if notifier:
                try:
                    notifier.send_shutdown("用户停止")
                except Exception:
                    pass
            break
        except Exception as e:
            retry_count += 1
            wait = min(60, 5 * retry_count)
            logger.error(f"❌ 核心崩溃 (第 {retry_count} 次): {e}")
            if notifier:
                try:
                    notifier.send_recovery(retry_count, str(e))
                except Exception:
                    pass
            logger.info(f"🔄 {wait}秒后自我修复...")
            time.sleep(wait)


if __name__ == "__main__":
    main()
