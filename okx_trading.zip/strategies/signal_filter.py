import numpy as np
from collections import deque

class KalmanScoreFilter:
    """
    用卡尔曼滤波器平滑综合评分，消除短期噪声抖动。
    相比简单移动均线，卡尔曼滤波延迟更低，对真实趋势更敏感。
    """
    def __init__(self, process_variance=1e-4, measurement_variance=0.05):
        self.Q = process_variance      # 状态噪声（越小越平滑）
        self.R = measurement_variance  # 观测噪声（越大越信任历史）
        self.x = None  # 状态估计
        self.P = 1.0   # 误差协方差

    def update(self, raw_score: float) -> float:
        if self.x is None:
            self.x = raw_score
            return raw_score
        
        # 预测步
        P_pred = self.P + self.Q
        
        # 更新步
        K = P_pred / (P_pred + self.R)   # 卡尔曼增益
        self.x = self.x + K * (raw_score - self.x)
        self.P = (1 - K) * P_pred
        
        return self.x

    def get_noise_level(self) -> float:
        """返回当前估计噪声水平，用于动态调整入场阈值"""
        return np.sqrt(self.P)

class AdaptiveThresholdGate:
    """
    根据近期波动率动态上调入场阈值。
    低波动 → 阈值升高（更严格）；高波动 → 阈值回归正常。
    """
    def __init__(self, base_threshold=60, window=48):
        self.base_threshold = base_threshold
        self.atr_history = deque(maxlen=window)  # 存近 48 个周期的 ATR

    def update_atr(self, atr: float, price: float):
        if price <= 0: return
        atr_pct = atr / price  # 归一化为价格百分比
        self.atr_history.append(atr_pct)

    def get_entry_threshold(self) -> float:
        if len(self.atr_history) < 10:
            return self.base_threshold
        
        current_atr_pct = self.atr_history[-1]
        avg_atr_pct = np.mean(self.atr_history)
        
        # 波动率比率：< 0.6 视为极低波动
        vol_ratio = current_atr_pct / avg_atr_pct if avg_atr_pct > 0 else 1.0
        
        if vol_ratio < 0.6:
            # 极低波动：阈值上调 8-12 分，严格过滤
            extra = 12 * (1 - vol_ratio / 0.6)
            return min(self.base_threshold + extra, 78)
        elif vol_ratio > 1.4:
            # 高波动：略微放宽阈值（趋势行情信号可能更明显）
            return max(self.base_threshold - 3, 55)
        else:
            return self.base_threshold

    def is_low_volatility_env(self) -> bool:
        if len(self.atr_history) < 10:
            return False
        avg_atr = np.mean(self.atr_history)
        if avg_atr == 0: return False
        return (self.atr_history[-1] / avg_atr) < 0.6
