import numpy as np
from dataclasses import dataclass

@dataclass
class MarketRegime:
    adx: float
    atr_pct: float       # ATR / price
    bb_width: float      # 布林带宽度 / price
    trend_direction: int  # +1 long, -1 short, 0 none

class DynamicRREngine:
    """
    根据市场状态（趋势强度 + 波动扩张程度）动态调整止盈止损距离
    """
    
    REGIME_CONFIG = {
        "strong_trend":  {"rr_target": 3.0, "sl_atr_mult": 1.5, "tp_mode": "trailing"},
        "weak_trend":    {"rr_target": 2.5, "sl_atr_mult": 1.8, "tp_mode": "fixed"},
        "breakout":      {"rr_target": 3.5, "sl_atr_mult": 1.2, "tp_mode": "trailing"},
        "ranging":       {"rr_target": 2.0, "sl_atr_mult": 2.0, "tp_mode": "fixed"},
    }

    def __init__(self, min_rr: float = 2.0):
        self.min_rr = min_rr
        self.trailing_state = {}  # symbol -> trailing stop price

    def classify_regime(self, regime: MarketRegime) -> str:
        if regime.adx >= 25 and regime.bb_width > 0.03:
            return "breakout"
        elif regime.adx >= 25:
            return "strong_trend"
        elif regime.adx >= 15:
            return "weak_trend"
        else:
            return "ranging"

    def calculate_exits(
        self, 
        entry_price: float, 
        direction: int,    # +1 long, -1 short
        atr: float, 
        regime: MarketRegime,
        signal_score: float
    ) -> dict:
        regime_name = self.classify_regime(regime)
        config = self.REGIME_CONFIG[regime_name]
        
        # --- 止损计算 ---
        sl_distance = atr * config["sl_atr_mult"]
        sl_distance = min(sl_distance, entry_price * 0.03)  # 硬上限 3%
        stop_loss = entry_price - direction * sl_distance

        # --- 止盈计算 ---
        base_tp_distance = sl_distance * config["rr_target"]
        score_boost = max(0, min((signal_score - 50) / 50 * 0.20, 0.25))
        
        bb_cap = regime.bb_width * entry_price * 0.48
        
        if regime_name == "ranging":
            tp_distance = min(base_tp_distance * (1 + score_boost), bb_cap)
        else:
            tp_distance = base_tp_distance * (1 + score_boost)

        actual_rr = tp_distance / sl_distance if sl_distance > 0 else 0
        if actual_rr < self.min_rr:
            tp_distance = sl_distance * self.min_rr

        take_profit = entry_price + direction * tp_distance
        actual_rr = tp_distance / sl_distance if sl_distance > 0 else 0

        return {
            "stop_loss": round(stop_loss, 4),
            "take_profit": round(take_profit, 4),
            "sl_distance_pct": sl_distance / entry_price,
            "tp_distance_pct": tp_distance / entry_price,
            "actual_rr": round(actual_rr, 2),
            "tp_mode": config["tp_mode"],
            "regime": regime_name,
        }

    def update_trailing_stop(self, symbol, current_price, direction, atr, trail_atr_mult=1.2):
        trail_distance = atr * trail_atr_mult
        new_trail = current_price - direction * trail_distance

        if symbol not in self.trailing_state:
            self.trailing_state[symbol] = new_trail
            return new_trail

        current_trail = self.trailing_state[symbol]
        if direction == 1 and new_trail > current_trail:
            self.trailing_state[symbol] = new_trail
            return new_trail
        elif direction == -1 and new_trail < current_trail:
            self.trailing_state[symbol] = new_trail
            return new_trail
        
        return None
    
    def clear_trailing(self, symbol: str):
        self.trailing_state.pop(symbol, None)
