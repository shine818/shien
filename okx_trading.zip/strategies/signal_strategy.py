"""
精准信号策略 (Signal Strategy) v5.0 - 量化管线化版本
替代简单逻辑驱动，引入专业机构级信号处理流程。

核心功能 (v5.0):
1. 信号处理管线:
   - Kalman Filter: 卡尔曼滤波平滑原始评分，消除瞬时噪声和虚假抖动。
   - Adaptive Vol Gate: ATR 智能门槛，在横盘/低波动区自动拉高入场门槛，保护资金。
   - State Machine Confirmation: 状态机锁定信号，要求确认周期内无显著衰减方可成交。
2. 动态盈亏比引擎 (RR Engine):
   - Regime Recognition: 自动识别 [强趋势/弱趋势/突破/震荡] 市场状态。
   - Dynamic Exit: 趋势行情采用追踪止损 (Trailing Stop)，震荡行情采用固定止盈。
3. 组合风控集成:
   - Portfolio VaR: 组合级风险价值监控，单币种信号需服从全局风险预算。
   - Asset Correlation: 相关性避雷针，自动识别 BTC/ETH 同向关联，智能压缩重复敞口。

风控基准:
- 默认杠杆: 10x
- 仓位调节: 五维自适应因子 (ATR, ADX, Sentiment, Drawdown, Correlation)
- 连亏熔断: 同方向连亏 3 次触发 4 小时冷却
"""

import os
import time
import logging
import threading
from typing import List, Optional
from strategies.base import BaseStrategy, TradeAction, Signal
from strategies.signal_filter import KalmanScoreFilter, AdaptiveThresholdGate
from strategies.signal_state_machine import SignalStateMachine, SignalState
from strategies.rr_engine import DynamicRREngine, MarketRegime

logger = logging.getLogger(__name__)


class SignalStrategy(BaseStrategy):
    """精准信号策略: 动态止盈 + 情绪反转平仓 + 用户方向偏好"""

    _retrain_lock = threading.Lock()
    _global_last_retrain = 0.0

    def __init__(self, inst_id: str = "ETH-USDT-SWAP",
                 leverage: int = 10,
                 position_pct: float = 0.80,
                 sl_pct: float = 0.015,
                 tp_pct: float = 0.05,
                 cooldown_hours=0.0,   # 冷却时间（0=关闭）
                 daily_loss_limit: float = 10.0,  # 10U日亏损限额 (以实际平仓为准)
                 bb_period: int = 20,
                 bb_std: float = 2.0,
                 sentiment=None,
                 risk_manager=None,
                 user_bias: str = None,
                 notifier=None,
                 trader=None,
                 threshold: float = 55.0):
        super().__init__("信号策略", inst_id)
        self.leverage = leverage
        self.position_pct = position_pct   # 30% 资金
        self.sl_pct = sl_pct               # 1.5% 止损 (收紧)
        self.tp_pct = tp_pct               # 5% 默认止盈 (加宽)
        self.cooldown = cooldown_hours * 3600  # 2小时冷却
        self.daily_loss_limit = daily_loss_limit

        # Bollinger
        self.bb_period = bb_period
        self.bb_std = bb_std

        # 状态
        self.sentiment = sentiment
        self.risk_manager = risk_manager
        self.user_bias = user_bias  # "long" / "short" / None
        self.last_trade_time = 0.0
        self.daily_loss = 0.0
        self.daily_reset_date = ""
        self.has_position = False
        self._reversal_confirm_count = 0  # v3.2 情绪反转确认计数
        self._last_sentiment_score = 50   # 缓存上一次分数

        # 持仓跟踪 (用于情绪反转平仓 + 移动止盈)
        self.entry_price = 0.0
        self.entry_direction = None  # "long" / "short"
        self.entry_size = "0"
        self._peak_pnl = 0.0  # 持仓期间最大浮盈

        # 方向连亏熔断 (教训#34-40: 同方向连亏3次暂停4小时)
        self._dir_losses = {"long": 0, "short": 0}
        self._dir_block_until = {"long": 0.0, "short": 0.0}

        # 信号管线管线化 (v5.0)
        self.threshold = threshold
        self._long_kalman = KalmanScoreFilter()
        self._short_kalman = KalmanScoreFilter()
        self._vol_gate = AdaptiveThresholdGate(base_threshold=self.threshold)
        self._state_machine = SignalStateMachine(inst_id, confirm_cycles=2, cool_down_seconds=120)
        self._rr_engine = DynamicRREngine(min_rr=2.0)

        # 执行锁 (防重复订单)
        self._action_pending = False
        self._action_pending_time = 0.0
        self._ACTION_LOCK_TIMEOUT = 60  # 60秒超时自动解锁

        # LightGBM ML
        self.lgbm_predictor = None
        self.last_retrain = 0.0
        self.retrain_interval = 24 * 3600  # 每 24 小时重训练
        self.notifier = notifier
        self.trader = trader
        self.dry_run = False  # 由 main.py 设置
        self._sl_tp_check_interval = 60
        self._last_sl_tp_check = 0.0
        self._last_sl_tp_signature = None
        self._init_lgbm()

    def _sync_dry_run_position(self):
        """同步 Trader 持久化的 dry-run 仓位，避免重启后策略忘记持仓。"""
        if not getattr(self, "dry_run", False) or not self.trader:
            return
        try:
            virtual_positions = self.trader.get_virtual_state().get("position", {})
            position = virtual_positions.get(self.inst_id)
        except Exception:
            return

        if not position:
            if self.has_position:
                self._reset_position()
            return

        side = position.get("side")
        entry = float(position.get("entry", 0) or 0)
        size = str(position.get("size", "1") or "1")
        if side not in ("long", "short") or entry <= 0:
            return

        if (not self.has_position or
                self.entry_direction != side or
                abs(self.entry_price - entry) > 1e-8 or
                self.entry_size != size):
            self.entry_direction = side
            self.entry_price = entry
            self.entry_size = size
            self.has_position = True
            self._last_sl_tp_check = 0.0
            self._last_sl_tp_signature = None
            logger.info(f"🧪 同步 dry-run 持仓: {self.inst_id} {side} @{entry:.2f} x{size}")

    def _init_lgbm(self):
        """初始化 LightGBM 预测器"""
        try:
            from ml_lightgbm import LGBMSignalPredictor
            self.lgbm_predictor = LGBMSignalPredictor()
            if self.lgbm_predictor.model:
                model_path = getattr(self.lgbm_predictor, "model_path", "")
                if model_path and os.path.exists(model_path):
                    model_mtime = os.path.getmtime(model_path)
                    self.last_retrain = model_mtime
                    type(self)._global_last_retrain = max(type(self)._global_last_retrain, model_mtime)
                logger.info("🤖 LightGBM 模型已加载")
            else:
                logger.info("🤖 LightGBM 模型未训练, 启动后自动训练")
        except Exception as e:
            logger.warning(f"⚠️ LightGBM 初始化失败: {e}")
            self.lgbm_predictor = None

    def _maybe_retrain(self, client):
        """每 24h 自动重训练"""
        if not self.lgbm_predictor:
            return
        last_retrain = max(self.last_retrain, type(self)._global_last_retrain)
        if time.time() - last_retrain < self.retrain_interval:
            self.last_retrain = last_retrain
            return
        if not type(self)._retrain_lock.acquire(blocking=False):
            return
        try:
            last_retrain = max(self.last_retrain, type(self)._global_last_retrain)
            if time.time() - last_retrain < self.retrain_interval:
                self.last_retrain = last_retrain
                return
            logger.info("🔄 LightGBM 定时重训练...")
            acc = self.lgbm_predictor.train(client, inst_id=self.inst_id)
            self.last_retrain = time.time()
            type(self)._global_last_retrain = self.last_retrain
            if acc:
                logger.info(f"✅ LightGBM 重训练完成, 准确率: {acc:.1%}")
                if self.notifier:
                    self.notifier._send(
                        f"🤖 <b>LightGBM 重训练</b>\n"
                        f"━━━━━━━━━━━━━━\n"
                        f"📊 准确率: <b>{acc:.1%}</b>\n"
                        f"📈 币种: {self.inst_id}\n"
                        f"⏰ {time.strftime('%H:%M:%S')}"
                    )
        except Exception as e:
            logger.warning(f"⚠️ LightGBM 重训练失败: {e}")
        finally:
            type(self)._retrain_lock.release()

    def _reset_daily(self):
        """每日重置"""
        today = time.strftime("%Y-%m-%d")
        if today != self.daily_reset_date:
            self.daily_loss = 0.0
            self.daily_reset_date = today

    def _calc_bollinger(self, closes):
        """计算布林带"""
        if len(closes) < self.bb_period:
            return None, None, None
        recent = closes[-self.bb_period:]
        sma = sum(recent) / self.bb_period
        variance = sum((p - sma) ** 2 for p in recent) / self.bb_period
        std = variance ** 0.5
        return sma, sma + self.bb_std * std, sma - self.bb_std * std

    def _calc_adx(self, highs, lows, closes, period=14):
        """计算 ADX"""
        if len(highs) < period * 2:
            return 0
        tr_list, plus_dm, minus_dm = [], [], []
        for i in range(1, len(highs)):
            h, l, pc = highs[i], lows[i], closes[i-1]
            tr_list.append(max(h - l, abs(h - pc), abs(l - pc)))
            up = highs[i] - highs[i-1]
            dn = lows[i-1] - lows[i]
            plus_dm.append(up if up > dn and up > 0 else 0)
            minus_dm.append(dn if dn > up and dn > 0 else 0)

        def ema(data, p):
            result = [sum(data[:p]) / p]
            k = 1 / p
            for v in data[p:]:
                result.append(result[-1] * (1 - k) + v * k)
            return result

        atr = ema(tr_list, period)
        plus_di = [100 * p / a if a > 0 else 0 for p, a in zip(ema(plus_dm, period), atr)]
        minus_di = [100 * m / a if a > 0 else 0 for m, a in zip(ema(minus_dm, period), atr)]
        dx = [100 * abs(p - m) / (p + m) if (p + m) > 0 else 0 for p, m in zip(plus_di, minus_di)]

        if len(dx) < period:
            return 0
        adx_vals = ema(dx, period)
        return adx_vals[-1] if adx_vals else 0

    def _calc_rsi(self, closes, period=14):
        """计算 RSI"""
        if len(closes) < period + 1:
            return 50
        gains, losses = [], []
        for i in range(1, len(closes)):
            d = closes[i] - closes[i-1]
            gains.append(d if d > 0 else 0)
            losses.append(-d if d < 0 else 0)
        avg_g = sum(gains[-period:]) / period
        avg_l = sum(losses[-period:]) / period
        if avg_l == 0:
            return 100
        rs = avg_g / avg_l
        return 100 - 100 / (1 + rs)

    def _calc_atr(self, highs, lows, closes, period=14):
        """计算 ATR (用于动态止损)"""
        if len(highs) < period + 1:
            return 0
        trs = []
        for i in range(1, len(highs)):
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
            trs.append(tr)
        return sum(trs[-period:]) / period

    def _get_sentiment_direction(self) -> Optional[str]:
        """从情绪分析获取方向 (含用户偏好加权)"""
        if not self.sentiment:
            return None
        try:
            result = self.sentiment.analyze(self.inst_id)
            score = result.get("score", 50)

            # 用户偏好偏移: 看空时降低做多门槛、提高做空门槛
            long_threshold = 60
            short_threshold = 45
            if self.user_bias == "short":
                long_threshold = 70   # 更难做多
                short_threshold = 50  # 更容易做空
            elif self.user_bias == "long":
                long_threshold = 55   # 更容易做多
                short_threshold = 35  # 更难做空

            bias_label = f" [偏好:{self.user_bias}]" if self.user_bias else ""

            if score > long_threshold:
                logger.info(f"📈 情绪看涨 (score={score:.0f}>{long_threshold}){bias_label} → 做多信号")
                return "long"
            elif score < short_threshold:
                logger.info(f"📉 情绪看跌 (score={score:.0f}<{short_threshold}){bias_label} → 做空信号")
                return "short"
            else:
                logger.info(f"⚪ 情绪中性 (score={score:.0f}){bias_label} → 无信号")
                return None
        except Exception as e:
            logger.warning(f"⚠️ 情绪分析异常: {e}")
            return None

    def _calc_dynamic_tp(self, direction: str) -> float:
        """根据情绪强度计算动态止盈幅度 (目标盈亏比 >2:1)"""
        if not self.sentiment:
            return self.tp_pct  # 无情绪数据时用默认
        try:
            result = self.sentiment.analyze(self.inst_id)
            score = result.get("score", 50)

            # 情绪越极端 → TP 越宽
            if direction == "long":
                strength = score - 50  # 正数 = 看涨强度
            else:
                strength = 50 - score  # 正数 = 看空强度

            if strength > 20:  # 强信号
                tp = 0.08
                label = "强信号→8%"
            elif strength > 10:  # 中等
                tp = 0.06
                label = "中等→6%"
            else:  # 弱信号
                tp = 0.04
                label = "弱信号→4%"

            logger.info(f"🎯 动态止盈: {label} (情绪强度={strength:.0f}, 盈亏比≈{tp/self.sl_pct:.1f}:1)")
            return tp
        except Exception:
            return self.tp_pct

    def _ensure_sl_tp(self, client, entry_price: float, direction: str):
        """确保持仓有止损止盈保护 (教训: 防止裸仓)"""
        if entry_price <= 0:
            return
        position_signature = (direction, round(entry_price, 4), self.entry_size or "1")
        now = time.time()
        if (self._last_sl_tp_signature == position_signature and
                now - self._last_sl_tp_check < self._sl_tp_check_interval):
            return
        try:
            # 检查是否已有 algo 委托 (查所有类型: conditional, oco, trigger)
            has_sl = False
            has_tp = False
            for ord_type in ["conditional", "oco", "trigger"]:
                algo_orders = client._request("GET", "/api/v5/trade/orders-algo-pending",
                                              params={"ordType": ord_type, "instId": self.inst_id})
                if algo_orders.get("data"):
                    for a in algo_orders["data"]:
                        if a.get("slTriggerPx") and a.get("slTriggerPx") != "":
                            has_sl = True
                        if a.get("tpTriggerPx") and a.get("tpTriggerPx") != "":
                            has_tp = True

            if has_sl and has_tp:
                self._last_sl_tp_check = now
                self._last_sl_tp_signature = position_signature
                return  # 已有 SL+TP，不重复挂

            sl_side = "sell" if direction == "long" else "buy"

            # 补挂止损
            if not has_sl:
                if direction == "long":
                    sl_price = round(entry_price * (1 - self.sl_pct), 2)
                else:
                    sl_price = round(entry_price * (1 + self.sl_pct), 2)
                sl_result = client.place_stop_order(
                    inst_id=self.inst_id, td_mode="cross",
                    side=sl_side, sz=self.entry_size or "1",
                    sl_trigger_px=str(sl_price))
                if sl_result.get("code") == "0":
                    logger.info(f"🛡️ 同步补挂止损: SL={sl_price} ({self.sl_pct*100:.0f}%)")

            # 补挂止盈
            if not has_tp:
                if direction == "long":
                    tp_price = round(entry_price * (1 + self.tp_pct), 2)
                else:
                    tp_price = round(entry_price * (1 - self.tp_pct), 2)
                tp_result = client.place_stop_order(
                    inst_id=self.inst_id, td_mode="cross",
                    side=sl_side, sz=self.entry_size or "1",
                    tp_trigger_px=str(tp_price))
                if tp_result.get("code") == "0":
                    logger.info(f"🎯 同步补挂止盈: TP={tp_price} ({self.tp_pct*100:.0f}%)")

            self._last_sl_tp_check = now
            self._last_sl_tp_signature = position_signature

        except Exception as e:
            logger.warning(f"⚠️ 补挂SL/TP失败: {e}")

    def _count_reversal_dims(self, sentiment_result: dict, direction: str) -> int:
        """
        统计有多少个情绪维度支持反转方向 (教训#4: 避免单维度假反转)
        direction: "bullish" 或 "bearish"
        返回支持该方向的维度数 (0-5)
        """
        dims = 0
        threshold = 5  # 信号阈值, 超过±5算有效

        # 检查各维度
        for key in ["order_book", "long_short", "open_interest", "taker_volume"]:
            data = sentiment_result.get(key, {})
            sig = data.get("signal", 0)
            if direction == "bullish" and sig > threshold:
                dims += 1
            elif direction == "bearish" and sig < -threshold:
                dims += 1

        # 新闻维度
        news = sentiment_result.get("news", {})
        news_sig = news.get("signal", 0)
        if direction == "bullish" and news_sig > threshold:
            dims += 1
        elif direction == "bearish" and news_sig < -threshold:
            dims += 1

        logger.info(f"📐 反转维度检查 ({direction}): {dims}/5 维确认")
        return dims

    def _get_fng_value(self) -> Optional[int]:
        """获取并缓存恐惧贪婪指数"""
        try:
            sent_data = self.sentiment.analyze(self.inst_id) if self.sentiment else {}
            news_data = sent_data.get("news", {})
            fg_info = news_data.get("fear_greed", {})
            fg_value = fg_info.get("score") if isinstance(fg_info, dict) else None
            return int(fg_value) if fg_value is not None else None
        except Exception:
            return None

    def _check_position_exit(self, client) -> Optional[TradeAction]:
        """持仓中检查: 情绪反转 → 主动平仓"""
        if not self.entry_direction or not self.sentiment:
            return None
        try:
            result = self.sentiment.analyze(self.inst_id, force_refresh=True)
            score = result.get("score", 50)
            current_price = client.get_current_price(self.inst_id)
            if not current_price:
                return None

            pnl_pct = 0
            if self.entry_price > 0:
                if self.entry_direction == "long":
                    pnl_pct = (current_price - self.entry_price) / self.entry_price
                else:
                    pnl_pct = (self.entry_price - current_price) / self.entry_price

            # 1. 移动止盈
            if pnl_pct > self._peak_pnl:
                self._peak_pnl = pnl_pct
            
            if self._peak_pnl >= 0.01 and pnl_pct > 0:
                retrace = 1 - (pnl_pct / self._peak_pnl) if self._peak_pnl > 0 else 0
                if retrace >= 0.35:
                    reason = f"📈 移动止盈 (峰值={self._peak_pnl:+.2%}, 回撤={retrace:.0%})"
                    logger.info(f"🔔 {reason}")
                    signal = Signal.CLOSE_LONG if self.entry_direction == "long" else Signal.CLOSE_SHORT
                    action = TradeAction(
                        signal=signal, inst_id=self.inst_id, price=current_price,
                        size=self.entry_size, reason=reason, sl_price=0, tp_price=0
                    )
                    self._reset_position_state()
                    return action

            # 2. 情绪反转
            ob_reliable = result.get("ob_reliable", True)
            bear_threshold = 25 if pnl_pct > 0 else 30
            bull_threshold = 75 if pnl_pct > 0 else 70
            if not ob_reliable:
                bear_threshold, bull_threshold = 25, 75

            reversal_triggered = False
            reason = ""
            if self.entry_direction == "long" and score < bear_threshold:
                if self._count_reversal_dims(result, "bearish") >= 2:
                    reversal_triggered = True
                    reason = f"📰 情绪反转平多 (score={score:.0f})"
            elif self.entry_direction == "short" and score > bull_threshold:
                if self._count_reversal_dims(result, "bullish") >= 2:
                    reversal_triggered = True
                    reason = f"📰 情绪反转平空 (score={score:.0f})"

            # v3.2: 情绪确认去噪
            if reversal_triggered:
                self._reversal_confirm_count += 1
                if self._reversal_confirm_count < 2:
                    logger.info(f"⏳ 情绪反转待确认 ({self._reversal_confirm_count}/2)...")
                    reversal_triggered = False
                else:
                    logger.info(f"✅ 情绪反转确认通过")
            else:
                self._reversal_confirm_count = 0

            # 3. 盈利落袋 / 用户偏好
            should_exit = reversal_triggered
            if not should_exit and pnl_pct > 0.02 and 40 <= score <= 60:
                should_exit = True
                reason = f"💰 盈利落袋 (PnL={pnl_pct:+.2%})"
            if not should_exit and self.user_bias and pnl_pct > 0.01:
                if self.entry_direction != self.user_bias:
                    should_exit = True
                    reason = f"📋 偏好平仓 (PnL={pnl_pct:+.2%})"

            if should_exit:
                logger.info(f"🔔 {reason}")
                signal = Signal.CLOSE_LONG if self.entry_direction == "long" else Signal.CLOSE_SHORT
                action = TradeAction(
                    signal=signal, inst_id=self.inst_id, price=current_price,
                    size=self.entry_size, reason=reason, sl_price=0, tp_price=0
                )
                exit_dir = self.entry_direction
                # 记录连亏
                if pnl_pct < 0 and exit_dir:
                    self._dir_losses[exit_dir] = self._dir_losses.get(exit_dir, 0) + 1
                    if self._dir_losses[exit_dir] >= 3:
                        self._dir_block_until[exit_dir] = time.time() + 4 * 3600
                elif exit_dir:
                    self._dir_losses[exit_dir] = 0
                
                self._reset_position_state()
                if pnl_pct < 0: self.last_trade_time = time.time()
                return action

        except Exception as e:
            logger.error(f"❌ 持仓检查异常: {e}")
        return None

    def _reset_position_state(self):
        """重置持仓相关状态"""
        self.entry_direction = None
        self.entry_price = 0
        self.entry_size = "0"
        self._peak_pnl = 0
        self.has_position = False
        self._reversal_confirm_count = 0
        self._last_sl_tp_check = 0.0
        self._last_sl_tp_signature = None

    def _check_entry_signal(self, client) -> Optional[TradeAction]:
        """加权评分开仓: 情绪40% + 规则35% + ML25%, 总分>50触发"""
        # 1. 冷却期
        if time.time() - self.last_trade_time < self.cooldown:
            remaining = int((self.cooldown - (time.time() - self.last_trade_time)) / 60)
            logger.info(f"⏳ 冷却中 ({remaining}分钟后可交易)")
            return None

        # 2. 每日亏损限制
        self._reset_daily()
        if self.daily_loss >= self.daily_loss_limit:
            logger.warning(f"🛑 今日已亏 {self.daily_loss:.2f}U, 超过限额 {self.daily_loss_limit}U, 停止交易")
            return None

        # 3. 已有仓位 → 交给 _check_position_exit 处理
        # 🧪 Dry-run: 跳过实盘持仓检查，用虚拟状态
        if getattr(self, 'dry_run', False):
            # dry-run 模式: 只用 self.has_position 内部状态
            if self.has_position:
                return None
        else:
            positions = client.get_positions()
            has_pos = False
            if positions.get("data"):
                for p in positions["data"]:
                    if p.get("instId") == self.inst_id and float(p.get("pos", 0)) != 0:
                        has_pos = True
                        pos_amt = float(p.get("pos", 0))
                        new_dir = "long" if pos_amt > 0 else "short"
                        avg_px = float(p.get("avgPx", 0))
                        # 如果方向变了或未同步, 重置状态
                        if self.entry_direction != new_dir:
                            self.entry_direction = new_dir
                            self.entry_price = avg_px
                            self.entry_size = str(abs(int(pos_amt)))
                            logger.info(f"🔄 同步持仓: {self.entry_direction} @ {self.entry_price}")

                        # 检查是否有止损止盈保护 (教训: 防止裸仓)
                        self._ensure_sl_tp(client, avg_px, new_dir)

                        self.has_position = True
                        return None
            # 无仓位时清理状态
            if not has_pos:
                self.has_position = False
                if self.entry_direction:
                    self.entry_direction = None
                    self.entry_price = 0
                    self.entry_size = "0"
                self._last_sl_tp_check = 0.0
                self._last_sl_tp_signature = None

        # 4. 获取 K 线数据
        candles = client._request("GET", "/api/v5/market/candles",
                                   params={"instId": self.inst_id, "bar": "1H", "limit": "50"})
        if not candles.get("data") or len(candles["data"]) < 30:
            return None

        closes = [float(c[4]) for c in reversed(candles["data"])]
        highs = [float(c[2]) for c in reversed(candles["data"])]
        lows = [float(c[3]) for c in reversed(candles["data"])]
        volumes = [float(c[5]) for c in reversed(candles["data"])]
        current_price = closes[-1]

        # ─── 三维评分 ───

        # 维度1: 情绪评分 (0-100)
        sentiment_score = 50  # 默认中性
        if self.sentiment:
            try:
                result = self.sentiment.analyze(self.inst_id)
                sentiment_score = result.get("score", 50)
            except Exception as e:
                logger.warning(f"⚠️ 情绪评分获取失败(用默认50): {e}")

        # 维度2: 规则评分 (ADX + BB)
        adx = self._calc_adx(highs, lows, closes)
        mid, upper, lower = self._calc_bollinger(closes)
        if not mid:
            return None

        adx_score = min(100, adx * 2.5)  # ADX 40 → 100分
        bb_range = upper - lower
        if bb_range > 0:
            if current_price <= lower * 1.01:
                bb_score = 80 + min(20, (lower - current_price) / bb_range * 100)
            elif current_price >= upper * 0.99:
                bb_score = 80 + min(20, (current_price - upper) / bb_range * 100)
            else:
                mid_p = (upper + lower) / 2
                bb_score = max(0, 50 - abs(current_price - mid_p) / bb_range * 100)
        else:
            bb_score = 50
        rule_score = (adx_score + min(100, bb_score)) / 2

        # 维度3: ML 评分 (0-100)
        ml_score = 50  # 默认中性
        if self.lgbm_predictor and self.lgbm_predictor.model:
            try:
                ml_score = self.lgbm_predictor.predict(highs, lows, closes, volumes)
            except Exception:
                ml_score = 50

        # 维度4: RSI 反转检测 (v3.1 新增)
        rsi = self._calc_rsi(closes)
        atr = self._calc_atr(highs, lows, closes)

        # ─── 加权多空评分 ───
        # ML准确率v2=73%, 回测验证ML主导权重最优
        W_SENT, W_RULE, W_ML = 0.30, 0.30, 0.40
        LONG_THRESHOLD = self.threshold
        SHORT_THRESHOLD = self.threshold

        # 规则评分: ADX 趋势强度为基础, BB位置为加成
        # ADX 越高趋势越明确, 两个方向都可以用
        base_rule = min(100, adx * 2)  # ADX=25→50, ADX=50→100

        # BB 位置加成: 靠近 lower 做多加分, 靠近 upper 做空加分
        bb_mid = (upper + lower) / 2
        bb_range = upper - lower if upper > lower else 1
        bb_position = (current_price - lower) / bb_range  # 0=下轨, 1=上轨

        # 做多评分
        long_sent = max(0, sentiment_score - 50) * 2  # 0-100
        long_rule = base_rule * (1.0 + max(0, 0.5 - bb_position))  # 靠近下轨加成
        long_ml = max(0, ml_score - 50) * 2

        # 做空评分
        short_sent = max(0, 50 - sentiment_score) * 2
        short_rule = base_rule * (1.0 + max(0, bb_position - 0.5))  # 靠近上轨加成
        short_ml = max(0, 50 - ml_score) * 2

        long_total = long_sent * W_SENT + long_rule * W_RULE + long_ml * W_ML
        short_total = short_sent * W_SENT + short_rule * W_RULE + short_ml * W_ML

        # ─── RSI 反转加分 (v3.1: 超卖做多/超买做空) ───
        rsi_bonus_long = 0
        rsi_bonus_short = 0
        if rsi < 30:
            rsi_bonus_long = (30 - rsi) * 1.5  # RSI=20 → +15分
            long_total += rsi_bonus_long
            short_total *= 0.5  # 超卖时抑制做空
            logger.info(f"📉 RSI超卖={rsi:.0f} → 做多加分+{rsi_bonus_long:.0f}, 做空减半")
        elif rsi > 70:
            rsi_bonus_short = (rsi - 70) * 1.5  # RSI=80 → +15分
            short_total += rsi_bonus_short
            long_total *= 0.5  # 超买时抑制做多
            logger.info(f"📈 RSI超买={rsi:.0f} → 做空加分+{rsi_bonus_short:.0f}, 做多减半")

        # 用户偏好: 加成 + ML下限 + 逆向抑制 (教训#34-40: ML不能阻止用户bias方向)
        if self.user_bias == "long":
            long_ml = max(long_ml, 40)    # ML 不能拖累做多 (用户说做多, ML 至少给 40 分)
            long_total = long_sent * W_SENT + long_rule * W_RULE + long_ml * W_ML + 20
            short_ml *= 0.3               # ML 逆势做空压制 70%
            short_total = short_sent * W_SENT + short_rule * W_RULE + short_ml * W_ML
        elif self.user_bias == "short":
            short_ml = max(short_ml, 40)
            short_total = short_sent * W_SENT + short_rule * W_RULE + short_ml * W_ML + 20
            long_ml *= 0.3
            long_total = long_sent * W_SENT + long_rule * W_RULE + long_ml * W_ML

        # ─── 信号管线化处理 (v5.0) ───
        # 1. 卡尔曼滤波平滑
        long_smooth = self._long_kalman.update(long_total)
        short_smooth = self._short_kalman.update(short_total)

        # 2. 波动率感知门槛更新
        self._vol_gate.update_atr(atr, current_price)
        base_threshold = self._vol_gate.get_entry_threshold()
        
        # 结合 F&G 进行门槛漂移 (取两者最严值)
        long_threshold_adj = max(base_threshold, LONG_THRESHOLD)
        short_threshold_adj = max(base_threshold, SHORT_THRESHOLD)

        # 日志美化与透明度: 展示加权得分明细
        log_msg = (
            f"📊 管线得分 | "
            f"多:{long_smooth:.1f}(原{long_total:.1f}) [Sent:{long_sent*W_SENT:.1f}, Rule:{long_rule*W_RULE:.1f}, ML:{long_ml*W_ML:.1f}] | "
            f"空:{short_smooth:.1f}(原{short_total:.1f}) [Sent:{short_sent*W_SENT:.1f}, Rule:{short_rule*W_RULE:.1f}, ML:{short_ml*W_ML:.1f}] | "
            f"阈值:{base_threshold:.1f}"
        )
        logger.info(log_msg)

        # 3. 状态机二次确认
        if long_smooth >= long_threshold_adj and long_smooth > short_smooth:
            confirmed = self._state_machine.process(long_smooth, "long", long_threshold_adj)
            final_direction = "long"
            final_score = long_smooth
        elif short_smooth >= short_threshold_adj and short_smooth > long_smooth:
            confirmed = self._state_machine.process(short_smooth, "short", short_threshold_adj)
            final_direction = "short"
            final_score = short_smooth
        else:
            self._state_machine.reset()
            confirmed = False
            final_direction = None
            final_score = 0

        if self._state_machine.state != SignalState.IDLE:
             logger.info(f"🤖 状态机 [{self.inst_id}]: {self._state_machine.state.value} | 确认进度: {self._state_machine.confirm_count}/{self._state_machine.confirm_cycles}")

        if not confirmed:
            return None

        # 4. 市场状态分类 + 动态盈亏比 (RR) 计算
        regime = MarketRegime(
            adx=adx,
            atr_pct=atr/current_price,
            bb_width=(upper-lower)/current_price,
            trend_direction=(1 if final_direction == "long" else -1)
        )
        exits = self._rr_engine.calculate_exits(
            entry_price=current_price,
            direction=(1 if final_direction == "long" else -1),
            atr=atr,
            regime=regime,
            signal_score=final_score
        )

        # 5. 信号确认成功!
        signal = Signal.BUY if final_direction == "long" else Signal.SELL
        logger.info(f"🚀🚀 信号确认成功! [{self.inst_id}] Regime={exits['regime']} RR={exits['actual_rr']} 方向={final_direction}")

        # 重置状态机
        self._state_machine.reset()
        
        # 构造执行动作
        # 从 RiskManager 计算合理仓位 (不再默认 size=0 依赖 Trader 兜底)
        calc_size = "1"  # 最小默认值
        if self.risk_manager:
            try:
                sl_dist_pct = exits.get("sl_distance_pct", 0.02)
                calc_size = str(self.risk_manager.calc_adaptive_position(
                    inst_id=self.inst_id,
                    entry_price=current_price,
                    sl_distance_pct=sl_dist_pct,
                    atr=atr,
                    win_rate=getattr(self.risk_manager, 'recent_win_rate', 0.5),
                    volatility=atr / current_price if current_price > 0 else 0.01,
                    recent_pnl=getattr(self.risk_manager, 'recent_pnl_sum', 0),
                ))
            except Exception as e:
                logger.warning(f"仓位计算异常, 使用最小仓位: {e}")

        action = TradeAction(
            signal=signal,
            inst_id=self.inst_id,
            price=current_price,
            size=calc_size,
            reason=f"PipelineConfirmed({final_direction},Regime:{exits['regime']},Score:{final_score:.0f})",
            sl_price=exits["stop_loss"],
            tp_price=exits["take_profit"]
        )
        # 记录持仓信息 (供状态显示)
        self.entry_price = current_price
        self.entry_direction = final_direction
        self.has_position = True
        
        return action

    def reset_action_lock(self):
        """重置执行锁 (由 Trader 执行完毕后调用)"""
        if self._action_pending:
            self._action_pending = False
            logger.info("🔓 执行锁已释放")

    def analyze(self, client) -> List[TradeAction]:
        """分析并返回交易动作"""
        # 执行锁: 防止 action 创建后、执行前重复触发 (教训#43/#44)
        if self._action_pending:
            elapsed = time.time() - self._action_pending_time
            if elapsed < self._ACTION_LOCK_TIMEOUT:
                logger.info(f"⏳ 信号执行中, 跳过分析 ({elapsed:.0f}s/{self._ACTION_LOCK_TIMEOUT}s)")
                return []
            else:
                logger.warning(f"⚠️ 执行锁超时 ({elapsed:.0f}s), 自动解锁")
                self._action_pending = False

        # 定期重训练 LightGBM
        self._maybe_retrain(client)

        # 持仓中: 检查情绪反转平仓
        self._sync_dry_run_position()
        if self.has_position and self.entry_direction:
            exit_action = self._check_position_exit(client)
            if exit_action:
                self._action_pending = True
                self._action_pending_time = time.time()
                return [exit_action]  # cooldown已在_check_position_exit内设置
            return []  # 持仓中不开新单

        action = self._check_entry_signal(client)
        if action:
            self._action_pending = True
            self._action_pending_time = time.time()
            self.last_trade_time = time.time()
            return [action]
        return []

    def record_loss(self, amount: float):
        """记录亏损"""
        self.daily_loss += abs(amount)

    def get_status(self) -> dict:
        cd_left = max(0, self.cooldown - (time.time() - self.last_trade_time))
        return {
            "name": "信号策略",
            "direction": "等待信号",
            "daily_loss": f"{self.daily_loss:.2f}/{self.daily_loss_limit:.0f}U",
            "cooldown": f"{cd_left/60:.0f}min" if cd_left > 0 else "就绪",
            "has_position": self.has_position,
        }
