from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta

class SignalState(Enum):
    IDLE = "idle"
    PENDING = "pending"      # 首次触发，等待确认
    CONFIRMED = "confirmed"  # 二次确认通过
    COOLING = "cooling"      # 信号失败后冷却

@dataclass
class SignalStateMachine:
    symbol: str
    confirm_cycles: int = 2       # 需要连续确认次数
    cool_down_seconds: int = 120  # 信号失败后冷却时间
    
    state: SignalState = SignalState.IDLE
    pending_direction: str = None
    confirm_count: int = 0
    last_trigger_time: datetime = None
    cool_until: datetime = None
    score_history: list = field(default_factory=list)  # 记录确认期间的得分序列

    def process(self, score: float, direction: str, threshold: float) -> bool:
        """
        返回 True 表示信号通过，可以开仓。
        关键改进：确认期间的得分必须保持稳定（不能衰减），防止"勉强过线"的虚假确认。
        """
        now = datetime.utcnow()
        
        # 冷却期直接拒绝
        if self.state == SignalState.COOLING:
            if self.cool_until and now < self.cool_until:
                return False
            else:
                self.state = SignalState.IDLE

        signal_triggered = score >= threshold

        if self.state == SignalState.IDLE:
            if signal_triggered:
                self.state = SignalState.PENDING
                self.pending_direction = direction
                self.confirm_count = 1
                self.last_trigger_time = now
                self.score_history = [score]
                if self.confirm_cycles <= 1:
                    self.state = SignalState.CONFIRMED
                    return True
                return False
            return False

        elif self.state == SignalState.PENDING:
            # 方向翻转或信号消失 → 冷却
            if not signal_triggered or direction != self.pending_direction:
                self._enter_cooling(now)
                return False
            
            self.confirm_count += 1
            self.score_history.append(score)
            
            # 额外检查：确认期间得分不能持续下滑（至少不低于首次触发的 95%）
            score_decay = self.score_history[-1] / self.score_history[0] if self.score_history[0] > 0 else 1.0
            if score_decay < 0.95:
                self._enter_cooling(now)
                return False

            if self.confirm_count >= self.confirm_cycles:
                self.state = SignalState.CONFIRMED
                return True
            return False

        elif self.state == SignalState.CONFIRMED:
            # 已确认状态由外部开仓后重置
            return True

        return False

    def reset(self):
        self.state = SignalState.IDLE
        self.pending_direction = None
        self.confirm_count = 0
        self.score_history = []

    def _enter_cooling(self, now: datetime):
        self.state = SignalState.COOLING
        self.cool_until = now + timedelta(seconds=self.cool_down_seconds)
        self.confirm_count = 0
        self.score_history = []
