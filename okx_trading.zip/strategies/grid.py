"""
网格交易策略 v2.0
在价格区间内自动挂买卖单，适合震荡行情
新增: Bollinger Bands 自动计算区间 + 定时重校准
"""
import time
import logging
from typing import List
from .base import BaseStrategy, Signal, TradeAction

logger = logging.getLogger(__name__)


class GridStrategy(BaseStrategy):
    """
    网格交易策略 v2.0

    原理：
    1. 用 Bollinger Bands (SMA20 ± 2σ) 自动计算价格区间
    2. 将区间等分为 N 个网格
    3. 低于当前价的网格挂买单，高于当前价的网格挂卖单
    4. 每 4 小时自动重新校准区间（价格突破时立即重建）

    v2 新增:
    - Bollinger Bands 自动区间替代手动设定
    - 定时重校准 (默认 4 小时)
    - ADX 网格密度自适应 (震荡加密, 趋势放宽)
    """

    def __init__(self, inst_id: str = "BTC-USDT-SWAP",
                 upper_price: float = 0,
                 lower_price: float = 0,
                 grid_count: int = 5,
                 total_investment: float = 20.0,
                 leverage: int = 5,
                 bb_period: int = 20,
                 bb_std: float = 2.0,
                 recalibrate_hours: float = 2.0,
                 sl_pct: float = 0.02,
                 tp_pct: float = 0.01,
                 sentiment=None):
        super().__init__("网格交易", inst_id)
        self.upper_price = upper_price
        self.lower_price = lower_price
        self.grid_count = grid_count
        self.total_investment = total_investment
        self.leverage = leverage

        # Bollinger Bands 参数
        self.bb_period = bb_period
        self.bb_std = bb_std
        self.recalibrate_interval = recalibrate_hours * 3600

        # 运行状态
        self.grid_lines: List[float] = []
        self.grid_step = 0.0
        self.active_orders: dict = {}
        self.filled_grids: dict = {}
        self.grid_profit = 0.0
        self.initialized = False
        self.last_calibrate_time = 0.0
        self.bb_upper = 0.0
        self.bb_lower = 0.0
        self.bb_mid = 0.0
        self.auto_mode = (upper_price == 0 and lower_price == 0)

        # 止盈止损
        self.sl_pct = sl_pct
        self.tp_pct = tp_pct

        # 市场情绪 → 自动方向
        self.sentiment = sentiment
        self.direction = "short"  # 默认做空 (保守)

        # 持仓对称保护
        self.buy_count = 0       # 本轮累计买入笔数
        self.sell_count = 0      # 本轮累计卖出笔数
        self.max_imbalance = 3   # 最大允许买卖差 (超过则暂停开仓)

    # ─── Bollinger Bands 计算 ───

    @staticmethod
    def _calc_bollinger(closes: List[float], period: int = 20, num_std: float = 2.0):
        """计算布林带: (中轨, 上轨, 下轨)"""
        if len(closes) < period:
            return None, None, None

        recent = closes[-period:]
        sma = sum(recent) / period
        variance = sum((p - sma) ** 2 for p in recent) / period
        std = variance ** 0.5

        upper = sma + num_std * std
        lower = sma - num_std * std
        return round(sma, 6), round(upper, 6), round(lower, 6)

    @staticmethod
    def _calc_adx(highs, lows, closes, period=14):
        """ADX: >25 趋势, <20 震荡"""
        if len(highs) < period * 2:
            return 25.0
        plus_dm, minus_dm, tr_list = [], [], []
        for i in range(1, len(highs)):
            up = highs[i] - highs[i - 1]
            down = lows[i - 1] - lows[i]
            plus_dm.append(up if up > down and up > 0 else 0)
            minus_dm.append(down if down > up and down > 0 else 0)
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
            tr_list.append(tr)
        if len(tr_list) < period:
            return 25.0
        atr_val = sum(tr_list[-period:]) / period
        if atr_val == 0:
            return 25.0
        plus_di = (sum(plus_dm[-period:]) / period) / atr_val * 100
        minus_di = (sum(minus_dm[-period:]) / period) / atr_val * 100
        return abs(plus_di - minus_di) / (plus_di + minus_di + 0.0001) * 100

    def _fetch_ohlcv(self, client):
        """获取 K 线数据用于计算布林带"""
        need = max(self.bb_period + 5, 30)
        result = client.get_candles(self.inst_id, bar="1H", limit=str(need))
        if result.get("code") != "0" or not result.get("data"):
            return None, None, None, None
        candles = result["data"]
        candles.reverse()
        highs = [float(c[2]) for c in candles]
        lows = [float(c[3]) for c in candles]
        closes = [float(c[4]) for c in candles]
        return highs, lows, closes, closes[-1] if closes else None

    # ─── 区间设定 ───

    def _auto_set_range_bollinger(self, client):
        """用 Bollinger Bands 自动计算网格区间"""
        highs, lows, closes, current_price = self._fetch_ohlcv(client)

        if closes is None or len(closes) < self.bb_period:
            # 数据不足，退回到简单 ±8%
            if current_price:
                self._fallback_range(current_price)
            return

        mid, upper, lower = self._calc_bollinger(closes, self.bb_period, self.bb_std)
        if mid is None:
            if current_price:
                self._fallback_range(current_price)
            return

        # ADX 自适应: 震荡行情收窄区间加密网格, 趋势行情放宽区间
        adx = self._calc_adx(highs, lows, closes)

        if adx < 20:
            # 强震荡 → 收窄到 1.5σ, 加密网格
            _, upper, lower = self._calc_bollinger(closes, self.bb_period, 1.5)
            self.grid_count = max(self.grid_count, 12)
            mode_label = "震荡模式(1.5σ)"
        elif adx > 30:
            # 强趋势 → 放宽到 2.5σ, 减少网格
            _, upper, lower = self._calc_bollinger(closes, self.bb_period, 2.5)
            self.grid_count = max(8, self.grid_count - 2)
            mode_label = "趋势模式(2.5σ)"
        else:
            mode_label = "标准模式(2.0σ)"

        self.upper_price = upper
        self.lower_price = lower
        self.bb_upper = upper
        self.bb_lower = lower
        self.bb_mid = mid
        self.last_calibrate_time = time.time()

        logger.info(f"📐 Bollinger 自动区间: {lower:.4f} - {upper:.4f} "
                    f"| 中轨={mid:.4f} | ADX={adx:.0f} | {mode_label}")
        print(f"📐 Bollinger 自动区间: {lower:.4f} - {upper:.4f} "
              f"| 中轨={mid:.4f} | ADX={adx:.0f} | {mode_label}")

    def _fallback_range(self, current_price: float, range_pct: float = 0.08):
        """数据不足时的回退方案: ±8%"""
        self.upper_price = round(current_price * (1 + range_pct), 4)
        self.lower_price = round(current_price * (1 - range_pct), 4)
        self.last_calibrate_time = time.time()
        print(f"📐 回退区间 (±{range_pct:.0%}): {self.lower_price} - {self.upper_price}")

    def _calculate_grids(self):
        """计算网格线"""
        if self.upper_price <= self.lower_price:
            raise ValueError(f"上限({self.upper_price})必须大于下限({self.lower_price})")

        step = (self.upper_price - self.lower_price) / self.grid_count
        self.grid_lines = []
        for i in range(self.grid_count + 1):
            price = round(self.lower_price + step * i, 6)
            self.grid_lines.append(price)

        self.grid_step = step
        self.per_grid_amount = self.total_investment / self.grid_count

    def _should_recalibrate(self) -> bool:
        """是否该重新校准区间"""
        if not self.auto_mode:
            return False
        return (time.time() - self.last_calibrate_time) >= self.recalibrate_interval

    # ─── 核心逻辑 ───

    def initialize(self, client) -> List[TradeAction]:
        """初始化网格"""
        if self.auto_mode:
            self._auto_set_range_bollinger(client)
        elif self.upper_price == 0 or self.lower_price == 0:
            current_price = client.get_current_price(self.inst_id)
            if current_price:
                self._fallback_range(current_price)

        self._calculate_grids()

        current_price = client.get_current_price(self.inst_id)
        if not current_price:
            print("❌ 无法获取当前价格")
            return []

        print(f"📊 网格策略初始化 (v2 · Bollinger):")
        print(f"   价格区间: {self.lower_price} - {self.upper_price}")
        print(f"   网格数量: {self.grid_count}")
        print(f"   网格间距: {self.grid_step:.6f}")
        print(f"   每格金额: {self.per_grid_amount:.2f} USDT")
        print(f"   杠杆倍数: {self.leverage}x")
        print(f"   重校间隔: {self.recalibrate_interval / 3600:.0f}h")

        actions = self._place_grid_orders(client, current_price)
        self.initialized = True
        return actions

    def _detect_direction(self):
        """根据市场情绪自动判断做多/做空方向
        使用 MarketSentiment.analyze() 综合评分:
        - score > 65 → 做多 (看涨)
        - score < 35 → 做空 (看跌)
        - 35-65 → 做空 (保守偏空)
        """
        if not self.sentiment:
            return  # 无情绪数据, 保持当前方向

        try:
            result = self.sentiment.analyze(self.inst_id)
            if not result:
                return

            score = result.get("score", 50)
            direction_label = result.get("direction", "neutral")
            old_dir = self.direction

            if score > 65:
                self.direction = "long"    # 看涨 → 做多
            elif score < 35:
                self.direction = "short"   # 看跌 → 做空
            else:
                self.direction = "short"   # 中性偏空 (保守)

            if old_dir != self.direction:
                logger.info(f"🔄 网格方向切换: {old_dir} → {self.direction} (情绪={score:.0f} {direction_label})")
            else:
                logger.info(f"📊 网格方向: {self.direction} (情绪={score:.0f} {direction_label})")
        except Exception as e:
            logger.warning(f"⚠️ 方向检测异常: {e}")

    def _place_grid_orders(self, client, current_price: float) -> List[TradeAction]:
        """在网格线上摆放订单 — 每次只下 1 单, 方向由 self.direction 决定"""
        contract_val = client.get_contract_val(self.inst_id)

        best_action = None
        best_distance = float('inf')
        is_short = (self.direction == "short")

        for price in self.grid_lines:
            distance = abs(price - current_price)
            if distance < self.grid_step * 0.3:
                continue

            sz_in_usdt = self.per_grid_amount * self.leverage
            num_contracts = max(1, int(sz_in_usdt / (contract_val * price)))
            sz = str(num_contracts)

            if is_short and price > current_price and distance < best_distance:
                # 做空: 在价格上方挂卖单
                best_distance = distance
                sl = round(price * (1 + self.sl_pct), 6)
                tp = round(price * (1 - self.tp_pct), 6)
                best_action = TradeAction(
                    signal=Signal.SELL, inst_id=self.inst_id,
                    price=price, size=sz,
                    reason=f"网格做空 @{price:.6f}",
                    sl_price=sl, tp_price=tp
                )
            elif not is_short and price < current_price and distance < best_distance:
                # 做多: 在价格下方挂买单
                best_distance = distance
                sl = round(price * (1 - self.sl_pct), 6)
                tp = round(price * (1 + self.tp_pct), 6)
                best_action = TradeAction(
                    signal=Signal.BUY, inst_id=self.inst_id,
                    price=price, size=sz,
                    reason=f"网格做多 @{price:.6f}",
                    sl_price=sl, tp_price=tp
                )

        if best_action:
            label = "做空" if is_short else "做多"
            logger.info(f"📊 网格选单: 最近{label}点 (距离={best_distance:.6f})")
            return [best_action]

        logger.info("📊 网格: 当前无合适挂单点")
        return []

    def analyze(self, client) -> List[TradeAction]:
        """分析当前状态"""
        if not self.initialized:
            self._detect_direction()  # 初始化前先检测方向
            return self.initialize(client)

        # 每次分析前检测市场方向
        self._detect_direction()

        current_price = client.get_current_price(self.inst_id)
        if not current_price:
            return []

        # 定时重校准 (Bollinger 重新计算)
        if self._should_recalibrate():
            logger.info("🔄 Bollinger 定时重校准触发...")
            print("🔄 Bollinger 定时重校准...")
            return self._rebuild_grid(client, current_price)

        # 价格突破区间 → 立即重建
        if current_price < self.lower_price or current_price > self.upper_price:
            print(f"⚠️ 价格 {current_price} 超出区间 "
                  f"[{self.lower_price}, {self.upper_price}]")
            print(f"🔄 Bollinger 重建网格...")
            return self._rebuild_grid(client, current_price)

        # 检查挂单状态，补充 1 个最近的缺失网格 (每次只补 1 单)
        pending = client.get_pending_orders(inst_id=self.inst_id)
        pending_prices = set()

        if pending.get("code") == "0" and pending.get("data"):
            for order in pending["data"]:
                px = float(order.get("px", 0))
                pending_prices.add(round(px, 4))

        contract_val = client.get_contract_val(self.inst_id)
        best_action = None
        best_distance = float('inf')

        is_short = (self.direction == "short")

        for price in self.grid_lines:
            rounded = round(price, 4)
            if rounded in pending_prices:
                continue
            distance = abs(price - current_price)
            if distance < self.grid_step * 0.3:
                continue

            if is_short and price > current_price and distance < best_distance:
                sz_in_usdt = self.per_grid_amount * self.leverage
                num_contracts = max(1, int(sz_in_usdt / (contract_val * price)))
                best_distance = distance
                sl = round(price * (1 + self.sl_pct), 6)
                tp = round(price * (1 - self.tp_pct), 6)
                best_action = TradeAction(
                    signal=Signal.SELL, inst_id=self.inst_id,
                    price=price, size=str(num_contracts),
                    reason=f"网格补空 @{price:.6f}",
                    sl_price=sl, tp_price=tp
                )
            elif not is_short and price < current_price and distance < best_distance:
                sz_in_usdt = self.per_grid_amount * self.leverage
                num_contracts = max(1, int(sz_in_usdt / (contract_val * price)))
                best_distance = distance
                sl = round(price * (1 - self.sl_pct), 6)
                tp = round(price * (1 + self.tp_pct), 6)
                best_action = TradeAction(
                    signal=Signal.BUY, inst_id=self.inst_id,
                    price=price, size=str(num_contracts),
                    reason=f"网格补多 @{price:.6f}",
                    sl_price=sl, tp_price=tp
                )

        return [best_action] if best_action else []

    def _rebuild_grid(self, client, current_price: float) -> List[TradeAction]:
        """重建网格: 撤旧单 → Bollinger 重算 → 重新挂单"""
        # 记录不平衡警告
        imbalance = abs(self.buy_count - self.sell_count)
        if imbalance > 0:
            logger.warning(f"⚠️ 网格重建时买卖不平衡: {self.buy_count}买/{self.sell_count}卖 "
                          f"(差={imbalance})")

        try:
            client.cancel_all_orders(self.inst_id)
            logger.info(f"🧹 已撤销旧网格挂单")
        except Exception as e:
            logger.warning(f"⚠️ 撤单出错: {e}")

        # 重置计数器
        self.buy_count = 0
        self.sell_count = 0

        # 用 Bollinger 重新计算区间
        if self.auto_mode:
            self.upper_price = 0
            self.lower_price = 0
            self._auto_set_range_bollinger(client)
        else:
            self._fallback_range(current_price)

        self._calculate_grids()

        logger.info(f"📐 网格已重建: {self.lower_price} - {self.upper_price} "
                    f"| 间距={self.grid_step:.6f}")

        return self._place_grid_orders(client, current_price)

    def get_status(self) -> dict:
        next_recal = ""
        if self.auto_mode and self.last_calibrate_time > 0:
            remaining = max(0, self.recalibrate_interval - (time.time() - self.last_calibrate_time))
            next_recal = f"{remaining / 60:.0f}min"

        return {
            "策略": f"{self.name} (v2·Bollinger)",
            "交易对": self.inst_id,
            "价格区间": f"{self.lower_price} - {self.upper_price}",
            "布林中轨": f"{self.bb_mid:.6f}" if self.bb_mid else "N/A",
            "网格数量": self.grid_count,
            "网格间距": f"{self.grid_step:.6f}" if self.grid_lines else "未初始化",
            "杠杆": f"{self.leverage}x",
            "累计利润": f"{self.grid_profit:.4f} USDT",
            "模式": "自动(Bollinger)" if self.auto_mode else "手动",
            "下次校准": next_recal or "N/A",
            "运行中": self.is_running,
        }
