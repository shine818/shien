"""
均线交叉策略 (终极版 v2)
EMA 金叉/死叉 + RSI 过滤 + ATR 动态止损 + 追踪止盈
+ 成交量确认 + 多时间框架共振 + ML 置信度辅助
+ 自适应 ATR 倍数 + 凯利公式仓位 + ML 自动校准
"""
from typing import List, Optional, Tuple
from .base import BaseStrategy, Signal, TradeAction


class MACrossStrategy(BaseStrategy):
    """
    均线交叉策略 (终极版 v2)
    
    信号层级过滤链：
    1. EMA7/25 金叉或死叉 → 基础信号
    2. RSI(14) 趋势确认 → 过滤反趋势信号
    3. 成交量放大确认 → 过滤缩量虚假突破
    4. 4H 高级别趋势共振 → 只做顺势单
    5. ML 置信度 (可选) → 置信度>60才放行
    6. ATR 动态止损止盈 + 移动追踪止盈
    
    v2 新增:
    7. 自适应 ATR 倍数 (ADX 判断趋势/震荡自动调参)
    8. 凯利公式动态仓位 (通过 risk_manager 计算)
    9. ML 权重自动校准 (每 50 笔交易触发)
    10. 市场情绪前瞻过滤 (Order Book + 多空比 + 持仓量 + 主动买卖)
    """
    
    def __init__(self, inst_id: str = "BTC-USDT-SWAP",
                 fast_period: int = 9,
                 slow_period: int = 30,
                 bar: str = "1H",
                 leverage: int = 5,
                 position_pct: float = 0.30,
                 ml_scorer=None,
                 risk_manager=None,
                 sentiment=None):
        super().__init__("均线交叉", inst_id)
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.bar = bar
        self.leverage = leverage
        self.position_pct = position_pct
        self.ml_scorer = ml_scorer
        self.risk_manager = risk_manager
        self.sentiment = sentiment          # 市场情绪分析器 (可选)
        self.notifier = None  # 通知器 (由 main.py 注入)
        self.trade_count = 0  # 交易计数 (用于触发 ML 校准)
        
        # 指标状态
        self.prev_fast_ema = None
        self.prev_slow_ema = None
        self.current_rsi = None
        self.current_atr = None
        self.current_volume_ratio = None
        self.higher_tf_trend = None  # 'bullish', 'bearish', None
        self.ml_confidence = None
        
        # 持仓状态
        self.current_position = None  # 'long', 'short', None
        self.entry_price = 0.0
        self.highest_since_entry = 0.0
        self.lowest_since_entry = 999999.0
        self.trailing_active = False
        
        # 阶梯止盈状态
        self.tp_tier1_done = False  # 2×ATR 平 30%
        self.tp_tier2_done = False  # 3×ATR 平 30%
        self.remaining_pct = 1.0    # 剩余仓位比例
        
        # ATR 乘数 (基础值, 会被自适应调整) — v5 加宽止盈减少频率
        self.atr_sl_mult = 3.0
        self.atr_tp_mult = 6.0
        self.atr_trail_activate = 3.0
        self.atr_trail_offset = 1.5
        self.adaptive_atr = True
        
        # 阶梯止盈参数
        self.tp_tier1_atr = 2.0   # 第一层: 浮盈 2×ATR
        self.tp_tier1_close = 0.30 # 平掉 30%
        self.tp_tier2_atr = 3.0   # 第二层: 浮盈 3×ATR
        self.tp_tier2_close = 0.30 # 再平 30%
        # 剩余 40% 由追踪止盈管理
        
        # 波动率过滤 (布林带挤压)
        self.bb_period = 20
        self.bb_squeeze_threshold = 0.015  # BB宽度 < 1.5% 判定为挤压 (放宽: 原2%)
        self.volatility_filter = True
        
        # 成交量过滤参数
        self.vol_ma_period = 20
        self.vol_threshold = 1.2    # 放宽: 原1.5x 过于严格导致多数信号被过滤

        # v5: 最小持仓时间 (防止快速翻转)
        self.min_hold_bars = 2      # 至少持仓2根K线才能反向 (放宽: 原3)
        self.bars_since_entry = 0   # 入场后经过的K线数
    
    @staticmethod
    def _calc_ema(prices: List[float], period: int) -> List[float]:
        if len(prices) < period:
            return []
        multiplier = 2 / (period + 1)
        ema_values = []
        sma = sum(prices[:period]) / period
        ema_values.append(sma)
        for i in range(period, len(prices)):
            ema = (prices[i] - ema_values[-1]) * multiplier + ema_values[-1]
            ema_values.append(ema)
        return ema_values
    
    @staticmethod
    def _calc_rsi(prices: List[float], period: int = 14) -> float:
        if len(prices) < period + 1:
            return 50.0
        changes = [prices[i] - prices[i-1] for i in range(len(prices)-period, len(prices))]
        gains = [c for c in changes if c > 0]
        losses = [-c for c in changes if c < 0]
        avg_gain = sum(gains) / period if gains else 0
        avg_loss = sum(losses) / period if losses else 0.0001
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))
    
    @staticmethod
    def _calc_atr(highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> float:
        if len(highs) < period + 1:
            return 0.0
        true_ranges = []
        for i in range(1, len(highs)):
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
            true_ranges.append(tr)
        if len(true_ranges) < period:
            return sum(true_ranges) / len(true_ranges) if true_ranges else 0
        return sum(true_ranges[-period:]) / period
    
    @staticmethod
    def _calc_volume_ratio(volumes: List[float], period: int = 20) -> float:
        """计算当前成交量相对于均量的比值"""
        if len(volumes) < period + 1:
            return 1.0
        avg_vol = sum(volumes[-period-1:-1]) / period
        if avg_vol <= 0:
            return 1.0
        return volumes[-1] / avg_vol
    
    def _get_ohlcv_data(self, client, bar: str = None) -> Tuple:
        """获取 OHLCV 数据"""
        use_bar = bar or self.bar
        need = max(self.slow_period, 20) + 15
        result = client.get_candles(self.inst_id, bar=use_bar, limit=str(need))
        
        if result.get("code") != "0" or not result.get("data"):
            return None, None, None, None, None
        
        candles = result["data"]
        candles.reverse()
        
        opens = [float(c[1]) for c in candles]
        highs = [float(c[2]) for c in candles]
        lows = [float(c[3]) for c in candles]
        closes = [float(c[4]) for c in candles]
        volumes = [float(c[5]) for c in candles]
        
        return opens, highs, lows, closes, volumes
    
    def _check_higher_tf_trend(self, client) -> str:
        """检查 4H 级别的趋势方向"""
        try:
            _, _, _, closes_4h, _ = self._get_ohlcv_data(client, bar="4H")
            if not closes_4h or len(closes_4h) < self.slow_period + 2:
                return "neutral"
            
            fast_4h = self._calc_ema(closes_4h, self.fast_period)
            slow_4h = self._calc_ema(closes_4h, self.slow_period)
            
            if not fast_4h or not slow_4h:
                return "neutral"
            
            if fast_4h[-1] > slow_4h[-1]:
                return "bullish"
            else:
                return "bearish"
        except Exception:
            return "neutral"

    @staticmethod
    def _calc_adx(highs, lows, closes, period=14):
        """计算 ADX: >25 趋势行情, <20 震荡行情"""
        if len(highs) < period * 2:
            return 25.0
        plus_dm, minus_dm, tr_list = [], [], []
        for i in range(1, len(highs)):
            up = highs[i] - highs[i - 1]
            down = lows[i - 1] - lows[i]
            plus_dm.append(up if up > down and up > 0 else 0)
            minus_dm.append(down if down > up and down > 0 else 0)
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
            tr_list.append(tr)
        if len(tr_list) < period:
            return 25.0
        atr_val = sum(tr_list[-period:]) / period
        if atr_val == 0:
            return 25.0
        plus_di = (sum(plus_dm[-period:]) / period) / atr_val * 100
        minus_di = (sum(minus_dm[-period:]) / period) / atr_val * 100
        return abs(plus_di - minus_di) / (plus_di + minus_di + 0.0001) * 100

    def _adapt_atr_multipliers(self, adx: float):
        """根据 ADX 自适应调整 ATR 止损/止盈倍数"""
        if not self.adaptive_atr:
            return
        if adx > 30:  # 强趋势: 放宽止盈, 收紧止损
            self.atr_sl_mult = 1.2
            self.atr_tp_mult = 6.0
            self.atr_trail_activate = 2.5
        elif adx > 20:  # 温和趋势: 标准参数
            self.atr_sl_mult = 1.5
            self.atr_tp_mult = 4.5
            self.atr_trail_activate = 2.0
        else:  # 震荡: 收紧止盈, 放宽止损
            self.atr_sl_mult = 2.0
            self.atr_tp_mult = 2.5
            self.atr_trail_activate = 1.5

    def _auto_calibrate_ml(self):
        """每 50 笔交易自动校准 ML 权重"""
        if self.ml_scorer and self.trade_count > 0 and self.trade_count % 50 == 0:
            try:
                self.ml_scorer.calibrate_from_trades()
                print(f"🔧 ML 权重已自动校准 (第 {self.trade_count} 笔交易后)")
            except Exception as e:
                print(f"⚠️ ML 校准失败: {e}")

    def analyze(self, client) -> List[TradeAction]:
        """终极版分析：EMA + RSI + 成交量 + 多时间框架 + ML + ATR + 追踪止盈"""
        opens, highs, lows, closes, volumes = self._get_ohlcv_data(client)
        if not closes or len(closes) < self.slow_period + 2:
            print(f"⚠️ K线数据不足")
            return []
        
        # === 核心指标 ===
        fast_ema = self._calc_ema(closes, self.fast_period)
        slow_ema = self._calc_ema(closes, self.slow_period)
        if len(fast_ema) < 2 or len(slow_ema) < 2:
            return []
        
        curr_fast = fast_ema[-1]
        prev_fast = fast_ema[-2]
        curr_slow = slow_ema[-1]
        prev_slow = slow_ema[-2]
        current_price = closes[-1]
        
        rsi = self._calc_rsi(closes, 14)
        atr = self._calc_atr(highs, lows, closes, 14)
        vol_ratio = self._calc_volume_ratio(volumes, self.vol_ma_period)
        adx = self._calc_adx(highs, lows, closes)
        
        # 自适应 ATR 倍数
        self._adapt_atr_multipliers(adx)
        
        # 4H 高级别趋势
        higher_trend = self._check_higher_tf_trend(client)
        
        # ML 置信度 (可选)
        ml_conf = 75.0  # 默认通过
        if self.ml_scorer:
            try:
                ml_conf = self.ml_scorer.predict_confidence(rsi, atr, curr_fast - curr_slow, vol_ratio)
            except Exception:
                ml_conf = 75.0
        
        # 更新状态
        self.prev_fast_ema = curr_fast
        self.prev_slow_ema = curr_slow
        self.current_rsi = rsi
        self.current_atr = atr
        self.current_volume_ratio = vol_ratio
        self.higher_tf_trend = higher_trend
        self.ml_confidence = ml_conf
        
        # 市场情绪前瞻 (可选)
        sentiment_score = 50.0
        sentiment_label = ""
        sentiment_bias = 1.0
        if self.sentiment:
            try:
                sdata = self.sentiment.analyze(self.inst_id)
                sentiment_score = sdata["score"]
                sentiment_label = sdata.get("label", "")
                sentiment_bias = self.sentiment.get_trade_bias(self.inst_id)
            except Exception:
                pass
        
        actions = []
        
        # === 波动率过滤 (布林带挤压) ===
        bb_width = self._calc_bb_width(closes, self.bb_period)
        if self.volatility_filter and bb_width < self.bb_squeeze_threshold:
            if self.current_position is None:
                print(f"⏸️ BB 挤压检测 | 宽度={bb_width:.4f} < {self.bb_squeeze_threshold} | 暂停开新仓")
                return actions  # 不开新仓, 但现有持仓照常管理

        # === v5: 持仓时间计数 ===
        if self.current_position:
            self.bars_since_entry += 1
        
        # === 信号检测 ===
        golden_cross = prev_fast <= prev_slow and curr_fast > curr_slow
        death_cross = prev_fast >= prev_slow and curr_fast < curr_slow
        
        # === 追踪止盈（持仓中时持续检查）===
        if self.current_position and atr > 0:
            trail_action = self._check_trailing_stop(current_price, atr)
            if trail_action:
                actions.append(trail_action)
                return actions
        
        # === 金叉信号 + 多重过滤 ===
        if golden_cross:
            reject_reasons = []
            if rsi <= 50:
                reject_reasons.append(f"RSI={rsi:.1f}≤50")
            if vol_ratio < self.vol_threshold:
                reject_reasons.append(f"缩量({vol_ratio:.1f}x<{self.vol_threshold}x)")
            if higher_trend == "bearish":
                reject_reasons.append(f"4H空头趋势")
            if ml_conf < 60:
                reject_reasons.append(f"ML置信度={ml_conf:.0f}<60")
            if self.sentiment and sentiment_score < 25:
                reject_reasons.append(f"情绪强看跌({sentiment_score:.0f})")
            
            if reject_reasons:
                print(f"🚫 金叉被过滤 | {' + '.join(reject_reasons)}")
                if self.notifier:
                    try:
                        self.notifier.send_signal_filtered("金叉", reject_reasons)
                    except Exception:
                        pass
            else:
                # v5: 最小持仓时间检查
                if self.current_position == "short" and self.bars_since_entry < self.min_hold_bars:
                    print(f"⏳ 金叉信号但持仓仅{self.bars_since_entry}/{self.min_hold_bars}根K线, 等待")
                elif self.current_position == "short":
                    actions.append(TradeAction(
                        signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                        price=current_price, size="0",
                        reason=f"金叉平空 | RSI={rsi:.1f}"
                    ))
                
                if self.current_position != "long":
                    balance = client.get_usdt_balance()
                    # 行情自适应仓位
                    if self.risk_manager:
                        pos_info = self.risk_manager.calc_adaptive_position(
                            balance=balance, atr=atr, price=current_price,
                            adx=adx, sentiment_score=sentiment_score,
                            ml_confidence=ml_conf, inst_id=self.inst_id
                        )
                        pos_pct = pos_info["size_pct"]
                    else:
                        pos_pct = self.position_pct
                    invest = balance * pos_pct * self.leverage
                    contract_val = client.get_contract_val(self.inst_id)
                    num_contracts = max(1, int(invest / (contract_val * current_price)))
                    
                    sl_price = round(current_price - atr * self.atr_sl_mult, 4)
                    tp_price = round(current_price + atr * self.atr_tp_mult, 4)
                    
                    actions.append(TradeAction(
                        signal=Signal.BUY, inst_id=self.inst_id,
                        price=current_price, size=str(num_contracts),
                        reason=f"金叉做多 | RSI={rsi:.1f} Vol={vol_ratio:.1f}x 4H={higher_trend} ML={ml_conf:.0f} ATR={atr:.5f}",
                        sl_price=sl_price, tp_price=tp_price,
                    ))
                    self.current_position = "long"
                    self.entry_price = current_price
                    self.highest_since_entry = current_price
                    self.trailing_active = False
                    self.trade_count += 1
                    self.bars_since_entry = 0  # v5: 重置持仓计数
                    self._auto_calibrate_ml()
                    print(f"🟢 金叉开多 | 价格={current_price} | RSI={rsi:.1f} | Vol={vol_ratio:.1f}x | "
                          f"4H={higher_trend} | ML={ml_conf:.0f} | ADX={adx:.0f} | "
                          f"情绪={sentiment_score:.0f} | "
                          f"仓位={pos_pct if self.risk_manager else self.position_pct:.0%} | SL={sl_price} TP={tp_price}")
        
        # === 死叉信号 + 多重过滤 ===
        elif death_cross:
            reject_reasons = []
            if rsi >= 50:
                reject_reasons.append(f"RSI={rsi:.1f}≥50")
            if vol_ratio < self.vol_threshold:
                reject_reasons.append(f"缩量({vol_ratio:.1f}x<{self.vol_threshold}x)")
            if higher_trend == "bullish":
                reject_reasons.append(f"4H多头趋势")
            if ml_conf < 60:
                reject_reasons.append(f"ML置信度={ml_conf:.0f}<60")
            if self.sentiment and sentiment_score > 75:
                reject_reasons.append(f"情绪强看涨({sentiment_score:.0f})")
            
            if reject_reasons:
                print(f"🚫 死叉被过滤 | {' + '.join(reject_reasons)}")
                if self.notifier:
                    try:
                        self.notifier.send_signal_filtered("死叉", reject_reasons)
                    except Exception:
                        pass
            else:
                # v5: 最小持仓时间检查
                if self.current_position == "long" and self.bars_since_entry < self.min_hold_bars:
                    print(f"⏳ 死叉信号但持仓仅{self.bars_since_entry}/{self.min_hold_bars}根K线, 等待")
                elif self.current_position == "long":
                    actions.append(TradeAction(
                        signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                        price=current_price, size="0",
                        reason=f"死叉平多 | RSI={rsi:.1f}"
                    ))
                
                if self.current_position != "short":
                    balance = client.get_usdt_balance()
                    # 行情自适应仓位
                    if self.risk_manager:
                        pos_info = self.risk_manager.calc_adaptive_position(
                            balance=balance, atr=atr, price=current_price,
                            adx=adx, sentiment_score=sentiment_score,
                            ml_confidence=ml_conf, inst_id=self.inst_id
                        )
                        pos_pct = pos_info["size_pct"]
                    else:
                        pos_pct = self.position_pct
                    invest = balance * pos_pct * self.leverage
                    contract_val = client.get_contract_val(self.inst_id)
                    num_contracts = max(1, int(invest / (contract_val * current_price)))
                    
                    sl_price = round(current_price + atr * self.atr_sl_mult, 4)
                    tp_price = round(current_price - atr * self.atr_tp_mult, 4)
                    
                    actions.append(TradeAction(
                        signal=Signal.SELL, inst_id=self.inst_id,
                        price=current_price, size=str(num_contracts),
                        reason=f"死叉做空 | RSI={rsi:.1f} Vol={vol_ratio:.1f}x 4H={higher_trend} ML={ml_conf:.0f} ATR={atr:.5f}",
                        sl_price=sl_price, tp_price=tp_price,
                    ))
                    self.current_position = "short"
                    self.entry_price = current_price
                    self.lowest_since_entry = current_price
                    self.trailing_active = False
                    self.trade_count += 1
                    self.bars_since_entry = 0  # v5: 重置持仓计数
                    self._auto_calibrate_ml()
                    print(f"🔴 死叉开空 | 价格={current_price} | RSI={rsi:.1f} | Vol={vol_ratio:.1f}x | "
                          f"4H={higher_trend} | ML={ml_conf:.0f} | ADX={adx:.0f} | "
                          f"情绪={sentiment_score:.0f} | "
                          f"仓位={pos_pct if self.risk_manager else self.position_pct:.0%} | SL={sl_price} TP={tp_price}")
        else:
            direction = "多头" if curr_fast > curr_slow else "空头"
            diff_pct = abs(curr_fast - curr_slow) / curr_slow * 100
            trail = "🎯追踪中" if self.trailing_active else ""
            print(f"⏸️ 无信号 | {direction} | 差距={diff_pct:.2f}% | RSI={rsi:.1f} | "
                  f"Vol={vol_ratio:.1f}x | ATR={atr:.5f} | 4H={higher_trend} | ADX={adx:.0f} | "
                  f"情绪={sentiment_score:.0f}{sentiment_label} {trail}")
        
        return actions
    
    def _calc_bb_width(self, closes: List[float], period: int = 20) -> float:
        """计算布林带宽度百分比, 用于挤压检测"""
        if len(closes) < period:
            return 1.0
        window = closes[-period:]
        sma = sum(window) / period
        if sma == 0:
            return 1.0
        variance = sum((p - sma) ** 2 for p in window) / period
        std = variance ** 0.5
        bb_width = (2 * std * 2) / sma  # (Upper - Lower) / SMA
        return bb_width

    def _reset_tp_state(self):
        """重置阶梯止盈状态"""
        self.tp_tier1_done = False
        self.tp_tier2_done = False
        self.remaining_pct = 1.0
        self.trailing_active = False

    def _check_trailing_stop(self, current_price: float, atr: float):
        """阶梯止盈 + 移动追踪止盈 + 浮盈保护止损
        
        阶梯逻辑:
          Tier 1: 浮盈 >= 2×ATR → 平 30%
          Tier 2: 浮盈 >= 3×ATR → 再平 30%
          剩余 40%: 追踪止盈管理
        """
        if self.current_position == "long":
            if current_price > self.highest_since_entry:
                self.highest_since_entry = current_price
            floating_profit = current_price - self.entry_price
            pct = (current_price - self.entry_price) / self.entry_price * 100
            
            # ─── 阶梯止盈 Tier 1: 浮盈 >= 2×ATR → 平 30% ───
            if not self.tp_tier1_done and floating_profit >= atr * self.tp_tier1_atr:
                self.tp_tier1_done = True
                close_ratio = self.tp_tier1_close
                self.remaining_pct -= close_ratio
                print(f"🎯 阶梯止盈T1(多) | 平{close_ratio:.0%} | 浮盈={pct:.2f}% | 剩余={self.remaining_pct:.0%}")
                return TradeAction(
                    signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                    price=current_price, size=f"PARTIAL:{close_ratio}",
                    reason=f"阶梯T1平多{close_ratio:.0%} | 盈利{pct:.2f}%"
                )
            
            # ─── 阶梯止盈 Tier 2: 浮盈 >= 3×ATR → 再平 30% ───
            if not self.tp_tier2_done and self.tp_tier1_done and floating_profit >= atr * self.tp_tier2_atr:
                self.tp_tier2_done = True
                close_ratio = self.tp_tier2_close
                self.remaining_pct -= close_ratio
                print(f"🎯 阶梯止盈T2(多) | 平{close_ratio:.0%} | 浮盈={pct:.2f}% | 剩余={self.remaining_pct:.0%}")
                return TradeAction(
                    signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                    price=current_price, size=f"PARTIAL:{close_ratio}",
                    reason=f"阶梯T2平多{close_ratio:.0%} | 盈利{pct:.2f}%"
                )
            
            # ─── 浮盈保护: 盈利>3ATR 后价格回到保本 → 全平 ───
            if floating_profit >= atr * 3 and current_price <= self.entry_price:
                self.current_position = None
                self._reset_tp_state()
                print(f"🛡️ 浮盈保护触发(多) | 保本平仓 | PNL={pct:.2f}%")
                return TradeAction(
                    signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                    price=current_price, size="0",
                    reason=f"浮盈保护平多 | 价格回到保本线"
                )
            
            # ─── 剩余仓位: 追踪止盈 ───
            if not self.trailing_active and floating_profit >= atr * self.atr_trail_activate:
                self.trailing_active = True
                print(f"🎯 追踪止盈激活(多) | 浮盈={floating_profit:.5f}")
            
            if self.trailing_active:
                trail_stop = self.highest_since_entry - atr * self.atr_trail_offset
                if floating_profit >= atr * 3:
                    trail_stop = max(trail_stop, self.entry_price)
                if current_price <= trail_stop:
                    self.current_position = None
                    self._reset_tp_state()
                    print(f"📈 追踪止盈触发(多) | 盈利={pct:.2f}%")
                    return TradeAction(
                        signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                        price=current_price, size="0",
                        reason=f"追踪止盈平多 | 盈利 {pct:.2f}%"
                    )
        
        elif self.current_position == "short":
            if current_price < self.lowest_since_entry:
                self.lowest_since_entry = current_price
            floating_profit = self.entry_price - current_price
            pct = (self.entry_price - current_price) / self.entry_price * 100
            
            # ─── 阶梯止盈 Tier 1 ───
            if not self.tp_tier1_done and floating_profit >= atr * self.tp_tier1_atr:
                self.tp_tier1_done = True
                close_ratio = self.tp_tier1_close
                self.remaining_pct -= close_ratio
                print(f"🎯 阶梯止盈T1(空) | 平{close_ratio:.0%} | 浮盈={pct:.2f}% | 剩余={self.remaining_pct:.0%}")
                return TradeAction(
                    signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                    price=current_price, size=f"PARTIAL:{close_ratio}",
                    reason=f"阶梯T1平空{close_ratio:.0%} | 盈利{pct:.2f}%"
                )
            
            # ─── 阶梯止盈 Tier 2 ───
            if not self.tp_tier2_done and self.tp_tier1_done and floating_profit >= atr * self.tp_tier2_atr:
                self.tp_tier2_done = True
                close_ratio = self.tp_tier2_close
                self.remaining_pct -= close_ratio
                print(f"🎯 阶梯止盈T2(空) | 平{close_ratio:.0%} | 浮盈={pct:.2f}% | 剩余={self.remaining_pct:.0%}")
                return TradeAction(
                    signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                    price=current_price, size=f"PARTIAL:{close_ratio}",
                    reason=f"阶梯T2平空{close_ratio:.0%} | 盈利{pct:.2f}%"
                )
            
            # ─── 浮盈保护 ───
            if floating_profit >= atr * 3 and current_price >= self.entry_price:
                self.current_position = None
                self._reset_tp_state()
                print(f"🛡️ 浮盈保护触发(空) | 保本平仓 | PNL={pct:.2f}%")
                return TradeAction(
                    signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                    price=current_price, size="0",
                    reason=f"浮盈保护平空 | 价格回到保本线"
                )
            
            # ─── 剩余仓位: 追踪止盈 ───
            if not self.trailing_active and floating_profit >= atr * self.atr_trail_activate:
                self.trailing_active = True
                print(f"🎯 追踪止盈激活(空) | 浮盈={floating_profit:.5f}")
            
            if self.trailing_active:
                trail_stop = self.lowest_since_entry + atr * self.atr_trail_offset
                if floating_profit >= atr * 3:
                    trail_stop = min(trail_stop, self.entry_price)
                if current_price >= trail_stop:
                    self.current_position = None
                    self._reset_tp_state()
                    print(f"📈 追踪止盈触发(空) | 盈利={pct:.2f}%")
                    return TradeAction(
                        signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                        price=current_price, size="0",
                        reason=f"追踪止盈平空 | 盈利 {pct:.2f}%"
                    )
        return None
    
    def get_status(self) -> dict:
        return {
            "策略": self.name + " (v2)",
            "交易对": self.inst_id,
            "K线": self.bar,
            "EMA": f"{self.prev_fast_ema:.4f}/{self.prev_slow_ema:.4f}" if self.prev_fast_ema else "N/A",
            "RSI": f"{self.current_rsi:.1f}" if self.current_rsi else "N/A",
            "ATR": f"{self.current_atr:.5f}" if self.current_atr else "N/A",
            "ATR倍数": f"SL:{self.atr_sl_mult}/TP:{self.atr_tp_mult}",
            "成交量比": f"{self.current_volume_ratio:.1f}x" if self.current_volume_ratio else "N/A",
            "4H趋势": self.higher_tf_trend or "N/A",
            "ML置信": f"{self.ml_confidence:.0f}" if self.ml_confidence else "N/A",
            "仓位": self.current_position or "无",
            "追踪": "已激活" if self.trailing_active else "未激活",
            "杠杆": f"{self.leverage}x",
            "交易计数": self.trade_count,
            "自适应ATR": "开" if self.adaptive_atr else "关",
            "情绪分析": "开" if self.sentiment else "关",
        }
