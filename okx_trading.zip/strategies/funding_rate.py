"""
资金费率套利策略
利用永续合约每 8 小时一次的资金费率结算赚取利息
"""
import time
import logging
from typing import List, Optional
from .base import BaseStrategy, Signal, TradeAction

logger = logging.getLogger(__name__)


class FundingRateStrategy(BaseStrategy):
    """
    资金费率套利策略
    
    原理：
    - 资金费率 > 0.1% 时做空（空头收取多头的利息）
    - 资金费率 < -0.1% 时做多（多头收取空头的利息）
    - 仅在均线策略无持仓时执行（避免净持仓模式下冲突）
    """
    
    def __init__(self, inst_id: str = "DOGE-USDT-SWAP",
                 leverage: int = 3,
                 position_pct: float = 0.15,
                 rate_threshold: float = 0.001):
        super().__init__("资金费率", inst_id)
        self.leverage = leverage
        self.position_pct = position_pct
        self.rate_threshold = rate_threshold
        self.current_position = None
        self.last_check_time = 0
        self.check_interval = 3600  # 每小时检查一次
        self.ma_strategy_ref = None  # 引用均线策略，检查其持仓状态
    
    def set_ma_strategy(self, ma_strategy):
        """设置均线策略引用，用于检查持仓冲突"""
        self.ma_strategy_ref = ma_strategy
    
    def _get_funding_rate(self, client) -> Optional[float]:
        """获取当前资金费率"""
        try:
            result = client._request("GET", "/api/v5/public/funding-rate", 
                                     params={"instId": self.inst_id})
            if result.get("code") == "0" and result.get("data"):
                return float(result["data"][0].get("fundingRate", "0"))
        except Exception as e:
            logger.error(f"获取资金费率失败: {e}")
        return None
    
    def analyze(self, client) -> List[TradeAction]:
        """检查资金费率并决定是否套利"""
        now = time.time()
        if now - self.last_check_time < self.check_interval:
            return []
        self.last_check_time = now
        
        # 检查均线策略是否有持仓（净持仓模式下避免冲突）
        if self.ma_strategy_ref and self.ma_strategy_ref.current_position:
            return []
        
        rate = self._get_funding_rate(client)
        if rate is None:
            return []
        
        logger.info(f"💰 资金费率: {rate*100:.4f}%")
        
        actions = []
        
        if rate > self.rate_threshold and self.current_position != "short":
            # 高费率 → 做空吃利息
            if self.current_position == "long":
                actions.append(TradeAction(
                    signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                    price=0, size="0",
                    reason=f"费率套利-平多 | 费率={rate*100:.4f}%"
                ))
            
            balance = client.get_usdt_balance()
            invest = balance * self.position_pct * self.leverage
            contract_val = client.get_contract_val(self.inst_id)
            current_price = client.get_current_price(self.inst_id)
            if current_price:
                num = max(1, int(invest / (contract_val * current_price)))
                actions.append(TradeAction(
                    signal=Signal.SELL, inst_id=self.inst_id,
                    price=0, size=str(num),
                    reason=f"费率套利-做空 | 费率={rate*100:.4f}% (>0.1%)"
                ))
                self.current_position = "short"
                logger.info(f"💰 费率套利: 做空吃费率 {rate*100:.4f}%")
        
        elif rate < -self.rate_threshold and self.current_position != "long":
            # 低费率 → 做多吃利息
            if self.current_position == "short":
                actions.append(TradeAction(
                    signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                    price=0, size="0",
                    reason=f"费率套利-平空 | 费率={rate*100:.4f}%"
                ))
            
            balance = client.get_usdt_balance()
            invest = balance * self.position_pct * self.leverage
            contract_val = client.get_contract_val(self.inst_id)
            current_price = client.get_current_price(self.inst_id)
            if current_price:
                num = max(1, int(invest / (contract_val * current_price)))
                actions.append(TradeAction(
                    signal=Signal.BUY, inst_id=self.inst_id,
                    price=0, size=str(num),
                    reason=f"费率套利-做多 | 费率={rate*100:.4f}% (<-0.1%)"
                ))
                self.current_position = "long"
                logger.info(f"💰 费率套利: 做多吃费率 {rate*100:.4f}%")
        
        elif abs(rate) < self.rate_threshold * 0.5 and self.current_position:
            # 费率回归中性 → 平仓走人
            if self.current_position == "long":
                actions.append(TradeAction(
                    signal=Signal.CLOSE_LONG, inst_id=self.inst_id,
                    price=0, size="0",
                    reason=f"费率回归-平多 | 费率={rate*100:.4f}%"
                ))
            elif self.current_position == "short":
                actions.append(TradeAction(
                    signal=Signal.CLOSE_SHORT, inst_id=self.inst_id,
                    price=0, size="0",
                    reason=f"费率回归-平空 | 费率={rate*100:.4f}%"
                ))
            self.current_position = None
        
        return actions
    
    def get_status(self) -> dict:
        return {
            "策略": self.name,
            "交易对": self.inst_id,
            "持仓": self.current_position or "无",
            "杠杆": f"{self.leverage}x",
            "费率阈值": f"±{self.rate_threshold*100:.2f}%",
        }
