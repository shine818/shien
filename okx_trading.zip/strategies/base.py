"""
策略基类
所有交易策略的抽象基类，定义统一接口
"""
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List
from enum import Enum


class Signal(Enum):
    """交易信号"""
    BUY = "buy"           # 买入/做多
    SELL = "sell"         # 卖出/做空
    CLOSE_LONG = "close_long"   # 平多
    CLOSE_SHORT = "close_short" # 平空
    HOLD = "hold"         # 持有/观望


class TradeAction:
    """交易动作"""
    def __init__(self, signal: Signal, inst_id: str, price: float = 0,
                 size: str = "1", reason: str = "", sl_price: float = 0,
                 tp_price: float = 0):
        self.signal = signal
        self.inst_id = inst_id
        self.price = price
        self.size = size
        self.reason = reason
        self.sl_price = sl_price  # 止损价
        self.tp_price = tp_price  # 止盈价
    
    def __repr__(self):
        return (f"TradeAction({self.signal.value}, {self.inst_id}, "
                f"price={self.price}, size={self.size}, reason='{self.reason}')")


class BaseStrategy(ABC):
    """策略基类"""
    
    def __init__(self, name: str, inst_id: str = "BTC-USDT-SWAP"):
        self.name = name
        self.inst_id = inst_id
        self.is_running = False
        self._last_signal = Signal.HOLD
    
    @abstractmethod
    def analyze(self, client) -> List[TradeAction]:
        """
        分析市场数据，返回交易动作列表
        
        Args:
            client: OKXClient 实例
            
        Returns:
            交易动作列表，如果无操作返回空列表
        """
        pass
    
    @abstractmethod
    def get_status(self) -> dict:
        """获取策略状态"""
        pass
    
    def start(self):
        """启动策略"""
        self.is_running = True
        print(f"📊 策略 [{self.name}] 已启动 | 交易对: {self.inst_id}")
    
    def stop(self):
        """停止策略"""
        self.is_running = False
        print(f"⏹️ 策略 [{self.name}] 已停止")
