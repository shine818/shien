import numpy as np
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class PositionInfo:
    symbol: str
    direction: int       # +1 long, -1 short
    size_usdt: float
    entry_price: float
    stop_loss: float

class PortfolioRiskManager:
    """
    多币种组合风险管理：相关性压缩与组合 VaR
    """
    def __init__(self, max_portfolio_risk_pct=0.06, corr_window=60, corr_high_threshold=0.75):
        self.max_portfolio_risk_pct = max_portfolio_risk_pct
        self.corr_window = corr_window
        self.corr_high_threshold = corr_high_threshold
        self.price_history: dict[str, deque] = {}
        self.positions: dict[str, PositionInfo] = {}

    def update_price(self, symbol: str, price: float):
        if symbol not in self.price_history:
            self.price_history[symbol] = deque(maxlen=self.corr_window)
        self.price_history[symbol].append(price)

    def add_position(self, pos: PositionInfo):
        self.positions[pos.symbol] = pos

    def remove_position(self, symbol: str):
        self.positions.pop(symbol, None)

    def get_correlation(self, sym_a: str, sym_b: str) -> Optional[float]:
        hist_a = self.price_history.get(sym_a)
        hist_b = self.price_history.get(sym_b)
        if not hist_a or not hist_b or len(hist_a) < 20 or len(hist_b) < 20:
            return None
        min_len = min(len(hist_a), len(hist_b))
        arr_a = np.array(list(hist_a)[-min_len:])
        arr_b = np.array(list(hist_b)[-min_len:])
        ret_a = np.diff(np.log(arr_a))
        ret_b = np.diff(np.log(arr_b))
        if np.std(ret_a) == 0 or np.std(ret_b) == 0:
            return None
        return float(np.corrcoef(ret_a, ret_b)[0, 1])

    def get_position_scale_factor(self, new_symbol: str, new_direction: int, total_equity: float) -> dict:
        if not self.positions:
            return {"scale": 1.0, "reason": "no_existing_positions"}
        max_overlap_penalty = 0.0
        for symbol, pos in self.positions.items():
            if symbol == new_symbol: continue
            corr = self.get_correlation(new_symbol, symbol)
            if corr is None: corr = 0.8  # 保守假设
            effective_corr = corr * (new_direction * pos.direction)
            if effective_corr > self.corr_high_threshold:
                penalty = (effective_corr - self.corr_high_threshold) / (1 - self.corr_high_threshold)
                max_overlap_penalty = max(max_overlap_penalty, penalty)
        scale = max(0.40, 1.0 - max_overlap_penalty * 0.6)
        return {"scale": round(scale, 3), "reason": "correlation_adjusted" if max_overlap_penalty > 0 else "independent"}

    def check_portfolio_var(self, total_equity: float, new_position_risk_usdt: float = 0.0) -> dict:
        total_risk_usdt = new_position_risk_usdt
        for pos in self.positions.values():
            single_risk = abs(pos.entry_price - pos.stop_loss) / pos.entry_price * pos.size_usdt
            total_risk_usdt += single_risk
        
        if len(self.positions) > 1:
            symbols = list(self.positions.keys())
            corrs = []
            for i in range(len(symbols)):
                for j in range(i+1, len(symbols)):
                    c = self.get_correlation(symbols[i], symbols[j])
                    if c is not None: corrs.append(abs(c))
            if corrs:
                total_risk_usdt *= (1.0 + np.mean(corrs) * 0.25)

        risk_pct = total_risk_usdt / total_equity if total_equity > 0 else 0
        return {"allow": risk_pct <= self.max_portfolio_risk_pct, "portfolio_risk_pct": round(risk_pct, 4), "portfolio_risk_usdt": round(total_risk_usdt, 2)}
