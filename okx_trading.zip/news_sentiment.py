"""
新闻 & 宏观情绪分析模块 (News Sentiment)
接入外部信息面数据, 为交易策略提供新闻层面的方向参考

数据源:
1. Crypto Fear & Greed Index — 加密市场恐惧/贪婪指数 (0-100)
2. CoinGecko 价格变化 — BTC/ETH 大盘走势作为风向标
3. 关键词情绪分析 — 从 OKX 公告检测重大事件
4. BlockBeats 快讯 — 实时加密行业快讯情绪分析

输出: 0-100 评分 (>60 利好, <40 利空, 40-60 中性)
"""
import time
import logging
import re
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# ─── BlockBeats 快讯关键词权重 ───

BULLISH_KEYWORDS = [
    # 强利好 (+3)
    ("etf获批", 3), ("etf approved", 3), ("etf通过", 3),
    ("降息", 3), ("rate cut", 3), ("利率下调", 3),
    ("战略储备", 3), ("strategic reserve", 3),
    ("大规模采购", 3), ("大额买入", 3),
    # 中利好 (+2)
    ("利好", 2), ("突破", 2), ("新高", 2), ("ath", 2),
    ("合作", 2), ("partnership", 2), ("采用", 2), ("adoption", 2),
    ("机构买入", 2), ("institutional", 2), ("获投资", 2),
    ("上线", 2), ("launch", 2), ("升级", 2), ("upgrade", 2),
    ("减半", 2), ("halving", 2),
    # 弱利好 (+1)
    ("反弹", 1), ("看涨", 1), ("bullish", 1), ("上涨", 1),
    ("增长", 1), ("回升", 1), ("买入", 1), ("流入", 1), ("inflow", 1),
]

BEARISH_KEYWORDS = [
    # 强利空 (-3)
    ("黑客攻击", -3), ("hacked", -3), ("被盗", -3), ("exploit", -3),
    ("跑路", -3), ("rug pull", -3), ("崩盘", -3), ("crash", -3),
    ("sec起诉", -3), ("sec charges", -3), ("监管打击", -3),
    ("加息", -3), ("rate hike", -3),
    # 中利空 (-2)
    ("利空", -2), ("暴跌", -2), ("清算", -2), ("liquidat", -2),
    ("下架", -2), ("delist", -2), ("禁止", -2), ("ban", -2),
    ("罚款", -2), ("fine", -2), ("诉讼", -2), ("lawsuit", -2),
    ("漏洞", -2), ("vulnerability", -2),
    # 弱利空 (-1)
    ("下跌", -1), ("看跌", -1), ("bearish", -1), ("回调", -1),
    ("流出", -1), ("outflow", -1), ("抛售", -1), ("sell-off", -1),
    ("恐慌", -1), ("fear", -1), ("警告", -1), ("warning", -1),
]


class NewsSentiment:
    """新闻 & 宏观情绪分析"""

    def __init__(self, proxy: dict = None, cache_seconds: int = 900,
                 blockbeats_api_key: str = None):
        """
        proxy: 代理配置 {"http": ..., "https": ...}
        cache_seconds: 缓存时间 (默认 15 分钟, 新闻不需要太频繁)
        blockbeats_api_key: BlockBeats API Key
        """
        self.proxy = proxy or {}
        self.cache_seconds = cache_seconds
        self.blockbeats_api_key = blockbeats_api_key or ""
        self._cache = {}  # {"fear_greed": {...}, "btc_trend": {...}, ...}

        import requests
        self._requests = requests
        self.session = self._build_session()

    def _build_session(self):
        """创建/重建 HTTP Session"""
        s = self._requests.Session()
        if self.proxy:
            s.proxies = self.proxy
        s.headers.update({"User-Agent": "OKX-Trading-Bot/1.0"})
        return s

    def _rebuild_session(self):
        """代理断线后重建 Session"""
        self.session = self._build_session()
        logger.debug("🔄 NewsSentiment Session 已重建")

    def _safe_get(self, url, params=None, timeout=10):
        """带重试+Session重建的 GET 请求 (最多重试2次)"""
        import time as _t
        for attempt in range(3):
            try:
                resp = self.session.get(url, params=params, timeout=timeout)
                return resp
            except (OSError, self._requests.exceptions.ConnectionError,
                    self._requests.exceptions.ProxyError,
                    self._requests.exceptions.Timeout) as e:
                if attempt < 2:
                    logger.debug(f"⚠️ 网络重试 [{url[:50]}] ({attempt+1}/3): {type(e).__name__}")
                    self._rebuild_session()
                    _t.sleep(2)
                    continue
                raise

    def _is_cached(self, key: str) -> bool:
        c = self._cache.get(key)
        return c and (time.time() - c["time"]) < self.cache_seconds

    # ─── 1. Fear & Greed Index ───

    def get_fear_greed(self) -> Dict:
        """
        加密市场恐惧贪婪指数 (alternative.me)
        0-24: 极度恐惧 → 逆向做多
        25-49: 恐惧
        50-74: 贪婪
        75-100: 极度贪婪 → 逆向做空
        """
        if self._is_cached("fear_greed"):
            return self._cache["fear_greed"]["data"]

        try:
            resp = self._safe_get(
                "https://api.alternative.me/fng/?limit=1&format=json",
                timeout=10
            )
            data = resp.json()
            if "data" not in data or not data["data"]:
                return {"score": 50, "label": "N/A", "signal": 0}

            fng = data["data"][0]
            value = int(fng["value"])
            label = fng["value_classification"]

            # 逆向思维: 极度恐惧时反而看涨, 极度贪婪时反而看跌
            if value <= 15:
                signal = 25   # 极度恐惧 → 强烈看涨
            elif value <= 25:
                signal = 15   # 恐惧 → 看涨
            elif value <= 40:
                signal = 5
            elif value <= 60:
                signal = 0    # 中性
            elif value <= 75:
                signal = -5
            elif value <= 85:
                signal = -15  # 贪婪 → 看跌
            else:
                signal = -25  # 极度贪婪 → 强烈看跌

            result = {
                "score": value,
                "label": label,
                "signal": signal,
                "interpretation": self._fng_label(value)
            }

            self._cache["fear_greed"] = {"time": time.time(), "data": result}
            logger.info(f"📰 Fear & Greed: {value} ({label}) → signal={signal:+d}")
            return result

        except Exception as e:
            logger.warning(f"Fear & Greed 获取失败: {e}")
            return {"score": 50, "label": "N/A", "signal": 0}

    @staticmethod
    def _fng_label(value: int) -> str:
        if value <= 15:
            return "🔴 极度恐惧 (逆向看涨)"
        elif value <= 25:
            return "🟠 恐惧 (偏看涨)"
        elif value <= 45:
            return "🟡 偏恐惧"
        elif value <= 55:
            return "⚪ 中性"
        elif value <= 75:
            return "🟡 偏贪婪"
        elif value <= 85:
            return "🟠 贪婪 (偏看跌)"
        else:
            return "🔴 极度贪婪 (逆向看跌)"

    # ─── 2. BTC 大盘走势 ───

    def get_btc_trend(self) -> Dict:
        """
        BTC 作为大盘风向标
        - BTC 24h 涨 > 3% → 整体看涨
        - BTC 24h 跌 > 3% → 整体看跌
        用 CoinGecko 公开 API (无需 key)
        """
        if self._is_cached("btc_trend"):
            return self._cache["btc_trend"]["data"]

        try:
            resp = self._safe_get(
                "https://api.coingecko.com/api/v3/simple/price"
                "?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true",
                timeout=10
            )
            data = resp.json()

            btc_change = data.get("bitcoin", {}).get("usd_24h_change", 0)
            eth_change = data.get("ethereum", {}).get("usd_24h_change", 0)
            btc_price = data.get("bitcoin", {}).get("usd", 0)

            # BTC 涨跌信号
            if btc_change > 5:
                signal = 20
            elif btc_change > 3:
                signal = 12
            elif btc_change > 1:
                signal = 5
            elif btc_change < -5:
                signal = -20
            elif btc_change < -3:
                signal = -12
            elif btc_change < -1:
                signal = -5
            else:
                signal = 0

            result = {
                "btc_price": round(btc_price, 0),
                "btc_24h": round(btc_change, 2),
                "eth_24h": round(eth_change, 2),
                "signal": signal,
                "interpretation": f"BTC {btc_change:+.1f}% | ETH {eth_change:+.1f}%"
            }

            self._cache["btc_trend"] = {"time": time.time(), "data": result}
            logger.info(f"📰 大盘: BTC ${btc_price:.0f} ({btc_change:+.1f}%) "
                        f"ETH ({eth_change:+.1f}%) → signal={signal:+d}")
            return result

        except Exception as e:
            logger.warning(f"BTC 大盘数据获取失败: {e}")
            return {"btc_price": 0, "btc_24h": 0, "eth_24h": 0, "signal": 0}

    # ─── 3. 重大事件关键词检测 ───

    def get_event_signal(self) -> Dict:
        """
        通过 OKX 系统状态 API 检测维护/停机等重大事件
        维护期间不宜交易
        """
        if self._is_cached("event"):
            return self._cache["event"]["data"]

        try:
            resp = self._safe_get(
                "https://www.okx.com/api/v5/system/status",
                timeout=10
            )
            data = resp.json()

            if data.get("code") != "0":
                return {"signal": 0, "events": [], "warning": False}

            events = data.get("data", [])
            active_events = []
            warning = False

            for ev in events:
                state = ev.get("state", "")
                title = ev.get("title", "")
                if state in ("ongoing", "scheduled"):
                    active_events.append(title)
                    if any(kw in title.lower() for kw in
                           ["suspend", "maintenance", "upgrade", "halt"]):
                        warning = True

            signal = -20 if warning else 0

            result = {
                "signal": signal,
                "events": active_events[:3],  # 最多 3 条
                "warning": warning,
                "interpretation": f"⚠️ 维护中: {active_events[0]}" if warning else "✅ 正常"
            }

            self._cache["event"] = {"time": time.time(), "data": result}
            if warning:
                logger.warning(f"📰 交易所维护: {active_events}")
            return result

        except Exception as e:
            logger.warning(f"事件检测失败: {e}")
            return {"signal": 0, "events": [], "warning": False}

    # ─── 4. BlockBeats 快讯情绪 ───

    def get_blockbeats_signal(self) -> Dict:
        """
        BlockBeats 快讯实时情绪分析
        拉取最近 20 条重要快讯, 用关键词权重分析多空情绪
        输出 signal: -30 ~ +30
        """
        if self._is_cached("blockbeats"):
            return self._cache["blockbeats"]["data"]

        if not self.blockbeats_api_key:
            return {"signal": 0, "news_count": 0, "headlines": [],
                    "interpretation": "❌ 无 API Key"}

        try:
            resp = self._safe_get(
                "https://api.theblockbeats.news/v1/open-api/open-flash",
                params={
                    "size": "20",
                    "page": "1",
                    "type": "push",      # 重要快讯
                    "lang": "cn",
                    "api_key": self.blockbeats_api_key,
                },
                timeout=15
            )
            data = resp.json()

            if data.get("status") != 0 and data.get("status") != "0":
                logger.warning(f"BlockBeats API 返回异常: {data.get('message', 'unknown')}")
                return {"signal": 0, "news_count": 0, "headlines": [],
                        "interpretation": f"⚠️ API 错误: {data.get('message', '')}"}

            flash_list = []
            data_obj = data.get("data", {})
            if isinstance(data_obj, dict):
                flash_list = data_obj.get("data", [])
            elif isinstance(data_obj, list):
                flash_list = data_obj

            if not flash_list:
                return {"signal": 0, "news_count": 0, "headlines": [],
                        "interpretation": "📰 暂无快讯"}

            # 分析每条快讯的情绪
            total_score = 0
            headlines = []
            now_ts = time.time()

            for flash in flash_list[:20]:
                title = flash.get("title", "")
                content = flash.get("content", "")
                create_time = flash.get("create_time", "")

                # 合并标题+内容做关键词匹配
                text = (title + " " + content).lower()

                # 时间衰减: 超过 6 小时的快讯权重减半
                try:
                    flash_ts = int(create_time) if create_time else 0
                    age_hours = (now_ts - flash_ts) / 3600 if flash_ts > 0 else 0
                    decay = 0.5 if age_hours > 6 else 1.0
                except (ValueError, TypeError):
                    decay = 1.0

                # 关键词匹配
                flash_score = 0
                for keyword, weight in BULLISH_KEYWORDS:
                    if keyword in text:
                        flash_score += weight
                for keyword, weight in BEARISH_KEYWORDS:
                    if keyword in text:
                        flash_score += weight  # weight 已经是负数

                flash_score *= decay
                total_score += flash_score

                if title and len(headlines) < 5:
                    emoji = "🟢" if flash_score > 0 else ("🔴" if flash_score < 0 else "⚪")
                    headlines.append(f"{emoji} {title[:40]}")

            # 限制信号范围 [-30, +30]
            signal = max(-30, min(30, total_score))

            result = {
                "signal": round(signal, 1),
                "news_count": len(flash_list),
                "raw_score": round(total_score, 1),
                "headlines": headlines,
                "interpretation": self._bb_label(signal)
            }

            self._cache["blockbeats"] = {"time": time.time(), "data": result}
            logger.info(f"📰 BlockBeats: {len(flash_list)}条快讯 → "
                        f"signal={signal:+.1f} | {result['interpretation']}")
            if headlines:
                for h in headlines[:3]:
                    logger.info(f"   {h}")
            return result

        except Exception as e:
            logger.warning(f"BlockBeats 快讯获取失败: {e}")
            return {"signal": 0, "news_count": 0, "headlines": [],
                    "interpretation": f"⚠️ 请求失败"}

    @staticmethod
    def _bb_label(signal: float) -> str:
        if signal >= 15:
            return "📈 快讯强利好"
        elif signal >= 5:
            return "📈 快讯偏利好"
        elif signal >= -5:
            return "➡️ 快讯中性"
        elif signal >= -15:
            return "📉 快讯偏利空"
        else:
            return "📉 快讯强利空"

    # ─── 综合新闻评分 ───

    def analyze(self) -> Dict:
        """
        综合新闻情绪分析:
        - Fear & Greed: 25% (逆向指标)
        - BTC 大盘走势: 30% (顺势)
        - 重大事件: 15% (风险)
        - BlockBeats 快讯: 30% (实时信息面)

        无 BlockBeats 时回退到旧权重:
        - Fear & Greed: 40%, BTC: 40%, 事件: 20%

        输出 0-100, >60 利好, <40 利空
        """
        fng = self.get_fear_greed()
        btc = self.get_btc_trend()
        event = self.get_event_signal()
        bb = self.get_blockbeats_signal()

        if self.blockbeats_api_key and bb.get("news_count", 0) > 0:
            # 有 BlockBeats 数据: 4 源加权
            raw = (fng["signal"] * 0.25 +
                   btc["signal"] * 0.30 +
                   event["signal"] * 0.15 +
                   bb["signal"] * 0.30)
        else:
            # 无 BlockBeats: 回退旧权重
            raw = (fng["signal"] * 0.40 +
                   btc["signal"] * 0.40 +
                   event["signal"] * 0.20)

        score = max(0, min(100, 50 + raw))

        direction = "bullish" if score > 60 else ("bearish" if score < 40 else "neutral")

        result = {
            "score": round(score, 1),
            "direction": direction,
            "fear_greed": fng,
            "btc_trend": btc,
            "event": event,
            "blockbeats": bb,
            "label": self._score_label(score)
        }

        bb_info = f" | BB={bb['signal']:+.0f}({bb['news_count']}条)" if bb.get("news_count", 0) > 0 else ""
        logger.info(f"📰 新闻情绪综合: {result['label']} (score={score:.0f}) | "
                    f"F&G={fng['score']} | BTC={btc.get('btc_24h', 0):+.1f}% | "
                    f"事件={'⚠️' if event['warning'] else '✅'}{bb_info}")

        return result

    @staticmethod
    def _score_label(score: float) -> str:
        if score >= 70:
            return "📈 强利好"
        elif score >= 60:
            return "📈 偏利好"
        elif score >= 45:
            return "➡️ 中性"
        elif score >= 35:
            return "📉 偏利空"
        else:
            return "📉 强利空"

    def should_pause_trading(self) -> tuple:
        """
        是否应该暂停交易:
        - 交易所维护 → 暂停
        - 极端恐惧/贪婪 + BTC 大跌 → 暂停
        - BlockBeats 检测到极端利空 → 暂停
        返回 (should_pause, reason)
        """
        event = self.get_event_signal()
        if event["warning"]:
            return True, f"交易所维护中: {event['events'][0] if event['events'] else '未知'}"

        fng = self.get_fear_greed()
        btc = self.get_btc_trend()

        # BTC 暴跌 > 8% + 极度恐惧 → 暂停 (可能是黑天鹅)
        if btc.get("btc_24h", 0) < -8 and fng.get("score", 50) < 15:
            return True, f"黑天鹅预警: BTC {btc['btc_24h']:+.1f}%, Fear={fng['score']}"

        # BlockBeats 检测到极端利空 (signal <= -20) + BTC 暴跌
        bb = self.get_blockbeats_signal()
        if bb.get("signal", 0) <= -20 and btc.get("btc_24h", 0) < -5:
            top_news = bb.get("headlines", [""])[0] if bb.get("headlines") else ""
            return True, f"快讯极端利空+BTC暴跌: BB={bb['signal']:+.0f}, BTC={btc['btc_24h']:+.1f}% | {top_news}"

        return False, ""

    def get_status(self) -> dict:
        """当前状态摘要"""
        fng = self.get_fear_greed()
        btc = self.get_btc_trend()
        bb = self.get_blockbeats_signal()
        analysis = self.analyze()
        status = {
            "新闻情绪": analysis["label"],
            "恐惧贪婪": f"{fng['score']} ({fng.get('label', 'N/A')})",
            "BTC走势": f"${btc.get('btc_price', 0):.0f} ({btc.get('btc_24h', 0):+.1f}%)",
            "综合评分": f"{analysis['score']:.0f}/100",
        }
        if bb.get("news_count", 0) > 0:
            status["BlockBeats"] = f"{bb['interpretation']} ({bb['news_count']}条)"
        return status
