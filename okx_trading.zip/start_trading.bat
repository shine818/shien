@echo off
chcp 65001 >nul
title OKX Trading System - Watchdog
echo ============================================
echo   OKX 自动交易系统 · 一键启动
echo   看门狗模式 (崩溃自动重启 + WebSocket实时行情 + 防休眠)
echo ============================================
echo.

cd /d "%~dp0"

:: 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python 未安装! 请先安装 Python
    pause
    exit /b 1
)

:: 检查依赖
echo [1/3] 检查依赖...
python -m pip install requests flask websocket-client -q 2>nul
if errorlevel 1 (
    echo ❌ 依赖安装失败, 请检查 Python / pip 环境
    pause
    exit /b 1
)

:: 检查配置文件
echo [2/3] 检查配置...
if not exist "config.json" (
    echo ❌ config.json 不存在!
    pause
    exit /b 1
)

:: 启动看门狗
echo [3/3] 启动看门狗...
echo.
echo 💡 按 Ctrl+C 可安全停止
echo 💡 仪表盘: http://localhost:5000
echo 💡 模式: Watchdog + WebSocket 实时行情
echo.

python watchdog.py --strategy both

:: 如果退出了
echo.
echo ⚠️ 看门狗已退出
pause
