"""
ML 信号增强模块
简单的逻辑回归模型，输出 0-100 的置信度分数
用于辅助均线策略的开仓决策（分数>60才允许开仓）
"""
import os
import csv
import json
import logging
import math

logger = logging.getLogger(__name__)


class MLSignalScorer:
    """
    轻量级 ML 信号评分器
    
    使用加权逻辑回归模型 (无需外部ML库)
    输入: RSI, ATR (归一化), EMA差值, 成交量比率
    输出: 0-100 的置信度分数
    
    权重通过经验法则预设，后续可通过回测数据校准
    """
    
    def __init__(self, weights_path: str = "ml_weights.json"):
        # 默认权重 (基于技术分析经验法则)
        self.weights = {
            "rsi_weight": 0.30,       # RSI 在趋势方向上的强度
            "volume_weight": 0.25,    # 放量程度
            "ema_diff_weight": 0.25,  # 均线发散程度
            "momentum_weight": 0.20,  # 动量方向一致性
        }
        
        # 尝试加载训练过的权重
        self._load_weights(weights_path)
        logger.info(f"🤖 ML 评分器已初始化 (权重: {self.weights})")
    
    def _load_weights(self, path: str):
        """加载训练过的权重文件"""
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    loaded = json.load(f)
                    self.weights.update(loaded)
                    logger.info(f"📦 已加载训练权重: {path}")
        except Exception as e:
            logger.warning(f"⚠️ 加载权重失败，使用默认值: {e}")
    
    def save_weights(self, path: str = "ml_weights.json"):
        """保存当前权重"""
        with open(path, "w") as f:
            json.dump(self.weights, f, indent=2)
    
    @staticmethod
    def _sigmoid(x: float) -> float:
        """Sigmoid 激活函数"""
        try:
            return 1 / (1 + math.exp(-x))
        except OverflowError:
            return 0.0 if x < 0 else 1.0
    
    def predict_confidence(self, rsi: float, atr: float, 
                          ema_diff: float, volume_ratio: float, direction: str = "long") -> float:
        """
        预测信号置信度 (0-100)
        
        高分条件:
        - RSI 远离 50 (趋势明确)
        - 成交量放大 (>1.3x)
        - EMA 差值增大 (趋势发散)
        - 所有指标方向一致
        """
        if direction == "short":
            rsi = 100 - rsi
            ema_diff = -ema_diff

        # 1. RSI 分数: 距离50越远越好 (多头: RSI>50越高越好, 空头: RSI<50越低越好)
        rsi_score = abs(rsi - 50) / 50  # 0-1
        
        # 2. 成交量分数: 放量越多越好
        vol_score = min(1.0, max(0, (volume_ratio - 0.8) / 1.2))  # 0.8x→0, 2.0x→1
        
        # 3. EMA 差值分数: 差距越大动能越强
        # 归一化: 用 ATR 作为参考尺度
        if atr > 0:
            ema_norm = min(1.0, abs(ema_diff) / (atr * 3))
        else:
            ema_norm = 0.5
        
        # 4. 动量一致性: RSI方向 和 EMA方向 一致则加分
        rsi_bullish = rsi > 50
        ema_bullish = ema_diff > 0
        momentum_score = 1.0 if rsi_bullish == ema_bullish else 0.3
        
        # 加权求和
        raw_score = (
            rsi_score * self.weights["rsi_weight"] +
            vol_score * self.weights["volume_weight"] +
            ema_norm * self.weights["ema_diff_weight"] +
            momentum_score * self.weights["momentum_weight"]
        )
        
        # Sigmoid 映射到 0-100
        confidence = self._sigmoid((raw_score - 0.45) * 8) * 100
        
        return round(confidence, 1)
    
    def calibrate_from_trades(self, trades_csv: str = "trades.csv"):
        """
        根据历史交易记录校准权重 (简化版梯度下降)
        需要 trades.csv 中有足够多的记录
        """
        try:
            if not os.path.exists(trades_csv):
                logger.warning("⚠️ 无交易记录，无法校准")
                return
            
            with open(trades_csv, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                records = list(reader)
            
            if len(records) < 10:
                logger.info(f"📊 交易记录不足 ({len(records)}/10)，暂不校准")
                return
            
            # 统计盈利/亏损交易的平均指标值，据此调整权重
            # (简化版: 对盈利交易中高值的指标给予更高权重)
            logger.info(f"🔧 正在用 {len(records)} 条交易记录校准 ML 权重...")
            
            wins = [r for r in records if float(r.get("pnl_pct", 0)) > 0]
            
            if wins:
                avg_vol = sum(float(w.get("vol_ratio", 1)) for w in wins) / len(wins)
                # 如果盈利交易中平均放量较大，增加成交量权重
                if avg_vol > 1.5:
                    self.weights["volume_weight"] = min(0.40, self.weights["volume_weight"] + 0.02)
                
                self.save_weights()
                logger.info(f"✅ ML 权重已校准: {self.weights}")
        
        except Exception as e:
            logger.error(f"校准失败: {e}")


if __name__ == "__main__":
    scorer = MLSignalScorer()
    # 测试
    print(f"多头强信号: {scorer.predict_confidence(rsi=65, atr=0.001, ema_diff=0.002, volume_ratio=1.8)}")
    print(f"空头强信号: {scorer.predict_confidence(rsi=35, atr=0.001, ema_diff=-0.002, volume_ratio=1.5)}")
    print(f"弱信号: {scorer.predict_confidence(rsi=52, atr=0.001, ema_diff=0.0001, volume_ratio=0.9)}")
    print(f"矛盾信号: {scorer.predict_confidence(rsi=30, atr=0.001, ema_diff=0.002, volume_ratio=0.7)}")
