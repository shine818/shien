@echo off
chcp 65001 >nul
title OKX Trading System - Standard Launcher
echo ============================================
echo   OKX 自动交易系统 · 标准启动器 v2.0
echo   统一入口: Watchdog + WebSocket 实时行情
echo ============================================
echo.

cd /d "%~dp0"

:: ─── 检查 Python ───
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] Python 未安装! 请先安装 Python 3.8+
    pause
    exit /b 1
)

:: ─── 安装依赖 ───
echo [1/4] 检查/安装依赖...
python -m pip install requests flask websocket-client psutil -q 2>nul
if errorlevel 1 (
    echo [错误] 依赖安装失败，请检查 Python/pip 环境
    pause
    exit /b 1
)
echo       依赖检查完成

:: ─── 检查配置文件 ───
echo [2/4] 检查配置...
if not exist "config.json" (
    echo [错误] config.json 不存在!
    echo        请确保配置文件在当前目录
    pause
    exit /b 1
)

:: 检查 dry_run 模式
findstr /C "\"dry_run\": true" config.json >nul 2>&1
if not errorlevel 1 (
    echo       模式: [模拟交易 DRY-RUN]
    set "MODE_STR=模拟交易"
) else (
    findstr /C "\"dry_run\": false" config.json >nul 2>&1
    if not errorlevel 1 (
        echo       模式: [实盘交易 REAL]
    ) else (
        echo [警告] 无法确认模式，默认模拟交易
    )
)

:: ─── 检查 watchdog 进程 ───
echo [3/4] 检查运行状态...
tasklist /FI "IMAGENAME eq python.exe" 2>nul | findstr "watchdog" >nul 2>&1
if not errorlevel 1 (
    echo       发现 watchdog 进程正在运行
    echo.
    choice /C YN /M "是否重启? (Y=重启, N=退出)"
    if errorlevel 1 (
        echo       使用现有进程，退出
        timeout /t 2 >nul
        exit /b 0
    )
    echo       终止现有进程...
    taskkill /FI "WINDOWTITLE eq *watchdog*" /F 2>nul
    timeout /t 2 >nul
)

:: ─── 启动看门狗 ───
echo [4/4] 启动系统...
echo.
echo ============================================
echo   启动参数
echo ============================================
echo   启动模式: Watchdog 守护进程
echo   行情模式: WebSocket 实时推送
echo   交易标的: ETH-USDT-SWAP, BTC-USDT-SWAP
echo   策略模式: MA + Signal + Grid
echo ============================================
echo.
echo   使用说明:
echo   - Ctrl+C: 安全停止 (推荐)
echo   - 仪表盘: http://localhost:5000
echo   - Telegram: 发送 /status 查看状态
echo.
echo   按任意键开始...
pause >nul

:: 启动看门狗 (标准入口)
python watchdog.py --strategy both

:: ─── 退出处理 ───
echo.
echo ============================================
echo   系统已停止
echo ============================================
echo.
echo   最近一次运行记录:
findstr /N "." restart_log.txt 2>nul | findstr /C:"$(date)">nul
echo.
echo   按任意键退出...
pause >nul