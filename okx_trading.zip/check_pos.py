import sys
import io
# 强制 stdout 使用 UTF-8 编码
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
else:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.')
from okx_client import OKXClient

client = OKXClient('config.json')

# Positions
pos = client.get_positions()
print('=== 持仓 ===')
if pos.get('data'):
    found = False
    for p in pos['data']:
        if float(p.get('pos','0')) != 0:
            found = True
            print(f"  {p['instId']}: {p['posSide']} x{p['pos']} @ {p['avgPx']} upl={p['upl']}")
    if not found:
        print('  无持仓')
else:
    print('  无持仓')

# Algo orders (SL/TP)
algo = client._request('GET', '/api/v5/trade/orders-algo-pending', params={'ordType': 'conditional'})
print(f'\n=== 止盈止损单 ===')
if algo.get('data'):
    for o in algo['data']:
        print(f"  {o['instId']} {o['side']} sz={o['sz']} slTriggerPx={o.get('slTriggerPx','-')} tpTriggerPx={o.get('tpTriggerPx','-')}")
else:
    print('  无')

# Pending limit orders
orders = client._request('GET', '/api/v5/trade/orders-pending')
print(f'\n=== 挂单 ===')
if orders.get('data'):
    for o in orders['data']:
        print(f"  {o['instId']} {o['side']} px={o['px']} sz={o['sz']}")
else:
    print('  无')
