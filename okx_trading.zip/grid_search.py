"""参数网格搜索 - 一次拉数据, 本地计算全部组合"""
import statistics
import time
from okx_client import OKXClient

client = OKXClient()
print("Fetching 300 candles...")
result = client.get_candles("DOGE-USDT-SWAP", bar="1H", limit="300")
if result.get("code") != "0":
    print("API failed")
    exit()

candles = result["data"]
candles.reverse()
closes = [float(c[4]) for c in candles]
highs = [float(c[2]) for c in candles]
lows = [float(c[3]) for c in candles]
print(f"OK: {len(closes)} bars\n")


def calc_ema(p, n):
    if len(p) < n: return []
    m = 2 / (n + 1)
    e = [sum(p[:n]) / n]
    for i in range(n, len(p)):
        e.append((p[i] - e[-1]) * m + e[-1])
    return e

def calc_rsi(p, n=14):
    if len(p) < n + 1: return 50
    ch = [p[i] - p[i-1] for i in range(len(p)-n, len(p))]
    g = [c for c in ch if c > 0]
    l = [-c for c in ch if c < 0]
    ag = sum(g) / n if g else 0
    al = sum(l) / n if l else 0.0001
    return 100 - 100 / (1 + ag / al)

def calc_atr(h, l, c, n=14):
    tr = [max(h[i]-l[i], abs(h[i]-c[i-1]), abs(l[i]-c[i-1])) for i in range(1, len(h))]
    return sum(tr[-n:]) / n if len(tr) >= n else (sum(tr) / len(tr) if tr else 0)

def bt(fast, slow, atr_sl, atr_tp, fee=0.0006, slip=0.0002):
    fe = calc_ema(closes, fast)
    se = calc_ema(closes, slow)
    trades = []
    pos = None
    ent = 0
    for i in range(slow + 2, len(closes)):
        fi, si = i - fast, i - slow
        if fi < 1 or si < 1 or fi >= len(fe) or si >= len(se):
            continue
        cf, pf, cs, ps = fe[fi], fe[fi-1], se[si], se[si-1]
        px = closes[i]
        rsi = calc_rsi(closes[:i+1])
        atr = calc_atr(highs[:i+1], lows[:i+1], closes[:i+1])
        gc = pf <= ps and cf > cs
        dc = pf >= ps and cf < cs
        if pos == "long" and atr > 0:
            if px <= ent - atr * atr_sl:
                trades.append((px * (1-slip) - ent) / ent * 100 - fee * 200 - slip * 200)
                pos = None
            elif px >= ent + atr * atr_tp:
                trades.append((px * (1-slip) - ent) / ent * 100 - fee * 200 - slip * 200)
                pos = None
        elif pos == "short" and atr > 0:
            if px >= ent + atr * atr_sl:
                trades.append((ent - px * (1+slip)) / ent * 100 - fee * 200 - slip * 200)
                pos = None
            elif px <= ent - atr * atr_tp:
                trades.append((ent - px * (1+slip)) / ent * 100 - fee * 200 - slip * 200)
                pos = None
        if gc and rsi > 50 and pos != "long":
            if pos == "short":
                trades.append((ent - px * (1+slip)) / ent * 100 - fee * 200 - slip * 200)
            ent = px * (1 + slip)
            pos = "long"
        elif dc and rsi < 50 and pos != "short":
            if pos == "long":
                trades.append((px * (1-slip) - ent) / ent * 100 - fee * 200 - slip * 200)
            ent = px * (1 - slip)
            pos = "short"
    if not trades:
        return None
    w = [p for p in trades if p > 0]
    lo = [p for p in trades if p < 0]
    wr = len(w) / len(trades) * 100
    aw = sum(w) / len(w) if w else 0
    al2 = sum(lo) / len(lo) if lo else 0
    pf2 = abs(aw / al2) if al2 != 0 else 999
    pk = cm = md = 0
    for p in trades:
        cm += p
        pk = max(pk, cm)
        md = max(md, pk - cm)
    sh = 0
    if len(trades) > 1 and statistics.stdev(trades) > 0:
        sh = (sum(trades) / len(trades)) / statistics.stdev(trades) * (252 ** 0.5)
    return {
        "f": fast, "s": slow, "sl": atr_sl, "tp": atr_tp,
        "net": sum(trades), "wr": wr, "aw": aw, "al": al2,
        "pf": pf2, "mdd": md, "sh": sh, "n": len(trades)
    }


# Grid search
print("Grid search (local compute)...")
R = []
for f in range(5, 11):
    for s in range(15, 36, 5):
        if f >= s:
            continue
        for sl in [1.0, 1.2, 1.5, 2.0, 2.5]:
            for tp in [3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0]:
                r = bt(f, s, sl, tp)
                if r:
                    R.append(r)

R.sort(key=lambda x: x["sh"], reverse=True)
print(f"Done: {len(R)} valid combos\n")

print("=" * 80)
print("Top 10 (by Sharpe Ratio)")
print("=" * 80)
header = f"{'#':<3} {'EMA':<8} {'SL':<6} {'TP':<6} {'Net':>8} {'WR':>6} {'P/L':>7} {'MDD':>6} {'Sharpe':>7} {'N':>4}"
print(header)
print("-" * 80)

for i, r in enumerate(R[:10]):
    ema_str = f"{r['f']}/{r['s']}"
    pl_str = f"1:{r['pf']:.1f}"
    line = f"{i+1:<3} {ema_str:<8} {r['sl']:<6.1f} {r['tp']:<6.1f} {r['net']:+7.2f}% {r['wr']:5.1f}% {pl_str:>7} {r['mdd']:5.1f}% {r['sh']:7.2f} {r['n']:4}"
    print(line)

print("=" * 80)

b = R[0]
print(f"\n{'='*40}")
print(f"BEST: EMA {b['f']}/{b['s']} | SL {b['sl']}xATR | TP {b['tp']}xATR")
print(f"  Net={b['net']:+.2f}%  WR={b['wr']:.1f}%  P/L=1:{b['pf']:.1f}  MDD={b['mdd']:.1f}%  Sharpe={b['sh']:.2f}")
print(f"{'='*40}")

print(f"\nCurrent (EMA 7/25 SL 1.5 TP 4.5):")
cur = bt(7, 25, 1.5, 4.5)
if cur:
    print(f"  Net={cur['net']:+.2f}%  WR={cur['wr']:.1f}%  P/L=1:{cur['pf']:.1f}  MDD={cur['mdd']:.1f}%  Sharpe={cur['sh']:.2f}")

print(f"\nImprovement:")
if b and cur:
    print(f"  Net:    {cur['net']:+.2f}% -> {b['net']:+.2f}%  ({b['net']-cur['net']:+.2f}%)")
    print(f"  Sharpe: {cur['sh']:.2f} -> {b['sh']:.2f}  ({b['sh']-cur['sh']:+.2f})")
    print(f"  MDD:    {cur['mdd']:.1f}% -> {b['mdd']:.1f}%")
