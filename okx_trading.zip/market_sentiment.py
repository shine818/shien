"""
市场情绪分析模块 (趋势预测)
通过 Order Book 深度、多空比、持仓量等前瞻性指标预测趋势方向

数据源:
1. Order Book 深度 — 大单堆积方向预示支撑/阻力
2. Long/Short Ratio — OKX Rubik API 多空持仓人数比
3. Open Interest — 持仓量变化 (放量=趋势延续, 缩量=趋势衰竭)
4. Taker Buy/Sell Volume — 主动买卖力量对比

输出: SentimentScore (0-100, 50=中性, >60=看涨, <40=看跌)
"""
import time
import logging
from typing import Optional, Dict

logger = logging.getLogger(__name__)


class MarketSentiment:
    """市场情绪分析器 · 趋势预测 v2"""

    def __init__(self, client, cache_seconds: int = 300):
        self.client = client
        self.cache_seconds = cache_seconds
        self._cache = {}  # {inst_id: {"time": ts, "data": {...}}}
        self._news = None  # NewsSentiment 实例 (外部注入)
        self._prev_ob = {}  # {inst_id: bid_pct} OB变化速度检测

    def _is_cached(self, inst_id: str) -> bool:
        c = self._cache.get(inst_id)
        return c and (time.time() - c["time"]) < self.cache_seconds

    # ─── 数据采集 ───

    def _get_order_book(self, inst_id: str) -> Dict:
        """
        获取 Order Book 深度:
        分析买卖盘挂单密度, 判断支撑/阻力方向
        - 买盘厚 (bid volume > ask volume) → 看涨
        - 卖盘厚 → 看跌
        """
        try:
            result = self.client._request("GET", "/api/v5/market/books",
                                          params={"instId": inst_id, "sz": "20"})
            if result.get("code") != "0" or not result.get("data"):
                return {"signal": 0, "bid_vol": 0, "ask_vol": 0}

            book = result["data"][0]
            bids = book.get("bids", [])
            asks = book.get("asks", [])

            # 累加前20档挂单量
            bid_vol = sum(float(b[1]) for b in bids[:20])
            ask_vol = sum(float(a[1]) for a in asks[:20])
            total = bid_vol + ask_vol

            if total == 0:
                return {"signal": 0, "bid_vol": 0, "ask_vol": 0}

            # 买盘占比: >55% 看涨, <45% 看跌
            bid_pct = bid_vol / total * 100
            signal = (bid_pct - 50) * 2  # 映射到 -100~+100

            # 检测大单 (前3档占比超30%)
            top3_bid = sum(float(b[1]) for b in bids[:3])
            top3_ask = sum(float(a[1]) for a in asks[:3])
            big_order_bias = 0
            if top3_bid / (bid_vol + 0.001) > 0.3:
                big_order_bias = 10  # 买方大单堆积
            elif top3_ask / (ask_vol + 0.001) > 0.3:
                big_order_bias = -10  # 卖方大单堆积

            return {
                "signal": round(signal + big_order_bias, 1),
                "bid_vol": round(bid_vol, 2),
                "ask_vol": round(ask_vol, 2),
                "bid_pct": round(bid_pct, 1),
                "big_order": "买方" if big_order_bias > 0 else ("卖方" if big_order_bias < 0 else "均衡")
            }
        except Exception as e:
            logger.warning(f"Order Book 获取失败: {e}")
            return {"signal": 0, "bid_vol": 0, "ask_vol": 0}

    def _get_long_short_ratio(self, inst_id: str) -> Dict:
        """
        获取多空持仓人数比 (OKX Rubik API):
        - ratio > 1.5: 散户极度看多 → 可能反转做空
        - ratio < 0.7: 散户极度看空 → 可能反转做多
        - 0.9-1.1: 均衡
        """
        try:
            # 转换 inst_id 格式: DOGE-USDT-SWAP → DOGE
            ccy = inst_id.split("-")[0]
            result = self.client._request("GET",
                "/api/v5/rubik/stat/contracts/long-short-account-ratio",
                params={"ccy": ccy, "period": "1H"})

            if result.get("code") != "0" or not result.get("data"):
                return {"signal": 0, "ratio": 1.0}

            latest = result["data"][0]
            ratio = float(latest[1])  # long/short ratio

            # 逆向思维: 散户越看多, 越可能跌
            if ratio > 2.0:
                signal = -30  # 极度拥挤的多头 → 反向看空
            elif ratio > 1.5:
                signal = -15
            elif ratio < 0.5:
                signal = 30   # 极度拥挤的空头 → 反向看多
            elif ratio < 0.7:
                signal = 15
            else:
                signal = 0

            return {
                "signal": signal,
                "ratio": round(ratio, 2),
                "interpretation": "散户偏多" if ratio > 1.2 else ("散户偏空" if ratio < 0.8 else "均衡")
            }
        except Exception as e:
            logger.warning(f"多空比获取失败: {e}")
            return {"signal": 0, "ratio": 1.0}

    def _get_open_interest(self, inst_id: str) -> Dict:
        """
        获取持仓量 (Open Interest):
        - OI 上升 + 价格上涨 → 趋势延续 (看涨)
        - OI 上升 + 价格下跌 → 趋势延续 (看跌)
        - OI 下降 + 价格变化 → 趋势衰竭, 可能反转
        """
        try:
            result = self.client._request("GET",
                "/api/v5/rubik/stat/contracts/open-interest-volume",
                params={"ccy": inst_id.split("-")[0], "period": "1H"})

            if result.get("code") != "0" or not result.get("data") or len(result["data"]) < 3:
                return {"signal": 0, "oi_change": 0}

            data = result["data"]
            # data[0] = 最新, data[1] = 前1h, data[2] = 前2h
            oi_now = float(data[0][1])   # open interest
            oi_prev = float(data[2][1])  # 2h ago

            if oi_prev == 0:
                return {"signal": 0, "oi_change": 0}

            oi_change = (oi_now - oi_prev) / oi_prev * 100

            # OI 增加 → 趋势强化 (方向由其他指标决定)
            # OI 减少 → 趋势减弱
            if oi_change > 3:
                signal = 15   # 持仓量放大, 趋势强化
            elif oi_change > 1:
                signal = 5
            elif oi_change < -3:
                signal = -15  # 持仓量缩小, 趋势衰竭
            elif oi_change < -1:
                signal = -5
            else:
                signal = 0

            return {
                "signal": signal,
                "oi_change": round(oi_change, 2),
                "interpretation": "放量" if oi_change > 1 else ("缩量" if oi_change < -1 else "持平")
            }
        except Exception as e:
            logger.warning(f"持仓量获取失败: {e}")
            return {"signal": 0, "oi_change": 0}

    def _get_taker_volume(self, inst_id: str) -> Dict:
        """
        获取主动买卖量对比 (Taker Volume):
        - 主动买 > 主动卖 → 看涨
        - 主动卖 > 主动买 → 看跌
        """
        try:
            ccy = inst_id.split("-")[0]
            result = self.client._request("GET",
                "/api/v5/rubik/stat/taker-volume-contract",
                params={"ccy": ccy, "period": "1H"})

            if result.get("code") != "0" or not result.get("data"):
                return {"signal": 0, "buy_ratio": 50}

            latest = result["data"][0]
            buy_vol = float(latest[1])
            sell_vol = float(latest[2])
            total = buy_vol + sell_vol

            if total == 0:
                return {"signal": 0, "buy_ratio": 50}

            buy_ratio = buy_vol / total * 100
            signal = (buy_ratio - 50) * 2  # 映射 -100~+100, 但通常在 -20~+20

            return {
                "signal": round(signal, 1),
                "buy_ratio": round(buy_ratio, 1),
                "buy_vol": round(buy_vol, 2),
                "sell_vol": round(sell_vol, 2),
                "interpretation": "主买" if buy_ratio > 55 else ("主卖" if buy_ratio < 45 else "均衡")
            }
        except Exception as e:
            logger.warning(f"Taker Volume 获取失败: {e}")
            return {"signal": 0, "buy_ratio": 50}

    def set_news_analyzer(self, news_analyzer):
        """注入 NewsSentiment 实例"""
        self._news = news_analyzer

    # ─── 价格动量 (优化3: 零延迟趋势判断) ───

    def _get_price_momentum(self, inst_id: str) -> Dict:
        """
        价格动量维度: 用最近 5 根 1min K线计算短期趋势
        不依赖外部 API，零延迟
        - 5分钟涨 >0.5% → 看涨信号
        - 5分钟跌 >0.5% → 看跌信号
        """
        try:
            result = self.client._request("GET", "/api/v5/market/candles",
                params={"instId": inst_id, "bar": "1m", "limit": "6"})
            if result.get("code") != "0" or not result.get("data") or len(result["data"]) < 5:
                return {"signal": 0, "change_pct": 0}

            candles = sorted(result["data"], key=lambda x: int(x[0]))
            if len(candles) < 6:
                return {"signal": 0, "change_pct": 0}
            price_now = float(candles[-1][4])   # 最新收盘
            price_5ago = float(candles[0][4])    # 5分钟前

            if price_5ago == 0:
                return {"signal": 0, "change_pct": 0}

            change_pct = (price_now - price_5ago) / price_5ago * 100

            # 映射: 0.5% 变化 = ±20 信号
            signal = change_pct * 40  # 1% → ±40
            signal = max(-50, min(50, signal))

            return {
                "signal": round(signal, 1),
                "change_pct": round(change_pct, 3),
                "price_now": price_now,
                "interpretation": "急涨" if change_pct > 0.5 else ("急跌" if change_pct < -0.5 else "平稳")
            }
        except Exception as e:
            logger.warning(f"价格动量获取失败: {e}")
            return {"signal": 0, "change_pct": 0}

    # ─── 综合情绪评分 ───

    def analyze(self, inst_id: str, force_refresh: bool = False) -> Dict:
        """
        综合分析市场情绪, 返回 0-100 评分:
        - > 65: 看涨 (建议做多)
        - < 35: 看跌 (建议做空)
        - 35-65: 中性 (按原策略)

        权重 (含新闻+动量, 6维度):
        - Order Book: 20%
        - Long/Short (逆向): 15%
        - Open Interest: 10%
        - Taker Volume: 15%
        - 新闻情绪: 15%
        - 价格动量: 15% (新增, 零延迟)
        - OB可靠性: 如检测到异常波动, OB权重砍半

        force_refresh: True=跳过缓存 (持仓检查时使用)
        """
        if not force_refresh and self._is_cached(inst_id):
            return self._cache[inst_id]["data"]

        ob = self._get_order_book(inst_id)
        ls = self._get_long_short_ratio(inst_id)
        oi = self._get_open_interest(inst_id)
        tv = self._get_taker_volume(inst_id)
        pm = self._get_price_momentum(inst_id)

        # 优化1: OB 变化速度检测 (教训#45: 用3次均值平滑, 防止假异常收紧反转阈值)
        ob_weight = 0.20
        ob_reliable = True
        curr_bid_pct = ob.get("bid_pct", 50)

        # 3次滑动均值平滑OB噪声 (教训#45: 单次比较导致30次假异常)
        if not hasattr(self, '_ob_history'):
            self._ob_history = {}
        if inst_id not in self._ob_history:
            self._ob_history[inst_id] = []
        self._ob_history[inst_id].append(curr_bid_pct)
        if len(self._ob_history[inst_id]) > 3:
            self._ob_history[inst_id] = self._ob_history[inst_id][-3:]

        # 用均值做比较，而不是单次读取
        smoothed_bid_pct = sum(self._ob_history[inst_id]) / len(self._ob_history[inst_id])
        prev_smoothed = self._prev_ob.get(inst_id, smoothed_bid_pct)
        ob_delta = abs(smoothed_bid_pct - prev_smoothed)
        self._prev_ob[inst_id] = smoothed_bid_pct

        # 连续异常计数器
        if not hasattr(self, '_ob_anomaly_count'):
            self._ob_anomaly_count = {}

        if ob_delta > 20:
            self._ob_anomaly_count[inst_id] = self._ob_anomaly_count.get(inst_id, 0) + 1
            count = self._ob_anomaly_count[inst_id]
            if count >= 3:
                ob_weight = 0.0
                ob_reliable = False
                logger.warning(f"⚠️ OB连续异常{count}次: {prev_smoothed:.0f}%→{smoothed_bid_pct:.0f}% (Δ={ob_delta:.0f}%), 权重归零")
            else:
                ob_weight = 0.10
                ob_reliable = False
                logger.warning(f"⚠️ OB异常波动: {prev_smoothed:.0f}%→{smoothed_bid_pct:.0f}% (Δ={ob_delta:.0f}%), 权重砍半")
        else:
            self._ob_anomaly_count[inst_id] = 0

        # 新闻情绪
        news = {"signal": 0, "score": 50, "label": "N/A"}
        if self._news:
            try:
                news_result = self._news.analyze()
                news["signal"] = (news_result["score"] - 50)
                news["score"] = news_result["score"]
                news["label"] = news_result["label"]
                news["fear_greed"] = news_result.get("fear_greed", {})
                news["btc_trend"] = news_result.get("btc_trend", {})
            except Exception as e:
                logger.warning(f"新闻情绪分析异常: {e}")

        # 加权合成 (6维度, OB权重动态调整)
        # OB 砍半时, 多出的权重分给动量
        pm_weight = 0.15 + (0.20 - ob_weight)  # OB 正常=0.15, OB异常=0.25
        if self._news:
            raw = (ob["signal"] * ob_weight +
                   ls["signal"] * 0.15 +
                   oi["signal"] * 0.10 +
                   tv["signal"] * 0.15 +
                   news["signal"] * 0.15 +
                   pm["signal"] * pm_weight)
        else:
            raw = (ob["signal"] * (ob_weight + 0.05) +
                   ls["signal"] * 0.20 +
                   oi["signal"] * 0.15 +
                   tv["signal"] * 0.20 +
                   pm["signal"] * (pm_weight + 0.05))

        # 映射到 0-100
        score = max(0, min(100, 50 + raw))

        result = {
            "score": round(score, 1),
            "direction": "bullish" if score > 65 else ("bearish" if score < 35 else "neutral"),
            "order_book": ob,
            "long_short": ls,
            "open_interest": oi,
            "taker_volume": tv,
            "news": news,
            "momentum": pm,
            "ob_reliable": ob_reliable,
            "label": self._score_label(score)
        }

        self._cache[inst_id] = {"time": time.time(), "data": result}

        news_tag = f" | 📰={news['score']:.0f}" if self._news else ""
        mom_tag = f" | 动量={pm.get('change_pct', 0):+.2f}%"
        ob_warn = " ⚠️" if not ob_reliable else ""
        logger.info(f"📡 {inst_id} 情绪: {result['label']} | "
                    f"OB={curr_bid_pct:.0f}%{ob_warn} | "
                    f"L/S={ls.get('ratio', 1):.2f} | "
                    f"OI={oi.get('oi_change', 0):+.1f}% | "
                    f"TKR={tv.get('buy_ratio', 50):.0f}%{news_tag}{mom_tag}")

        return result

    @staticmethod
    def _score_label(score: float) -> str:
        if score >= 75:
            return "🟢 强烈看涨"
        elif score >= 65:
            return "🟢 看涨"
        elif score >= 55:
            return "🔵 弱看涨"
        elif score >= 45:
            return "⚪ 中性"
        elif score >= 35:
            return "🟠 弱看跌"
        elif score >= 25:
            return "🔴 看跌"
        else:
            return "🔴 强烈看跌"

    def get_trade_bias(self, inst_id: str) -> float:
        """
        返回交易偏置系数:
        - > 1.0: 看涨, 放大做多仓位 / 缩小做空仓位
        - < 1.0: 看跌, 缩小做多仓位 / 放大做空仓位
        - = 1.0: 中性, 不调整
        """
        result = self.analyze(inst_id)
        score = result["score"]
        if score > 65:
            return 1.0 + (score - 65) / 100  # 最高 1.35
        elif score < 35:
            return 1.0 - (35 - score) / 100  # 最低 0.65
        else:
            return 1.0

    def should_filter_trade(self, inst_id: str, direction: str) -> bool:
        """
        是否应该过滤该方向的交易:
        - 情绪强烈看涨但要做空 → 过滤
        - 情绪强烈看跌但要做多 → 过滤
        """
        result = self.analyze(inst_id)
        score = result["score"]
        if direction == "long" and score < 25:
            logger.info(f"🚫 情绪过滤: {inst_id} 强看跌, 拒绝做多")
            return True
        if direction == "short" and score > 75:
            logger.info(f"🚫 情绪过滤: {inst_id} 强看涨, 拒绝做空")
            return True
        return False
