"""
交易系统看门狗 (Watchdog)
监控 main.py 和 dashboard.py 进程, 崩溃自动重启

功能:
1. 每 30 秒检查子进程是否存活
2. 崩溃后自动重启 + 发通知
3. 记录重启日志
4. 心跳文件 (watchdog_heartbeat.txt) 供外部监控
5. 防休眠: 定时模拟鼠标移动

用法:
    python watchdog.py                # 启动（含交易 + 仪表盘）
    python watchdog.py --no-dashboard # 不启动仪表盘
"""
import fix_encoding  # noqa: F401  — 修复 Windows 控制台 emoji 编码
import os
import sys
import time
import json
import ctypes
import signal
import argparse
import subprocess
import logging
from datetime import datetime

# ─── 配置 ───

OKX_DIR = os.path.dirname(os.path.abspath(__file__))
MAIN_SCRIPT = os.path.join(OKX_DIR, "main.py")

HEARTBEAT_FILE = os.path.join(OKX_DIR, "watchdog_heartbeat.txt")
RESTART_LOG = os.path.join(OKX_DIR, "restart_log.txt")
CONFIG_PATH = os.path.join(OKX_DIR, "config.json")

CHECK_INTERVAL = 30        # 每 30 秒检查一次
MAX_RESTARTS = 10          # 单进程最大重启次数 (超过则放弃)
RESTART_COOLDOWN = 60      # 重启后等待 60 秒再检查
ANTI_SLEEP_INTERVAL = 300  # 每 5 分钟防休眠
STALE_LOG_TIMEOUT = 900    # 日志超过 15 分钟未更新 → 判定进程卡死
STALE_GRACE_PERIOD = 600   # 启动后 10 分钟内不检查日志超时 (等待进程稳定)
TRADING_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trading.log")

# ─── 日志 ───

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [WATCHDOG] %(message)s",
    handlers=[
        logging.StreamHandler(),  # stdout 已被 fix_encoding 设为 UTF-8
        logging.FileHandler(os.path.join(OKX_DIR, "watchdog.log"), encoding="utf-8")
    ]
)
logger = logging.getLogger("watchdog")


def _log_restart(process_name, reason):
    """记录重启到文件"""
    with open(RESTART_LOG, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat()} | {process_name} | {reason}\n")


def _write_heartbeat(status, main_pid=None):
    """写心跳文件, 让外部(如 Task Scheduler) 能检查 watchdog 自身是否存活"""
    data = {
        "timestamp": datetime.now().isoformat(),
        "status": status,
        "main_pid": main_pid,
    }
    with open(HEARTBEAT_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _send_notification(title, message):
    """通过 Telegram 发送 Watchdog 告警"""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            config = json.load(f)
        tg = config.get("telegram", {})
        bot_token = tg.get("bot_token", "")
        chat_id = tg.get("chat_id", "")
        if not bot_token or not chat_id:
            return
        proxy = config.get("proxy", {})
        text = f"🐕 Watchdog\n━━━━━━━━━━\n⚠️ {title}\n{message}\n⏰ {datetime.now().strftime('%H:%M:%S')}"
        import requests
        requests.post(
            f"https://api.telegram.org/bot{bot_token}/sendMessage",
            json={"chat_id": chat_id, "text": text},
            proxies=proxy,
            timeout=10
        )
    except Exception as e:
        logger.warning(f"Watchdog 通知发送失败: {e}")


def _prevent_sleep():
    """防止 Windows 休眠: 设置系统线程执行状态"""
    try:
        ES_CONTINUOUS = 0x80000000
        ES_SYSTEM_REQUIRED = 0x00000001
        ES_DISPLAY_REQUIRED = 0x00000002
        ctypes.windll.kernel32.SetThreadExecutionState(
            ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
        )
        return True
    except Exception:
        return False


def _is_log_stale(proc_start_time: float) -> bool:
    """检查 trading.log 是否超时未更新 (进程卡死检测)
    
    安全保护:
    1. 进程启动后 STALE_GRACE_PERIOD 秒内不检查 (等待稳定)
    2. 只比较进程启动后的日志更新时间
    """
    try:
        if not os.path.exists(TRADING_LOG):
            return False
        # 安全保护: 启动后前 10 分钟不检查
        uptime = time.time() - proc_start_time
        if uptime < STALE_GRACE_PERIOD:
            return False
        mtime = os.path.getmtime(TRADING_LOG)
        age = time.time() - mtime
        return age > STALE_LOG_TIMEOUT
    except Exception:
        return False


class ProcessMonitor:
    """进程监控器"""
    
    def __init__(self, name, script, args=None):
        self.name = name
        self.script = script
        self.args = args or []
        self.process = None
        self.restart_count = 0
        self.last_restart = 0
        self.start_time = 0  # 进程启动时间戳
    
    def start(self):
        """启动进程"""
        cmd = [sys.executable, self.script] + self.args
        try:
            # 设置 UTF-8 编码环境, 防止子进程因 emoji 崩溃
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"

            stderr_path = os.path.join(OKX_DIR, f"{self.name}_stderr.log")
            stderr_file = open(stderr_path, "a", encoding="utf-8")

            self.process = subprocess.Popen(
                cmd,
                cwd=OKX_DIR,
                stdout=subprocess.DEVNULL,
                stderr=stderr_file,
                env=env,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            self.start_time = time.time()  # 记录启动时间
            logger.info(f"✅ {self.name} 已启动 (PID: {self.process.pid})")
            return True
        except Exception as e:
            logger.error(f"❌ {self.name} 启动失败: {e}")
            return False
    
    def is_alive(self):
        """检查是否存活"""
        if self.process is None:
            return False
        return self.process.poll() is None
    
    def restart(self, reason="进程退出"):
        """重启进程"""
        self.restart_count += 1
        self.last_restart = time.time()
        
        if self.restart_count > MAX_RESTARTS:
            logger.error(f"🚨 {self.name} 重启次数超限 ({MAX_RESTARTS}), 放弃重启")
            _send_notification("重启超限", f"{self.name} 已重启 {MAX_RESTARTS} 次, 停止监控")
            return False
        
        # 清理旧进程
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
        
        logger.warning(f"🔄 {self.name} 正在重启 (第{self.restart_count}次) | 原因: {reason}")
        _log_restart(self.name, reason)
        _send_notification("进程重启", f"{self.name} 第{self.restart_count}次重启 | {reason}")
        
        return self.start()
    
    @property
    def pid(self):
        return self.process.pid if self.process else None


def main():
    parser = argparse.ArgumentParser(description="OKX 交易系统看门狗")

    parser.add_argument("--strategy", default="both", help="策略模式: ma/grid/both")
    parser.add_argument("--no-ws", action="store_true", help="禁用 WebSocket (纯轮询模式)")
    args = parser.parse_args()

    print("=" * 50)
    print("  🐕 OKX 看门狗 v1.0")
    print("  监控进程 + 崩溃重启 + 防休眠")
    print("=" * 50)

    # 防休眠
    if _prevent_sleep():
        logger.info("💤 防休眠: 已启用 (Windows)")
    else:
        logger.warning("💤 防休眠: 设置失败, 请手动设置电源计划")

    # 启动交易主程序
    main_args = ["--strategy", args.strategy]
    if args.no_ws:
        main_args.append("--no-ws")
    main_proc = ProcessMonitor("交易主程序", MAIN_SCRIPT, main_args)
    main_proc.start()


    
    time.sleep(3)
    last_anti_sleep = time.time()

    # ─── 主监控循环 ───
    try:
        while True:
            # 检查交易主程序
            if not main_proc.is_alive():
                exit_code = main_proc.process.returncode if main_proc.process else "N/A"
                main_proc.restart(f"进程退出 (code={exit_code})")
                time.sleep(RESTART_COOLDOWN)
            elif _is_log_stale(main_proc.start_time):
                # 进程活着但日志卡死 → 强制重启
                logger.warning(f"🚨 交易主程序卡死 (日志超过 {STALE_LOG_TIMEOUT}s 未更新)")
                if main_proc.process:
                    try:
                        main_proc.process.kill()
                        main_proc.process.wait(timeout=5)
                    except Exception:
                        pass
                main_proc.restart("进程卡死 (日志超时)")
                time.sleep(RESTART_COOLDOWN)
            

            
            # 防休眠 (每5分钟)
            if time.time() - last_anti_sleep > ANTI_SLEEP_INTERVAL:
                _prevent_sleep()
                last_anti_sleep = time.time()
            
            # 写心跳
            _write_heartbeat("running", main_pid=main_proc.pid)
            
            time.sleep(CHECK_INTERVAL)
    
    except KeyboardInterrupt:
        logger.info("🛑 收到退出信号, 正在关闭...")
        if main_proc.process:
            main_proc.process.terminate()

        _write_heartbeat("stopped")
        logger.info("👋 已退出")


if __name__ == "__main__":
    main()
