"""
风险管理模块 v4.0
v3 → v4 新增:
  - 按币种独立风控 (每个币种独立连亏/缩仓计数)
  - 最大同时持仓数量限制
  - 黑天鹅保护 (5分钟波动 >5% 紧急平仓信号)
  - 资金曲线止损 (5天新高回落 3% 暂停 24h)
  - SQLite 替代 CSV 存储
  - API 限速管理器
"""
import os
import csv
import time
import sqlite3
import logging
import threading
from datetime import datetime, date, timedelta
from typing import Dict, Any, Optional
from collections import deque
from strategies.portfolio_risk import PortfolioRiskManager, PositionInfo

logger = logging.getLogger(__name__)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trading.db")
EQUITY_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "equity_curve.csv")


class RateLimiter:
    """API 限速队列: 避免触发 OKX 429"""
    def __init__(self, max_calls: int = 18, period: float = 2.0):
        self.max_calls = max_calls
        self.period = period
        self._calls = deque()
        self._lock = threading.Lock()

    def wait(self):
        with self._lock:
            now = time.time()
            while self._calls and now - self._calls[0] > self.period:
                self._calls.popleft()
            if len(self._calls) >= self.max_calls:
                sleep_time = self.period - (now - self._calls[0])
                if sleep_time > 0:
                    time.sleep(sleep_time)
            self._calls.append(time.time())


# 全局限速器 (OKX 限制: 20次/2秒)
rate_limiter = RateLimiter(max_calls=18, period=2.0)


class PerCoinRisk:
    """单币种独立风控状态"""
    def __init__(self):
        self.consecutive_losses = 0
        self.loss_scale_factor = 1.0
        self.total_trades = 0
        self.total_wins = 0
        self.cooldown_until = 0.0


class RiskManager:
    """
    风险管理类 v4.0

    功能：
    1. 凯利公式动态仓位
    2. 监控账户回撤
    3. 日亏损上限（>3% 停机）
    4. 连亏冷却（可选暂停）
    5. 连亏缩仓（每亏一笔→仓位×0.7）
    6. 资金曲线记录 (SQLite + CSV 兼容)
    v4 新增:
    7. 按币种独立风控
    8. 最大同时持仓数量限制
    9. 黑天鹅保护 (5分钟波动 >5%)
    10. 资金曲线止损 (5天新高回落 3%)
    """

    def __init__(self, max_drawdown: float = 0.15, per_trade_risk: float = 0.02,
                 daily_loss_limit: float = 0.10, max_consecutive_losses: int = 3,
                 cooldown_seconds: int = 3600, notifier=None,
                 max_positions: int = 3,
                 black_swan_threshold: float = 0.05,
                 equity_stop_lookback_days: int = 5,
                 equity_stop_drawdown: float = 0.15):
        self.max_drawdown = max_drawdown
        self.per_trade_risk = per_trade_risk
        self.daily_loss_limit = daily_loss_limit
        self.max_consecutive_losses = max_consecutive_losses
        self.cooldown_seconds = cooldown_seconds
        self.notifier = notifier

        # 回撤追踪
        self.peak_balance = 0.0
        self.initial_balance = 0.0
        self.current_drawdown = 0.0

        # 日亏损追踪 (以实际平仓亏损为准)
        self.day_start_balance = 0.0
        self.current_day = None
        self.daily_realized_loss = 0.0  # 当日累计平仓亏损金额

        # 全局连亏追踪 (兼容旧接口)
        self.consecutive_losses = 0
        self.cooldown_until = 0.0
        self.total_trades = 0
        self.total_wins = 0
        self.loss_scale_factor = 1.0
        self.loss_scale_decay = 0.7
        self.loss_scale_min = 0.2

        # === v4 新增 ===
        # 按币种独立风控
        self._coin_risks: Dict[str, PerCoinRisk] = {}

        # 最大同时持仓数
        self.max_positions = max_positions
        self._active_positions: set = set()

        # 黑天鹅保护
        self.black_swan_threshold = black_swan_threshold
        self._price_cache: Dict[str, deque] = {}  # {inst_id: deque of (ts, price)}

        # 资金曲线止损
        self.equity_stop_lookback_days = equity_stop_lookback_days
        self.equity_stop_drawdown = equity_stop_drawdown
        self._equity_pause_until = 0.0
        self._daily_balances: deque = deque(maxlen=30)  # (date, balance)

        # 组合风控模块 (v5.0)
        self.portfolio_risk = PortfolioRiskManager(max_portfolio_risk_pct=0.06)

        # 初始化存储
        self._init_db()
        self._init_equity_csv()

    # ─── 存储初始化 ───

    def _init_db(self):
        """初始化 SQLite 数据库"""
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("""CREATE TABLE IF NOT EXISTS equity_curve (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                balance REAL NOT NULL,
                drawdown_pct REAL,
                daily_pnl_pct REAL,
                consecutive_losses INTEGER,
                status TEXT DEFAULT 'ok'
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                inst_id TEXT,
                side TEXT,
                price REAL,
                size TEXT,
                pnl_pct REAL,
                reason TEXT
            )""")
            c.execute("""CREATE INDEX IF NOT EXISTS idx_equity_ts ON equity_curve(timestamp)""")
            c.execute("""CREATE INDEX IF NOT EXISTS idx_trades_ts ON trades(timestamp)""")
            conn.commit()
            conn.close()
        except Exception as e:
            logger.warning(f"SQLite 初始化失败, 降级到 CSV: {e}")

    def _init_equity_csv(self):
        if not os.path.exists(EQUITY_CSV):
            with open(EQUITY_CSV, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["timestamp", "balance", "drawdown_pct", "daily_pnl_pct",
                                 "consecutive_losses", "status"])

    def _log_equity(self, balance: float, status: str = "ok"):
        daily_pnl = 0
        if self.day_start_balance > 0:
            daily_pnl = (balance - self.day_start_balance) / self.day_start_balance * 100
        now_str = datetime.now().isoformat()

        # 写 SQLite
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("INSERT INTO equity_curve (timestamp, balance, drawdown_pct, daily_pnl_pct, consecutive_losses, status) VALUES (?,?,?,?,?,?)",
                      (now_str, balance, self.current_drawdown * 100, daily_pnl, self.consecutive_losses, status))
            conn.commit()
            conn.close()
        except Exception:
            pass

        # 同时写 CSV (兼容旧仪表盘)
        try:
            with open(EQUITY_CSV, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([now_str, f"{balance:.2f}", f"{self.current_drawdown * 100:.2f}",
                                 f"{daily_pnl:.2f}", self.consecutive_losses, status])
        except Exception:
            pass

    def log_trade(self, inst_id: str, side: str, price: float, size: str,
                  pnl_pct: float = 0, reason: str = ""):
        """记录交易到 SQLite"""
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("INSERT INTO trades (timestamp, inst_id, side, price, size, pnl_pct, reason) VALUES (?,?,?,?,?,?,?)",
                      (datetime.now().isoformat(), inst_id, side, price, size, pnl_pct, reason))
            conn.commit()
            conn.close()
        except Exception:
            pass

    # ─── 币种风控 ───

    def _get_coin_risk(self, inst_id: str) -> PerCoinRisk:
        if inst_id not in self._coin_risks:
            self._coin_risks[inst_id] = PerCoinRisk()
        return self._coin_risks[inst_id]

    # ─── 持仓管理 ───

    def register_position(self, inst_id: str, direction: str, size_usdt: float, entry_price: float, stop_loss: float):
        """注册新持仓 (组合风控同步)"""
        self._active_positions.add(inst_id)
        pos = PositionInfo(
            symbol=inst_id,
            direction=(1 if direction == "long" else -1),
            size_usdt=size_usdt,
            entry_price=entry_price,
            stop_loss=stop_loss
        )
        self.portfolio_risk.add_position(pos)

    def unregister_position(self, inst_id: str):
        """注销持仓"""
        self._active_positions.discard(inst_id)
        self.portfolio_risk.remove_position(inst_id)

    def can_open_position(self, inst_id: str) -> bool:
        """检查是否可以开新仓"""
        if inst_id in self._active_positions:
            return True  # 已持仓的币种可以操作
        if len(self._active_positions) >= self.max_positions:
            logger.info(f"🚫 持仓数已达上限 {len(self._active_positions)}/{self.max_positions}")
            return False
        return True

    # ─── 黑天鹅检测 ───

    def update_price(self, inst_id: str, price: float):
        """更新价格缓存, 用于黑天鹅检测及组合相关性计算"""
        now = time.time()
        if inst_id not in self._price_cache:
            self._price_cache[inst_id] = deque(maxlen=60)  # 保留 5 分钟 (每 5 秒一次)
        self._price_cache[inst_id].append((now, price))
        
        # 同步更新组合风控的价格历史
        self.portfolio_risk.update_price(inst_id, price)

    def check_black_swan(self, inst_id: str) -> bool:
        """检查 5 分钟内是否有 >5% 的剧烈波动"""
        if inst_id not in self._price_cache:
            return False
        cache = self._price_cache[inst_id]
        if len(cache) < 2:
            return False

        now = time.time()
        _, latest_price = cache[-1]

        for ts, price in cache:
            if now - ts > 300:  # 只看 5 分钟内
                continue
            if price > 0:
                change = abs(latest_price - price) / price
                if change >= self.black_swan_threshold:
                    logger.warning(f"🦢 黑天鹅检测! {inst_id} 5分钟波动 {change:.2%} >= {self.black_swan_threshold:.0%}")
                    if self.notifier:
                        try:
                            self.notifier.send_risk_alert("黑天鹅",
                                f"{inst_id} 5分钟波动 {change:.2%}")
                        except Exception:
                            pass
                    return True
        return False

    # ─── 资金曲线止损 ───

    def _check_equity_curve_stop(self, current_balance: float) -> bool:
        """5天新高回落 3% → 暂停 24h"""
        if time.time() < self._equity_pause_until:
            remaining = int((self._equity_pause_until - time.time()) / 3600)
            logger.info(f"⏸️ 资金曲线停机中, 还剩 {remaining}h")
            return True

        today = date.today()
        # 记录每日余额
        if not self._daily_balances or self._daily_balances[-1][0] != today:
            self._daily_balances.append((today, current_balance))
        else:
            self._daily_balances[-1] = (today, current_balance)

        # 取最近 N 天
        lookback = list(self._daily_balances)[-self.equity_stop_lookback_days:]
        if len(lookback) < 2:
            return False

        peak = max(b for _, b in lookback)
        if peak > 0:
            drawdown = (peak - current_balance) / peak
            if drawdown >= self.equity_stop_drawdown:
                self._equity_pause_until = time.time() + 86400  # 暂停 24h
                msg = (f"📉 资金曲线止损! {self.equity_stop_lookback_days}天内 "
                       f"峰值={peak:.2f} 当前={current_balance:.2f} "
                       f"回落={drawdown:.2%} >= {self.equity_stop_drawdown:.0%}, 暂停24h")
                logger.warning(msg)
                if self.notifier:
                    try:
                        self.notifier.send_risk_alert("资金曲线止损", msg)
                    except Exception:
                        pass
                self._log_equity(current_balance, "equity_curve_stop")
                return True
        return False

    def record_trade_loss(self, loss_amount: float):
        """记录平仓亏损 (仅亏损时调用, loss_amount 为正数)"""
        if loss_amount > 0:
            self.daily_realized_loss += loss_amount
            if self.day_start_balance > 0:
                pct = self.daily_realized_loss / self.day_start_balance * 100
                logger.info(f"📊 日平仓亏损累计: {self.daily_realized_loss:.2f}U ({pct:.1f}%) | 限额: {self.daily_loss_limit*100:.0f}%")

    # ─── 核心接口 ───

    def update_balance(self, current_balance: float):
        """更新余额并计算回撤"""
        # 每次启动以当前余额为基准 (避免历史峰值导致虚假回撤)
        if self.initial_balance == 0:
            self.initial_balance = current_balance
            self.peak_balance = current_balance
            # 重启时清空旧的每日余额记录, 以当前余额为基准 (避免历史峰值导致虚假风控)
            self._daily_balances.clear()
            self._equity_pause_until = 0.0
            logger.info(f"📊 风控基准设定: 初始={current_balance:.2f} USDT (已重置历史记录)")

        today = date.today()
        if self.current_day != today:
            self.current_day = today
            self.day_start_balance = current_balance
            self.daily_realized_loss = 0.0  # 新的一天重置平仓亏损
            logger.info(f"📅 日结算重置 | 日初余额: {current_balance:.2f} USDT | 平仓亏损已清零")

        if current_balance > self.peak_balance:
            self.peak_balance = current_balance

        if self.peak_balance > 0:
            self.current_drawdown = (self.peak_balance - current_balance) / self.peak_balance
            # 安全阀: 回撤超50%说明基准失真, 重置
            if self.current_drawdown > 0.50:
                logger.warning(f"⚠️ 回撤 {self.current_drawdown:.2%} 异常, 重置基准为当前余额 {current_balance:.2f}")
                self.peak_balance = current_balance
                self.initial_balance = current_balance
                self.current_drawdown = 0.0

    def record_trade_result(self, pnl_pct: float, inst_id: str = ""):
        """记录交易结果, 更新全局 + 币种级别连亏计数"""
        self.total_trades += 1
        coin = self._get_coin_risk(inst_id) if inst_id else None

        if pnl_pct > 0:
            self.total_wins += 1
            self.consecutive_losses = 0
            self.loss_scale_factor = 1.0
            if coin:
                coin.total_wins += 1
                coin.total_trades += 1
                coin.consecutive_losses = 0
                coin.loss_scale_factor = 1.0
            logger.info(f"✅ 盈利 {pnl_pct:.2f}% | 连亏归零 | 仓位系数恢复→1.0")
        else:
            self.consecutive_losses += 1
            self.loss_scale_factor = max(
                self.loss_scale_min,
                self.loss_scale_factor * self.loss_scale_decay
            )
            if coin:
                coin.total_trades += 1
                coin.consecutive_losses += 1
                coin.loss_scale_factor = max(
                    self.loss_scale_min,
                    coin.loss_scale_factor * self.loss_scale_decay
                )
            logger.warning(f"❌ 亏损 {pnl_pct:.2f}% | 连亏: {self.consecutive_losses} | "
                           f"仓位缩减→{self.loss_scale_factor:.2%}"
                           f"{f' | {inst_id}连亏:{coin.consecutive_losses}' if coin else ''}")

            if self.consecutive_losses >= self.max_consecutive_losses:
                self.cooldown_until = time.time() + self.cooldown_seconds
                if coin:
                    coin.cooldown_until = self.cooldown_until
                msg = (f"🚨 连续 {self.consecutive_losses} 笔亏损，"
                       f"暂停 {self.cooldown_seconds // 60} 分钟 + 仓位缩至 {self.loss_scale_factor:.0%}")
                logger.warning(msg)
                if self.notifier:
                    try:
                        self.notifier.send_risk_alert("连亏停机", msg)
                    except Exception:
                        pass

    def calc_kelly_position(self, ml_confidence: float = 75.0,
                            base_pct: float = 0.30, inst_id: str = "") -> float:
        """凯利公式动态仓位 (支持币种级别缩仓)"""
        if self.total_trades < 10:
            if ml_confidence >= 80:
                final = min(base_pct * 1.3, 0.40)
            elif ml_confidence >= 70:
                final = base_pct
            elif ml_confidence >= 60:
                final = base_pct * 0.6
            else:
                final = base_pct * 0.3
        else:
            win_rate = self.total_wins / self.total_trades
            b = 1.5
            p = win_rate
            q = 1 - p
            kelly = (b * p - q) / b
            kelly = max(0.05, min(kelly, 0.5))
            confidence_mult = ml_confidence / 75.0
            final = kelly * confidence_mult
            final = max(0.05, min(final, 0.45))

        # 全局缩仓
        final *= self.loss_scale_factor

        # 币种级别缩仓 (取更小值)
        if inst_id:
            coin = self._get_coin_risk(inst_id)
            if coin.loss_scale_factor < self.loss_scale_factor:
                final = final / self.loss_scale_factor * coin.loss_scale_factor
                logger.info(f"📩 {inst_id}独立缩仓: ×{coin.loss_scale_factor:.2f}")

        return max(0.05, min(final, 0.45))

    def calc_adaptive_position(self, balance: float, atr: float, price: float,
                               adx: float = 25.0, sentiment_score: float = 50.0,
                               ml_confidence: float = 75.0,
                               inst_id: str = "",
                               direction: int = 1) -> dict:
        """
        行情自适应仓位计算 v5.0

        根据 5 个实时因子动态调整:
        1. ATR 波动率 → 高波动缩仓, 低波动扩仓
        2. ADX 趋势强度 → 强趋势加仓, 震荡缩仓
        3. 市场情绪 → 情绪极端且顺势时加仓
        4. 连亏缩仓 → 沿用全局/币种级别缩仓
        5. 回撤惩罚 → 回撤越大仓位越小

        返回 dict: {
            "size_usdt": 最终仓位 (USDT),
            "size_pct": 仓位占比,
            "factors": 各因子明细,
        }
        """
        if balance <= 0 or price <= 0 or atr <= 0:
            return {"size_usdt": 0, "size_pct": 0, "factors": {}}

        # ── 基础仓位 (凯利公式) ──
        base_pct = self.calc_kelly_position(ml_confidence, 0.30, inst_id)

        # ── 因子 1: ATR 波动率调节 ──
        # ATR% = ATR / price, 正常约 1-3%
        atr_pct = atr / price * 100
        if atr_pct > 4.0:
            vol_factor = 0.5   # 极高波动 → 半仓
        elif atr_pct > 3.0:
            vol_factor = 0.65  # 高波动 → 缩仓
        elif atr_pct > 2.0:
            vol_factor = 0.85  # 正常偏高
        elif atr_pct > 1.0:
            vol_factor = 1.0   # 正常波动
        elif atr_pct > 0.5:
            vol_factor = 1.15  # 低波动 → 略加
        else:
            vol_factor = 0.7   # 极低波动(BB挤压) → 不宜重仓

        # ── 因子 2: ADX 趋势强度 ──
        if adx >= 40:
            trend_factor = 1.3   # 强趋势 → 加仓
        elif adx >= 30:
            trend_factor = 1.15  # 中等趋势
        elif adx >= 20:
            trend_factor = 1.0   # 正常
        elif adx >= 15:
            trend_factor = 0.7   # 弱趋势 → 缩仓
        else:
            trend_factor = 0.5   # 无趋势震荡 → 大幅缩仓

        # ── 因子 3: 市场情绪 ──
        # sentiment_score: 0=极看跌, 50=中性, 100=极看涨
        # 情绪极端且我们顺势时加仓, 否则保守
        if sentiment_score >= 75 or sentiment_score <= 25:
            sentiment_factor = 1.2   # 情绪极端 → 趋势明确
        elif sentiment_score >= 60 or sentiment_score <= 40:
            sentiment_factor = 1.0   # 有方向偏向
        else:
            sentiment_factor = 0.8   # 中性/混乱 → 缩仓

        # ── 因子 4: 回撤惩罚 ──
        if self.current_drawdown >= 0.10:
            dd_factor = 0.4    # 回撤 >10% → 大幅缩仓
        elif self.current_drawdown >= 0.07:
            dd_factor = 0.6    # 回撤 7-10%
        elif self.current_drawdown >= 0.04:
            dd_factor = 0.8    # 回撤 4-7%
        else:
            dd_factor = 1.0    # 回撤 <4%

        # ── 因子 5: 组合相关性压缩 (v5.0) ──
        # 假设新开仓方向在 signal_strategy 已计算，这里尝试从上下文获取或通过 size_pct 推导
        # 为了兼容性，我们通过传入 direction 参数支持 (默认为 1 long)
        # direction 由函数参数传入 (1=long, -1=short)
        scale_info = self.portfolio_risk.get_position_scale_factor(inst_id, direction, balance)
        corr_factor = scale_info["scale"]

        # ── 计算最终仓位 ──
        adjusted_pct = base_pct * vol_factor * trend_factor * sentiment_factor * dd_factor * corr_factor
        adjusted_pct = max(0.05, min(adjusted_pct, 0.50))  # 限制 5%-50%

        size_usdt = balance * adjusted_pct

        factors = {
            "base_kelly": f"{base_pct:.1%}",
            "vol_factor": f"{vol_factor:.2f} (ATR={atr_pct:.2f}%)",
            "trend_factor": f"{trend_factor:.2f} (ADX={adx:.1f})",
            "sentiment_factor": f"{sentiment_factor:.2f} (score={sentiment_score:.0f})",
            "dd_factor": f"{dd_factor:.2f} (dd={self.current_drawdown:.2%})",
            "final_pct": f"{adjusted_pct:.1%}",
        }

        logger.info(
            f"📐 自适应仓位 {inst_id or 'N/A'}: "
            f"基础={base_pct:.1%} × 波动={vol_factor:.2f} × 趋势={trend_factor:.2f} "
            f"× 情绪={sentiment_factor:.2f} × 回撤={dd_factor:.2f} "
            f"→ {adjusted_pct:.1%} ({size_usdt:.2f} USDT)"
        )

        return {
            "size_usdt": round(size_usdt, 2),
            "size_pct": round(adjusted_pct, 4),
            "factors": factors,
        }

    def is_risk_ok(self, current_balance: float, inst_id: str = "",
                   new_risk_pct: float = 0.0, new_size_usdt: float = 0.0) -> bool:
        """综合风控检查 (含 v4 新增检查项)"""
        if current_balance < 0:
            # 余额获取失败 (代理断线等), 不阻止交易但也不记录虚假数据
            # main.py 应在调用前过滤掉 -1 的情况
            return True

        self.update_balance(current_balance)
        self._log_equity(current_balance)

        # 0. 资金曲线止损
        if self._check_equity_curve_stop(current_balance):
            return False

        # 1. 冷却期检查 (全局 + 币种)
        now = time.time()
        if now < self.cooldown_until:
            remaining = int(self.cooldown_until - now)
            logger.info(f"⏸️ 全局冷却中，还剩 {remaining}s")
            self._log_equity(current_balance, "cooldown")
            return False

        if inst_id:
            coin = self._get_coin_risk(inst_id)
            if now < coin.cooldown_until:
                remaining = int(coin.cooldown_until - now)
                logger.info(f"⏸️ {inst_id}冷却中，还剩 {remaining}s")
                return False

        # 2. 最大回撤
        if self.current_drawdown >= self.max_drawdown:
            msg = f"🚨 触发风控: 回撤 {self.current_drawdown * 100:.2f}% ≥ {self.max_drawdown * 100:.2f}%"
            logger.warning(msg)
            if self.notifier:
                try:
                    self.notifier.send_risk_alert("最大回撤超限",
                        f"当前回撤: {self.current_drawdown * 100:.2f}% / 限制: {self.max_drawdown * 100:.2f}%")
                except Exception:
                    pass
            self._log_equity(current_balance, "max_drawdown")
            return False

        # 3. 日亏损上限 (以实际平仓亏损为准, 非余额波动)
        if self.day_start_balance > 0 and self.daily_realized_loss > 0:
            daily_loss_pct = self.daily_realized_loss / self.day_start_balance
            if daily_loss_pct >= self.daily_loss_limit:
                msg = (f"🚨 日平仓亏损 {daily_loss_pct * 100:.2f}% ≥ {self.daily_loss_limit * 100:.2f}%，"
                       f"今日停止交易 (累计亏损={self.daily_realized_loss:.2f}U)")
                logger.warning(msg)
                if self.notifier:
                    try:
                        self.notifier.send_risk_alert("日亏损超限", msg)
                    except Exception:
                        pass
                self._log_equity(current_balance, "daily_limit")
                return False

        # 4. 余额过低
        if current_balance < self.initial_balance * 0.5:
            msg = f"🚨 余额亏损过半: {current_balance:.2f} / 初始 {self.initial_balance:.2f}"
            logger.warning(msg)
            if self.notifier:
                try:
                    self.notifier.send_risk_alert("余额亏损过半",
                        f"当前: {current_balance:.2f} / 初始: {self.initial_balance:.2f}")
                except Exception:
                    pass
            self._log_equity(current_balance, "balance_low")
            return False

        # 5. 黑天鹅检测 (仅警告, 不阻止)
        if inst_id:
            self.check_black_swan(inst_id)

        # 6. 持仓数量检查
        if inst_id and not self.can_open_position(inst_id):
            return False
            
        # 7. 组合 VaR 检查 (v5.0)
        # 这里进行整体 VaR 监控，新风险额由调用者提供或在此估算
        # new_risk_pct / new_size_usdt 由函数参数传入
        var_check = self.portfolio_risk.check_portfolio_var(current_balance, new_size_usdt * new_risk_pct)
        if not var_check["allow"]:
            logger.info(f"🚫 组合 VaR 风险超限: {var_check['portfolio_risk_pct']:.1%} > {self.portfolio_risk.max_portfolio_risk_pct:.1%}")
            return False

        return True

    def get_status(self) -> dict:
        daily_pnl = 0
        if self.day_start_balance > 0:
            daily_pnl = (self.peak_balance - self.day_start_balance) / self.day_start_balance * 100

        status = "正常"
        now = time.time()
        if now < self.cooldown_until:
            status = f"冷却中(还剩{int(self.cooldown_until - now)}s)"
        elif now < self._equity_pause_until:
            status = f"曲线停机(还剩{int((self._equity_pause_until - now) / 3600)}h)"

        return {
            "初始余额": f"{self.initial_balance:.2f} USDT",
            "峰值余额": f"{self.peak_balance:.2f} USDT",
            "当前回撤": f"{self.current_drawdown * 100:.2f}%",
            "风控限制": f"{self.max_drawdown * 100:.2f}%",
            "今日盈亏": f"{daily_pnl:+.2f}%",
            "连续亏损": f"{self.consecutive_losses}/{self.max_consecutive_losses}",
            "仓位系数": f"{self.loss_scale_factor:.0%}",
            "总胜率": f"{self.total_wins}/{self.total_trades}" if self.total_trades else "无数据",
            "活跃持仓": f"{len(self._active_positions)}/{self.max_positions}",
            "状态": status,
        }

