import sys, time
sys.path.insert(0, '.')
from okx_client import OKXClient

client = OKXClient('config.json')

# Test 3 successive API calls with timing
for i in range(3):
    t0 = time.time()
    try:
        result = client.get_ticker('DOGE-USDT-SWAP')
        if result.get('code') == '0':
            px = result['data'][0].get('last', '?')
            print(f"[{i}] OK  price={px}  ({time.time()-t0:.2f}s)")
        else:
            print(f"[{i}] ERR {result.get('msg')}  ({time.time()-t0:.2f}s)")
    except Exception as e:
        print(f"[{i}] FAIL {e}  ({time.time()-t0:.2f}s)")
    time.sleep(1)

# Test place_order with SL/TP
print("\n=== Testing order with SL/TP ===")
try:
    result = client.place_order(
        inst_id='DOGE-USDT-SWAP',
        td_mode='cross',
        side='buy',
        ord_type='limit',
        sz='1',
        px='0.09350',
        sl_trigger_px='0.09160',
        tp_trigger_px='0.09450'
    )
    print(f"Result: {result}")
except Exception as e:
    print(f"FAIL: {e}")
