"""
持仓安全守卫 (Position Guard)
在交易系统中加入 3 道安全防线:

1. 启动前仓位扫描 — 发现与 config 不匹配的"孤儿仓"立即报警
2. 连续失败告警 — 下单连续失败 N 次则暂停交易 (含自动恢复)
3. 裸仓定时检测 — 每 5 分钟扫描无止损保护的持仓
"""
import time
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)


class PositionGuard:
    """持仓安全守卫"""

    def __init__(self, client, notifier=None,
                 max_consecutive_failures: int = 3,
                 naked_check_interval: int = 300,
                 pause_cooldown: int = 300,
                 ignore_instruments: list = None,
                 dry_run: bool = False):
        self.client = client
        self.notifier = notifier
        self.max_consecutive_failures = max_consecutive_failures
        self.naked_check_interval = naked_check_interval  # 秒
        self.pause_cooldown = pause_cooldown  # 暂停冷却 (5分钟自动恢复)
        self.ignore_instruments = set(ignore_instruments or [])  # 不干预的仓位白名单
        self.dry_run = dry_run

        # 状态
        self.consecutive_failures = 0
        self.trading_paused = False
        self.pause_reason = ""
        self.pause_time = 0  # 暂停时间戳
        self.last_naked_check = 0
        self.orphan_positions = []  # 启动时发现的孤儿仓

        if self.ignore_instruments:
            logger.info(f"🛡️ 仓位白名单 (不干预): {', '.join(self.ignore_instruments)}")

    # ─── 1. 启动前仓位扫描 ───

    def scan_on_startup(self, config_instruments: List[str]) -> List[dict]:
        """
        启动时扫描所有持仓, 对比 config 中的 instruments 列表
        返回不在 config 中的"孤儿仓"列表
        """
        logger.info("🔍 启动前仓位安全扫描...")
        print("=" * 50)
        print("  🔍 启动前仓位安全扫描")
        print("=" * 50)

        orphans = []
        all_positions = []

        try:
            result = self.client.get_positions()
            if result.get("code") == "0" and result.get("data"):
                all_positions = result["data"]
        except Exception as e:
            logger.error(f"❌ 获取持仓失败: {e}")
            print(f"  ❌ 获取持仓失败: {e}")
            return []

        if not all_positions:
            print("  ✅ 当前无任何持仓")
            print("=" * 50)
            return []

        config_set = set(config_instruments)

        for pos in all_positions:
            inst_id = pos.get("instId", "")
            pos_amt = float(pos.get("pos", "0"))
            avg_px = float(pos.get("avgPx", "0"))
            upl = float(pos.get("upl", "0"))

            if pos_amt == 0:
                continue

            direction = "多头(long)" if pos_amt > 0 else "空头(short)"
            size = abs(pos_amt)

            # 打印所有持仓
            pnl_str = f"+{upl:.4f}" if upl >= 0 else f"{upl:.4f}"
            print(f"  📌 {inst_id}: {direction} × {size:.0f}张 @ {avg_px:.6f} | 浮盈: {pnl_str} USDT")

            if inst_id not in config_set:
                # 白名单仓位: 跳过不报警
                if inst_id in self.ignore_instruments:
                    print(f"  🛡️ {inst_id}: 白名单仓位, 跳过不干预")
                    continue
                orphans.append({
                    "inst_id": inst_id,
                    "direction": direction,
                    "size": size,
                    "avg_price": avg_px,
                    "unrealized_pnl": upl,
                })

        if orphans:
            print()
            print("  ⚠️  发现孤儿仓位 (不在当前 config instruments 中):")
            for o in orphans:
                print(f"     🚨 {o['inst_id']}: {o['direction']} × {o['size']:.0f}张 "
                      f"@ {o['avg_price']:.6f} | 浮盈 {o['unrealized_pnl']:.4f}")
            print()
            print("  ⚠️  这些仓位没有策略在管理, 是裸跑状态!")
            print("  💡  建议: 手动登录 OKX 决定是否平仓")

            # 发通知
            self._alert("🚨 启动扫描: 发现孤儿仓位",
                         self._format_orphan_alert(orphans, config_instruments))
        else:
            print("  ✅ 所有持仓均在策略管理范围内")

        print("=" * 50)
        self.orphan_positions = orphans
        return orphans

    def _format_orphan_alert(self, orphans, config_instruments):
        lines = [f"Config 管理: {', '.join(config_instruments)}"]
        lines.append("")
        for o in orphans:
            lines.append(f"⚠️ {o['inst_id']}: {o['direction']} × {o['size']:.0f}张")
            lines.append(f"   均价 {o['avg_price']:.6f} | 浮盈 {o['unrealized_pnl']:.4f}")
        lines.append("")
        lines.append("这些仓位无策略管理, 请手动处理!")
        return "\n".join(lines)

    # ─── 2. 连续失败告警 ───

    def record_success(self):
        """记录一次成功下单"""
        if self.consecutive_failures > 0:
            logger.info(f"✅ 下单恢复成功 (之前连续失败 {self.consecutive_failures} 次)")
        self.consecutive_failures = 0
        if self.trading_paused and self.pause_reason == "consecutive_failures":
            self.trading_paused = False
            self.pause_reason = ""
            self.pause_time = 0
            logger.info("▶️ 交易已自动恢复")

    def record_failure(self, reason: str = ""):
        """记录一次下单失败, 达到阈值则暂停 (含自动恢复倒计时)"""
        self.consecutive_failures += 1
        logger.warning(f"❌ 下单失败 ({self.consecutive_failures}/{self.max_consecutive_failures}): {reason}")

        if self.consecutive_failures >= self.max_consecutive_failures:
            self.trading_paused = True
            self.pause_reason = "consecutive_failures"
            self.pause_time = time.time()
            msg = (f"🛑 交易已暂停!\n"
                   f"连续失败 {self.consecutive_failures} 次\n"
                   f"最近失败原因: {reason}\n"
                   f"请检查: 余额是否充足 / API 是否正常 / 合约参数是否正确\n"
                   f"⏰ {self.pause_cooldown}秒后自动恢复")
            logger.error(msg)
            print(f"\n  🛑 交易已暂停! 连续失败 {self.consecutive_failures} 次")
            print(f"     原因: {reason}")
            print(f"     ⏰ {self.pause_cooldown}秒后自动恢复")
            self._alert("🛑 交易已暂停 — 连续失败", msg)

    def is_trading_allowed(self) -> bool:
        """检查是否允许交易 (含自动恢复)"""
        if self.trading_paused:
            # 冷却时间到 → 自动恢复
            if self.pause_time > 0 and (time.time() - self.pause_time) >= self.pause_cooldown:
                logger.info(f"▶️ 暂停冷却 {self.pause_cooldown}s 到期, 交易自动恢复")
                self.trading_paused = False
                self.pause_reason = ""
                self.pause_time = 0
                self.consecutive_failures = 0
                return True
            return False
        return True

    def force_resume(self):
        """强制恢复交易"""
        self.trading_paused = False
        self.pause_reason = ""
        self.pause_time = 0
        self.consecutive_failures = 0
        logger.info("▶️ 交易已强制恢复")

    # ─── 3. 裸仓定时检测 ───

    def check_naked_positions(self, managed_instruments: List[str]) -> List[dict]:
        """
        定时检查是否有"裸仓" — 有持仓但没有止损保护
        发现裸仓后自动补挂 5% 紧急止损
        """
        now = time.time()
        if (now - self.last_naked_check) < self.naked_check_interval:
            return []

        self.last_naked_check = now
        naked = []

        try:
            result = self.client.get_positions()
            if result.get("code") != "0" or not result.get("data"):
                return []

            for pos in result["data"]:
                inst_id = pos.get("instId", "")
                pos_amt = float(pos.get("pos", "0"))
                if pos_amt == 0:
                    continue

                # 白名单仓位: 跳过不干预
                if inst_id in self.ignore_instruments:
                    continue

                avg_px = float(pos.get("avgPx", "0"))
                upl = float(pos.get("upl", "0"))

                # 检查该仓位是否在管理范围内
                is_managed = inst_id in managed_instruments

                # 检查是否有止损/止盈单
                has_sl = False
                has_tp = False
                try:
                    algo_result = self.client._request("GET", "/api/v5/trade/orders-algo-pending",
                                                       params={"instId": inst_id, "ordType": "conditional"})
                    if algo_result.get("code") == "0" and algo_result.get("data"):
                        for a in algo_result["data"]:
                            if a.get("slTriggerPx") and a.get("slTriggerPx") != "":
                                has_sl = True
                            if a.get("tpTriggerPx") and a.get("tpTriggerPx") != "":
                                has_tp = True
                except Exception:
                    pass

                if not is_managed or not has_sl:
                    direction = "long" if pos_amt > 0 else "short"
                    naked.append({
                        "inst_id": inst_id,
                        "direction": direction,
                        "size": abs(pos_amt),
                        "avg_price": avg_px,
                        "upl": upl,
                        "is_managed": is_managed,
                        "has_sl": has_sl,
                        "has_tp": has_tp,
                    })

            if naked:
                lines = []
                for n in naked:
                    status = []
                    if not n["is_managed"]:
                        status.append("无策略管理")
                    if not n["has_sl"]:
                        status.append("无止损")
                    pnl = f"+{n['upl']:.4f}" if n['upl'] >= 0 else f"{n['upl']:.4f}"
                    lines.append(f"⚠️ {n['inst_id']}: {n['direction']} ×{n['size']:.0f} "
                                 f"@ {n['avg_price']:.6f} ({pnl}) — {' + '.join(status)}")

                    # ─── 自动补挂止损+止盈 (策略级保护) ───
                    if n["avg_price"] > 0:
                        try:
                            if self.dry_run:
                                logger.info(f"🧪 DRY-RUN 模式: 发现裸仓 {n['inst_id']}, 跳过实盘自动挂单")
                                lines.append(f"  🧪 DRY-RUN 模式: 未挂止损/止盈")
                                continue

                            sl_pct = 0.02   # 2% 止损 (与策略一致)
                            tp_pct = 0.04   # 4% 止盈 (与策略一致)
                            if n["direction"] == "long":
                                sl_price = round(n["avg_price"] * (1 - sl_pct), 2)
                                tp_price = round(n["avg_price"] * (1 + tp_pct), 2)
                                close_side = "sell"
                            else:
                                sl_price = round(n["avg_price"] * (1 + sl_pct), 2)
                                tp_price = round(n["avg_price"] * (1 - tp_pct), 2)
                                close_side = "buy"

                            sz = str(int(n["size"]))

                            # 补挂止损
                            if not n["has_sl"]:
                                sl_result = self.client.place_stop_order(
                                    inst_id=n["inst_id"],
                                    td_mode="cross",
                                    side=close_side,
                                    sz=sz,
                                    sl_trigger_px=str(sl_price),
                                )
                                if sl_result.get("code") == "0":
                                    logger.info(f"🛡️ 自动补挂止损: {n['inst_id']} SL={sl_price} ({sl_pct*100:.0f}%)")
                                    lines.append(f"  🛡️ 已自动补挂止损 SL={sl_price}")
                                else:
                                    logger.warning(f"⚠️ 自动补止损失败: {sl_result.get('msg')}")

                            # 补挂止盈
                            if not n["has_tp"]:
                                tp_result = self.client.place_stop_order(
                                    inst_id=n["inst_id"],
                                    td_mode="cross",
                                    side=close_side,
                                    sz=sz,
                                    tp_trigger_px=str(tp_price),
                                )
                                if tp_result.get("code") == "0":
                                    logger.info(f"🎯 自动补挂止盈: {n['inst_id']} TP={tp_price} ({tp_pct*100:.0f}%)")
                                    lines.append(f"  🎯 已自动补挂止盈 TP={tp_price}")
                                else:
                                    logger.warning(f"⚠️ 自动补止盈失败: {tp_result.get('msg')}")

                        except Exception as e:
                            logger.warning(f"⚠️ 自动补SL/TP异常: {e}")

                detail = "\n".join(lines)
                logger.warning(f"🔍 发现裸仓:\n{detail}")
                self._alert("⚠️ 裸仓检测 (已自动补止损)", detail)

        except Exception as e:
            logger.error(f"裸仓检测异常: {e}")

        return naked

    # ─── 通知 ───

    def _alert(self, title: str, detail: str):
        """发送告警通知"""
        print(f"\n{'='*50}")
        print(f"  {title}")
        print(f"  {detail}")
        print(f"{'='*50}\n")

        if self.notifier:
            try:
                self.notifier.send_risk_alert(title, detail)
            except Exception as e:
                logger.error(f"告警通知发送失败: {e}")

    def get_status(self) -> dict:
        return {
            "trading_paused": self.trading_paused,
            "pause_reason": self.pause_reason,
            "consecutive_failures": self.consecutive_failures,
            "orphan_count": len(self.orphan_positions),
        }
