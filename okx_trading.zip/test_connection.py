"""OKX API 连接测试脚本 - 使用 requests 库"""
import json
import hmac
import hashlib
import base64
import os
from datetime import datetime, timezone
import requests

def load_config():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def get_timestamp():
    now = datetime.now(timezone.utc)
    return now.strftime('%Y-%m-%dT%H:%M:%S.') + now.strftime('%f')[:3] + 'Z'

def sign(timestamp, method, request_path, body, secret_key):
    message = timestamp + method + request_path + (body or '')
    mac = hmac.new(secret_key.encode('utf-8'), message.encode('utf-8'), hashlib.sha256)
    return base64.b64encode(mac.digest()).decode('utf-8')

def test_connection():
    config = load_config()
    
    api_key = config["api_key"]
    secret_key = config["secret_key"]
    passphrase = config["passphrase"]
    is_simulated = config.get("is_simulated", True)

    # 代理配置
    proxies = {
        'http': 'http://127.0.0.1:7897',
        'https': 'http://127.0.0.1:7897',
    }
    
    # 尝试多个端点
    base_urls = [
        "https://www.okx.com",
        "https://aws.okx.com",
    ]
    request_path = "/api/v5/account/balance"
    method = "GET"
    body = ""
    
    if is_simulated:
        print("📋 模式: 模拟盘 (Simulated Trading)")
    else:
        print("📋 模式: 实盘 (Live Trading)")
    print(f"🌐 代理: {proxies['https']}")
    
    for base_url in base_urls:
        timestamp = get_timestamp()
        signature = sign(timestamp, method, request_path, body, secret_key)
        
        headers = {
            "OK-ACCESS-KEY": api_key,
            "OK-ACCESS-SIGN": signature,
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": passphrase,
            "Content-Type": "application/json"
        }
        
        if is_simulated:
            headers["x-simulated-trading"] = "1"
        
        url = base_url + request_path
        print(f"\n🔗 正在尝试连接: {url}")
        print("-" * 50)
        
        try:
            # 先尝试用代理
            resp = requests.get(url, headers=headers, proxies=proxies, timeout=15)
            data = resp.json()
            
            if data.get("code") == "0":
                print("✅ 连接成功！API 密钥验证通过！")
                print(f"📊 返回数据:")
                print(json.dumps(data, indent=2, ensure_ascii=False))
                return True
            else:
                print(f"❌ API 返回错误:")
                print(f"   错误码: {data.get('code')}")
                print(f"   错误信息: {data.get('msg')}")
                return False
                
        except requests.exceptions.ProxyError:
            print(f"⚠️ 代理连接失败，尝试直连...")
            try:
                resp = requests.get(url, headers=headers, timeout=15)
                data = resp.json()
                if data.get("code") == "0":
                    print("✅ 直连成功！API 密钥验证通过！")
                    print(f"📊 返回数据:")
                    print(json.dumps(data, indent=2, ensure_ascii=False))
                    return True
                else:
                    print(f"❌ API 返回错误: {data.get('code')} - {data.get('msg')}")
                    return False
            except Exception as e:
                print(f"⚠️ 直连也失败: {e} (尝试下一个端点...)")
        except Exception as e:
            print(f"⚠️ 错误: {e} (尝试下一个端点...)")
    
    print("\n❌ 所有端点均连接失败。")
    print("   请检查: 1) 代理/VPN是否运行  2) API密钥是否正确  3) 网络是否正常")
    return False

if __name__ == "__main__":
    test_connection()
