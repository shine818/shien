# OKX Agent Handoff Log

更新时间: 2026-04-30 21:43 Asia/Shanghai
项目目录: `C:\Users\15031\Desktop\shine\shine\okx`

这份文件给后续接管工具或自动化助手使用。目标是避免“靠记忆启动”，先确认状态，再决定是否重启。

## 当前运行状态

- 当前运行方式: 直接运行 `main.py --strategy both`
- 当前进程: `python.exe main.py --strategy both`
- 当前模式: `dry_run=true`，模拟交易，不应直接切换实盘
- 当前行情: WebSocket 已连接，K 线和 ticker 已订阅 ETH/BTC
- 当前虚拟余额: `128.98U`
- 当前虚拟净值展示: 已修复为 `余额 + 浮盈`
- 当前虚拟仓位: `BTC-USDT-SWAP` 空单
- BTC 仓位参数: entry `77023.6`, size `1`, SL `77550.7043`, TP `75642.1137`
- ETH 仓位: 已在 2026-04-30 20:44 触发 dry-run 止损平仓

## 最近已修复的问题

- 修复 dry-run 重启后策略忘记已有虚拟仓位的问题。
- 修复历史虚拟仓位缺少 SL/TP 导致无法自动平仓的问题。
- 修复 dry-run 平仓后余额文件已变化，但状态日志仍展示旧余额的问题。
- 修复 dry-run 交易 CSV 记录里 size 可能显示为 `0` 的展示问题。
- Telegram/状态展示现在应区分余额、浮盈、净值。

## 验证记录

- 语法校验已通过:
  `python -m py_compile main.py trader.py strategies\signal_strategy.py notifier.py okx_client.py ws_feed.py`
- 回测验证文件:
  `backtest_verify_result.json`
- ETH 1H 回测:
  1100 根 K 线，31 笔，净收益 `+0.5261%`，胜率 `29.03%`，最大回撤 `10.5997%`
- BTC 1H 回测:
  1100 根 K 线，43 笔，净收益 `-17.4437%`，胜率 `20.93%`，最大回撤 `19.4636%`

## 推荐启动方式

日常稳定运行建议使用 watchdog 托管，而不是直接运行 `main.py`。

安全查看状态:

```powershell
.\stable_start.ps1 -StatusOnly
```

发现已有实例时，默认不会重复启动:

```powershell
.\stable_start.ps1
```

需要明确切换到 watchdog 托管时再执行:

```powershell
.\stable_start.ps1 -Restart
```

如果要禁用 WebSocket，仅用于排障:

```powershell
.\stable_start.ps1 -Restart -NoWs
```

## 重要日志与状态文件

- 主运行日志: `trading.log`
- Watchdog 日志: `watchdog.log`
- Watchdog 心跳: `watchdog_heartbeat.txt`
- 重启记录: `restart_log.txt`
- 稳定启动器状态: `runtime_status.json`
- 稳定启动器输出: `logs\stable_start_*.out.log`
- 稳定启动器错误: `logs\stable_start_*.err.log`
- dry-run 状态: `dry_run_state.json`
- 交易记录: `trades.csv`

## 接管前检查清单

1. 先检查是否已有进程，避免重复启动。
2. 先确认 `config.json` 里 `dry_run` 的值，不要误切实盘。
3. 先看 `dry_run_state.json`，确认虚拟余额和仓位。
4. 再看 `trading.log` 最近 100 行，确认 WebSocket 与策略状态。
5. 若只是改策略参数，优先改 `config.json`，系统支持热加载。
6. 若改代码，先语法校验，再重启。
7. 若影响真实下单、仓位、止盈止损，必须先总结风险，不要直接执行。

## 已知风险

- 当前工作区存在大量未提交改动，不要随意执行回滚类 Git 操作。
- 项目没有远程仓库，暂时不能依赖远端恢复。
- `config.json` 含敏感信息，不要外传。
- BTC 当前参数近期回测表现较差，应优先优化 BTC 的信号过滤和参数。
- 当前 direct main 实例能运行，但长期稳定性不如 watchdog 托管。

## 下一步建议

- 下一次需要重启时，用 `stable_start.ps1 -Restart` 切换到 watchdog 托管。
- 把回测逻辑与真实 `SignalStrategy` 对齐，再做参数搜索。
- 建立最小测试集，覆盖 dry-run 开仓、平仓、余额、净值、重启恢复。
- 将敏感配置与普通参数拆分，降低误共享风险。
