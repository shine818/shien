"""
通知模块 v2 (Telegram)
优化: 精简内容 + 防刷屏 + 分级推送

通知级别:
- CRITICAL: 立即推送 (风控/黑天鹅/系统崩溃)
- TRADE:    立即推送 (开仓/平仓)
- INFO:     合并推送 (状态报告, 每小时一次)
- DEBUG:    不推送 (只写日志)
"""
import os
import csv
import html
import json
import time
import logging
import threading
import requests
from collections import defaultdict

logger = logging.getLogger(__name__)


class TelegramNotifier:
    """Telegram 机器人通知 · v2 精简版"""
    
    def __init__(self, bot_token: str = None, chat_id: str = None, 
                 proxy: dict = None, trader=None, client=None):
        self.bot_token = bot_token or os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self.chat_id = chat_id or os.environ.get("TELEGRAM_CHAT_ID", "")
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        self.trader = trader
        self.client = client
        self.proxies = proxy or {
            'http': 'http://127.0.0.1:7897',
            'https': 'http://127.0.0.1:7897'
        }
        
        # 防刷屏: 同类消息最小间隔
        self._last_sent = defaultdict(float)  # {msg_type: timestamp}
        self._cooldowns = {
            "order_failed": 300,      # 下单失败: 5分钟内只发1次
            "signal_filtered": 600,   # 信号过滤: 10分钟内只发1次
            "risk_alert": 120,        # 风控: 2分钟内只发1次
            "status_report": 3600,    # 状态报告: 1小时1次
            "naked_position": 600,    # 裸仓: 10分钟1次
            "heartbeat": 3600,        # 心跳: 1小时1次
        }
        
        if self.bot_token and self.chat_id:
            logger.info("✅ Telegram 通知已初始化")
        else:
            logger.warning("⚠️ Telegram 通知缺少 BOT_TOKEN 或 CHAT_ID")
    
    def _calc_virtual_upl(self):
        """计算所有虚拟持仓的实时浮盈 (USDT)"""
        total_upl = 0.0
        details = []
        if not self.trader or not self.trader.dry_run or not self.client:
            return total_upl, details
        try:
            v_pos = self.trader.get_virtual_state()["position"]
            for inst, p in v_pos.items():
                try:
                    ticker = self.client.get_ticker(inst)
                    if ticker and ticker.get("data"):
                        last_px = float(ticker["data"][0]["last"])
                        entry_px = float(p["entry"])
                        size = float(p.get("size", 0))
                        try:
                            ct_val = self.client.get_contract_val(inst)
                        except Exception:
                            ct_val = 0.01
                        notional = size * ct_val * entry_px
                        if p["side"] == "long":
                            pnl = (last_px - entry_px) / entry_px * notional
                        else:
                            pnl = (entry_px - last_px) / entry_px * notional
                        total_upl += pnl
                        details.append((inst, p["side"], pnl, last_px))
                except Exception:
                    pass
        except Exception:
            pass
        return total_upl, details

    def _should_send(self, msg_type: str) -> bool:
        """检查是否应该发送 (防刷屏)"""
        cooldown = self._cooldowns.get(msg_type, 0)
        if cooldown == 0:
            return True
        last = self._last_sent[msg_type]
        if time.time() - last < cooldown:
            return False
        self._last_sent[msg_type] = time.time()
        return True

    def _send(self, text: str, parse_mode: str = "HTML"):
        """异步发送消息 (不阻塞主线程)"""
        if not self.bot_token or not self.chat_id:
            return False
        t = threading.Thread(target=self._send_sync, args=(text, parse_mode), daemon=True)
        t.start()
        return True

    def _send_sync(self, text: str, parse_mode: str = "HTML"):
        """实际发送 (单次，不重试避免重复)"""
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": True
        }
        url = f"{self.base_url}/sendMessage"
        
        try:
            resp = requests.post(url, json=payload, proxies=self.proxies, timeout=10)
            if resp.status_code == 200:
                return True
            elif resp.status_code == 400 and parse_mode:
                import re
                clean = re.sub(r'<[^>]+>', '', text)
                payload["text"] = clean
                payload["parse_mode"] = ""
                resp2 = requests.post(url, json=payload, proxies=self.proxies, timeout=10)
                return resp2.status_code == 200
            logger.error(f"Telegram 发送失败: {resp.status_code}")
            return False
        except Exception as e:
            logger.error(f"Telegram 发送异常: {e}")
            return False

    
    def send_text(self, text: str):
        """发送纯文本"""
        self._send(text, parse_mode="")
    
    # ==================== 🚀 系统 ====================
    
    def send_startup(self, strategy: str, balance: float, inst_id: str):
        """启动通知 — 精简"""
        msg = (
            f"🚀 <b>交易系统启动</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📌 {inst_id}\n"
            f"📊 策略: <b>{strategy}</b>\n"
            f"💰 余额: <b>${balance:.2f}</b>\n"
            f"🛡️ 风控: 回撤10% | SL=1.5×ATR\n"
            f"📰 新闻情绪: 已启用\n"
            f"⏰ {time.strftime('%H:%M:%S')}"
        )
        self._send(msg)
    
    def send_shutdown(self, reason: str = "用户主动停止"):
        """停止通知"""
        self._send(f"🔴 <b>系统停止</b> | {reason} | {time.strftime('%H:%M')}")
    
    def send_recovery(self, retry_count: int, error: str):
        """自我修复 — 有冷却"""
        if not self._should_send("recovery"):
            return
        self._send(
            f"🔄 <b>系统修复</b> 第{retry_count}次\n"
            f"❌ {error[:80]}\n"
            f"⏰ {time.strftime('%H:%M:%S')}"
        )
    
    # ==================== 📈 交易 ====================
    
    def send_order_success(self, action_reason: str, signal_type: str,
                           inst_id: str, price: float, size, 
                           ord_id: str, sl_price: float = 0, tp_price: float = 0,
                           balance: float = 0):
        """下单成功 — 始终推送"""
        # 判断方向
        is_close = "平" in action_reason or "close" in signal_type
        is_long = "多" in action_reason or "买" in action_reason or signal_type in ("buy",)
        
        if is_close:
            emoji, label = "🏁", "平仓"
        elif is_long:
            emoji, label = "🟢", "做多"
        else:
            emoji, label = "🔴", "做空"
        
        lines = [
            f"{emoji} <b>{label} · {inst_id}</b>",
            f"💵 {price} × {size}张",
        ]
        
        if sl_price > 0 and tp_price > 0:
            lines.append(f"🛡️ SL={sl_price} | TP={tp_price}")
        elif sl_price > 0:
            lines.append(f"🛡️ SL={sl_price}")
        
        if balance > 0:
            lines.append(f"💰 余额: ${balance:.2f}")
        
        lines.append(f"📝 {action_reason}")
        lines.append(f"⏰ {time.strftime('%H:%M:%S')}")
        
        self._send("\n".join(lines))
    
    def send_order_failed(self, action_reason: str, error_msg: str):
        """下单失败 — 5分钟内只发1次"""
        if not self._should_send("order_failed"):
            return
        self._send(
            f"❌ <b>下单失败</b>\n"
            f"📝 {action_reason}\n"
            f"⚠️ {error_msg[:80]}\n"
            f"⏰ {time.strftime('%H:%M:%S')}"
        )
    
    # ==================== 📊 信号 ====================
    
    def send_signal_filtered(self, signal_type: str, reasons: list):
        """信号过滤 — 10分钟内只发1次"""
        if not self._should_send("signal_filtered"):
            return
        self._send(
            f"🟡 信号被滤 | {signal_type}\n"
            f"原因: {', '.join(reasons[:2])}"
        )
    
    def send_trailing_stop(self, direction: str, entry: float, 
                           highest_or_lowest: float, exit_price: float, pnl_pct: float):
        """追踪止盈 — 始终推送"""
        emoji = "💰" if pnl_pct > 0 else "📉"
        self._send(
            f"🎯 <b>追踪止盈 · {direction}</b>\n"
            f"入场 {entry} → 极值 {highest_or_lowest:.5f}\n"
            f"平仓 {exit_price} | {emoji} <b>{pnl_pct:+.2f}%</b>\n"
            f"⏰ {time.strftime('%H:%M:%S')}"
        )
    
    # ==================== 🚨 风控 ====================
    
    def send_risk_alert(self, alert_type: str, details: str):
        """风控警报 — 2分钟冷却"""
        if not self._should_send("risk_alert"):
            return
        self._send(
            f"🚨 <b>{alert_type}</b>\n"
            f"{details[:200]}\n"
            f"⏰ {time.strftime('%H:%M:%S')}"
        )
    
    # ==================== 📋 状态报告 ====================
    
    def send_status_report(self, balance: float, drawdown: float,
                           ma_status: dict, grid_status: dict = None,
                           trade_count: int = 0):
        """状态报告 — 1小时1次，精简"""
        if not self._should_send("status_report"):
            return
        
        lines = [
            f"📋 <b>状态报告</b>",
            f"━━━━━━━━━━━━━━",
            f"💰 ${balance:.2f} | 📉 回撤 {drawdown:.1f}%",
            f"📊 今日 {trade_count} 笔",
        ]
        
        # 均线状态
        pos = ma_status.get('仓位', '无')
        if pos != '无':
            lines.append(f"📈 均线: {pos} | RSI={ma_status.get('RSI', '?')}")
        else:
            lines.append(f"📈 均线: 空仓待机")
        
        # 网格状态
        if grid_status:
            lines.append(f"📐 网格: {grid_status.get('价格区间', 'N/A')}")
        
        lines.append(f"⏰ {time.strftime('%H:%M')}")
        
        self._send("\n".join(lines))
    
    # ==================== 💰 资金费率 ====================
    
    def send_funding_rate(self, rate: float, action: str):
        """资金费率 — 有操作才推送"""
        if not action:
            return  # 无操作不推送
        self._send(f"💰 费率 {rate*100:.4f}% | {action}")

    # ==================== 💓 心跳通知 ====================

    def send_heartbeat(self, balance: float, position: str,
                       strategy_mode: str, ws_status: dict = None,
                       last_signal: str = "", cycle_count: int = 0):
        """每小时运行状态心跳 — 1小时冷却"""
        if not self._should_send("heartbeat"):
            return

        lines = [
            f"💓 <b>心跳</b> | 系统运行中",
            f"━━━━━━━━━━━━━━",
            f"💰 余额: <b>${balance:.2f}</b>",
        ]

        lines.append(f"📈 持仓: {position or '空仓'}")
        lines.append(f"📊 模式: {strategy_mode}")

        if ws_status and (ws_status.get("business_connected") or ws_status.get("public_connected")):
            biz = "✅" if ws_status.get("business_connected") else "❌"
            pub = "✅" if ws_status.get("public_connected") else "❌"
            lines.append(f"📡 WS: K线{biz} Ticker{pub}")

        if last_signal:
            lines.append(f"📋 最近: {last_signal}")

        lines.append(f"🔄 循环: {cycle_count}")
        lines.append(f"⏰ {time.strftime('%H:%M:%S')}")

        self._send("\n".join(lines))

    # ==================== 📋 每日报告 ====================

    def send_daily_report(self, report_text: str):
        """每日绩效报告 — 直接推送 (无冷却)"""
        self._send(report_text)



class FeishuNotifier:
    """飞书 Webhook 通知 (保留兼容)"""
    
    def __init__(self, webhook_url: str = None):
        self.webhook_url = webhook_url or ""
    
    def send_text(self, text: str):
        if not self.webhook_url:
            return
        try:
            payload = {"msg_type": "text", "content": {"text": text}}
            headers = {'Content-Type': 'application/json'}
            requests.post(self.webhook_url, data=json.dumps(payload), headers=headers, timeout=10)
        except Exception as e:
            logger.error(f"飞书通知发送异常: {e}")
    
    def send_startup(self, strategy, balance, inst_id):
        self.send_text(f"🚀 启动 | {inst_id} | {strategy} | ${balance:.2f}")
    
    def send_shutdown(self, reason=""):
        self.send_text(f"🔴 停止 | {reason}")
    
    def send_recovery(self, retry_count, error):
        self.send_text(f"🔄 修复 第{retry_count}次 | {error[:80]}")
    
    def send_order_success(self, action_reason, signal_type, inst_id, price, size, ord_id, **kw):
        self.send_text(f"✅ {action_reason} | {price} × {size}张")
    
    def send_order_failed(self, action_reason, error_msg):
        self.send_text(f"❌ 失败 | {action_reason} | {error_msg[:80]}")
    
    def send_risk_alert(self, alert_type, details):
        self.send_text(f"🚨 {alert_type} | {details}")
    
    def send_signal_filtered(self, signal_type, reasons):
        self.send_text(f"🟡 被滤 | {signal_type}")
    
    def send_trailing_stop(self, direction, entry, peak, exit_price, pnl_pct):
        self.send_text(f"🎯 止盈 | {direction} | {pnl_pct:+.2f}%")
    
    def send_status_report(self, balance, drawdown, ma_status, grid_status=None, trade_count=0):
        self.send_text(f"📋 ${balance:.2f} | 回撤{drawdown:.1f}% | {trade_count}笔")
    
    def send_funding_rate(self, rate, action):
        if action:
            self.send_text(f"💰 费率{rate*100:.4f}% | {action}")


class TelegramCommandHandler:
    """
    Telegram 命令监听器 — 后台线程轮询 getUpdates
    
    支持命令:
        /status  - 查看系统状态
        /pos     - 查看当前持仓
        /stop    - 暂停交易
        /start   - 恢复交易
        /log     - 查看最近日志
        /help    - 帮助
    """
    
    def __init__(self, notifier: TelegramNotifier, client=None,
                 risk_manager=None, all_strategies=None,
                 sentiment=None, config_path=None, trader=None):
        self.notifier = notifier
        self.trader = trader
        self.client = client
        self.risk_manager = risk_manager
        self.all_strategies = all_strategies or {}
        self.sentiment = sentiment
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "config.json")
        self._last_update_id = 0
        self._running = True
        self._paused = False  # 用户手动暂停交易
        self._thread = None
    
    def start(self):
        """启动命令监听 (后台线程)"""
        if not self.notifier or not self.notifier.bot_token:
            logger.info("📱 Telegram 命令监听: 跳过 (无配置)")
            return
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()
        logger.info("📱 Telegram 命令监听: 已启动")
    
    @property
    def is_paused(self):
        return self._paused
    
    def _poll_loop(self):
        """长轮询循环"""
        # 先清空旧消息
        self._flush_old_updates()
        
        while self._running:
            try:
                # 只获取并处理最新一条消息
                updates = self._get_updates()
                if updates:
                    # 只处理第一条，offset 立即更新
                    self._handle_update(updates[0])
            except Exception as e:
                logger.debug(f"Telegram 命令轮询异常: {e}")
            time.sleep(5)  # 每 5 秒轮询一次
    
    def _flush_old_updates(self):
        """启动时清空所有旧消息，避免处理历史命令"""
        try:
            resp = requests.get(
                f"{self.notifier.base_url}/getUpdates",
                params={"timeout": 1, "offset": -1},
                proxies=self.notifier.proxies,
                timeout=10
            )
            data = resp.json()
            if data.get("result"):
                # 设置为最后一条+1，确保跳过所有旧消息
                last_id = data["result"][-1]["update_id"]
                self._last_update_id = last_id + 1
                logger.info(f"📱 已清空 {len(data['result'])} 条旧消息")
        except Exception:
            pass
    
    def _get_updates(self):
        """获取新消息"""
        try:
            resp = requests.get(
                f"{self.notifier.base_url}/getUpdates",
                params={
                    "offset": self._last_update_id,
                    "timeout": 3,
                    "allowed_updates": '["message"]'
                },
                proxies=self.notifier.proxies,
                timeout=15
            )
            data = resp.json()
            results = data.get("result", [])
            return results
        except Exception:
            return []
    
    def _handle_update(self, update):
        """处理单条消息"""
        msg = update.get("message", {})
        text = msg.get("text", "").strip()
        chat_id = str(msg.get("chat", {}).get("id", ""))
        
        # 更新 offset（每条消息处理后立即更新，避免重复）
        update_id = update.get("update_id", 0)
        if update_id >= self._last_update_id:
            self._last_update_id = update_id + 1
        chat_id = str(msg.get("chat", {}).get("id", ""))
        
        # 安全校验: 只响应配置的 chat_id
        if chat_id != self.notifier.chat_id:
            return
        
        if not text.startswith("/"):
            return
        
        cmd = text.split()[0].lower().split("@")[0]  # 去掉 @botname
        
        handlers = {
            "/status": self._cmd_status,
            "/pos": self._cmd_pos,
            "/stop": self._cmd_stop,
            "/start": self._cmd_start,
            "/log": self._cmd_log,
            "/close": self._cmd_close,
            "/market": self._cmd_market,
            "/pnl": self._cmd_pnl,
            "/bias": lambda: self._cmd_bias(text),
            "/trades": self._cmd_trades,
            "/reset": self._cmd_reset,
            "/setbal": lambda: self._cmd_set_bal(text),
            "/help": self._cmd_help,
        }
        
        handler = handlers.get(cmd)
        if handler:
            try:
                handler()
            except Exception as e:
                self.notifier.send_text(f"❌ 命令执行失败: {e}")
        else:
            self.notifier.send_text(f"❓ 未知命令: {cmd}\n输入 /help 查看帮助")
    
    def _cmd_status(self):
        """查看系统状态"""
        is_dry = self.trader and self.trader.dry_run
        lines = [f"📊 <b>系统状态</b>", "━━━━━━━━━━━━━━"]
        
        # 余额
        bal = 0
        try:
            if is_dry:
                bal = self.trader._virtual_balance
            else:
                bal = self.client.get_usdt_balance() if self.client else 0
            lines.append(f"💰 余额: <b>${bal:.2f}</b>")
        except Exception:
            lines.append("💰 余额: 查询失败")
        
        # 实时浮盈和净值 (dry_run 模式)
        if is_dry and self.trader:
            try:
                upl, _ = self.notifier._calc_virtual_upl()
                net = bal + upl
                emoji = "🟢" if upl >= 0 else "🔴"
                lines.append(f"{emoji} 浮盈: <b>{upl:+.2f}U</b>")
                lines.append(f"💎 净值: <b>${net:.2f}</b>")
            except Exception:
                pass
        
        # 暂停状态
        if self._paused:
            lines.append("⏸️ 交易: <b>已暂停</b> (手动)")
        else:
            lines.append("▶️ 交易: <b>运行中</b>")
        
        # 风控
        if self.risk_manager:
            dd = self.risk_manager.current_drawdown * 100
            lines.append(f"📉 回撤: {dd:.1f}%")
        
        # 策略与市场状态 + 实时价格
        for inst_id, strats in self.all_strategies.items():
            active = sum(1 for _, s in strats if s.is_running)
            
            # 获取实时价格
            current_price = "查询中"
            try:
                ticker = self.client.get_ticker(inst_id)
                if ticker and ticker.get("data"):
                    current_price = float(ticker["data"][0]["last"])
            except Exception:
                pass
            
            # 获取市场状态 (ADX)
            adx_info = ""
            try:
                from main import calc_adx_from_client, decide_strategy_mode
                adx_val = calc_adx_from_client(self.client, inst_id)
                with open(self.config_path, "r", encoding="utf-8") as f:
                    tmp_cfg = json.load(f)
                _, adx_label = decide_strategy_mode(adx_val, config=tmp_cfg)
                adx_info = f"\n   {adx_label}"
            except Exception:
                pass
            
            # 检查当前持仓
            pos_info = ""
            if is_dry and self.trader:
                try:
                    v_pos = self.trader.get_virtual_state()["position"]
                    if inst_id in v_pos:
                        p = v_pos[inst_id]
                        side = "多" if p["side"] == "long" else "空"
                        entry = float(p["entry"])
                        size = p.get("size", 0)
                        sl = p.get("sl_price", 0)
                        tp = p.get("tp_price", 0)
                        pnl = 0
                        if current_price != "查询中":
                            if p["side"] == "long":
                                pnl = (current_price - entry) / entry * 100
                            else:
                                pnl = (entry - current_price) / entry * 100
                        emoji = "🟢" if pnl >= 0 else "🔴"
                        pos_info = f"\n   📍持仓: {side} {size}张 @ {entry} ({current_price}) {emoji}{pnl:+.2f}%\n   🛡️ SL: {sl} | TP: {tp}"
                except Exception:
                    pass
            
            lines.append(f"📋 {inst_id}: {current_price}{pos_info}\n   📊 {active}/{len(strats)} 策略{adx_info}")
        
        lines.append(f"⏰ {time.strftime('%H:%M:%S')}")
        self.notifier._send("\n".join(lines))
    
    def _cmd_pos(self):
        """查看持仓"""
        is_dry = self.trader and self.trader.dry_run
        lines = [f"📈 <b>当前持仓 ({'🧪 DRY-RUN' if is_dry else '💰 实盘'})</b>", "━━━━━━━━━━━━━━"]
        
        try:
            found = False
            if is_dry:
                # 虚拟持仓
                v_pos = self.trader.get_virtual_state()["position"]
                for inst, p in v_pos.items():
                    found = True
                    side = "多" if p["side"] == "long" else "空"
                    
                    # 实时计算浮盈 (USDT 金额 + 百分比)
                    upl_str = "未算"
                    try:
                        total_upl_all, details = self.notifier._calc_virtual_upl()
                        # 查找当前币种的详情
                        found_detail = False
                        for d_inst, d_side, d_pnl, d_px in details:
                            if d_inst == inst:
                                try:
                                    entry_px = float(p["entry"])
                                    size = float(p.get("size", 0))
                                    try:
                                        ct_val = self.client.get_contract_val(inst)
                                    except Exception:
                                        ct_val = 0.01
                                    notional = size * ct_val * entry_px
                                    pnl_pct = d_pnl / notional * 100 if notional > 0 else 0
                                    emoji = "🟢" if d_pnl >= 0 else "🔴"
                                    upl_str = f"{emoji} {d_pnl:+.2f}U ({pnl_pct:+.2f}%)"
                                    found_detail = True
                                    break
                                except Exception:
                                    pass
                        
                        if not found_detail:
                             # 如果 helper 没算出来, 这里保底重算一次 (虽然概率低)
                             if self.client:
                                ticker = self.client.get_ticker(inst)
                                if ticker and ticker.get("data"):
                                    last_px = float(ticker["data"][0]["last"])
                                    entry_px = float(p["entry"])
                                    size = float(p.get("size", 0))
                                    try:
                                        ct_val = self.client.get_contract_val(inst)
                                    except Exception:
                                        ct_val = 0.01
                                    notional = size * ct_val * entry_px
                                    if p["side"] == "long":
                                        pnl_usdt = (last_px - entry_px) / entry_px * notional
                                    else:
                                        pnl_usdt = (entry_px - last_px) / entry_px * notional
                                    pnl_pct = pnl_usdt / notional * 100 if notional > 0 else 0
                                    emoji = "🟢" if pnl_usdt >= 0 else "🔴"
                                    upl_str = f"{emoji} {pnl_usdt:+.2f}U ({pnl_pct:+.2f}%)"
                    except Exception as e:
                        upl_str = f"获取失败"
                        
                    lines.append(
                        f"⚪ {inst} {side}×{p['size']:.0f}\n"
                        f"   入场: {p['entry']} | 浮盈: {upl_str}"
                    )
            else:
                # 实盘持仓
                if not self.client:
                    self.notifier.send_text("❌ 客户端未初始化")
                    return
                result = self.client.get_positions()
                if result.get("data"):
                    for p in result["data"]:
                        amt = float(p.get("pos", "0"))
                        if amt == 0: continue
                        found = True
                        inst = p.get("instId", "?")
                        direction = "多" if amt > 0 else "空"
                        avg_px = p.get("avgPx", "?")
                        upl = float(p.get("upl", "0"))
                        emoji = "🟢" if upl >= 0 else "🔴"
                        lines.append(
                            f"{emoji} {inst} {direction}×{abs(amt):.0f}\n"
                            f"   入场: {avg_px} | 浮盈: {upl:+.2f}U"
                        )
            
            if not found:
                lines.append("📭 空仓")
            
            lines.append(f"⏰ {time.strftime('%H:%M:%S')}")
            self.notifier._send("\n".join(lines))
        except Exception as e:
            self.notifier.send_text(f"❌ 持仓查询失败: {e}")

    def _cmd_reset(self):
        """重置账户"""
        if not self.trader or not self.trader.dry_run:
            self.notifier.send_text("⚠️ 仅支持在 DRY-RUN 模式下操作")
            return
        
        initial = 134.0
        self.trader.reset_virtual_account(initial_balance=initial)
        self.notifier._send(f"♻️ <b>账户已重置</b>\n余额已恢复至 ${initial}\n持仓已全部清空")

    def _cmd_set_bal(self, text):
        """设置余额"""
        if not self.trader or not self.trader.dry_run:
            self.notifier.send_text("⚠️ 仅支持在 DRY-RUN 模式下操作")
            return
        
        parts = text.split()
        if len(parts) < 2:
            self.notifier.send_text("💡 用法: /setbal <金额>")
            return
        
        try:
            amount = float(parts[1])
            self.trader.set_virtual_balance(amount)
            self.notifier._send(f"💰 <b>余额已调整</b>\n当前余额: ${amount}")
        except ValueError:
            self.notifier.send_text("❌ 错误: 金额必须是数字")
        except Exception as e:
            self.notifier.send_text(f"❌ 操作失败: {e}")
    
    def _cmd_stop(self):
        """暂停交易"""
        self._paused = True
        self.notifier._send("⏸️ <b>交易已暂停</b>\n发送 /start 恢复")
        logger.warning("📱 用户通过 Telegram 暂停交易")
    
    def _cmd_start(self):
        """恢复交易"""
        self._paused = False
        self.notifier._send("▶️ <b>交易已恢复</b>")
        logger.info("📱 用户通过 Telegram 恢复交易")
    
    def _cmd_log(self):
        """查看最近日志"""
        log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trading.log")
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            tail = lines[-10:] if len(lines) >= 10 else lines
            text = "📋 <b>最近日志</b>\n━━━━━━━━━━━━━━\n"
            for line in tail:
                # 截断长行
                clean = html.escape(line.strip()[:100])
                text += f"<code>{clean}</code>\n"
            self.notifier._send(text)
        except Exception as e:
            self.notifier.send_text(f"❌ 日志读取失败: {e}")
    
    def _cmd_close(self):
        """一键平仓"""
        is_dry = self.trader and self.trader.dry_run
        
        if is_dry:
            # === Dry-run 虚拟平仓 ===
            try:
                v_pos = self.trader.get_virtual_state()["position"]
                if not v_pos:
                    self.notifier.send_text("📭 当前无持仓")
                    return
                
                closed = []
                total_pnl = 0.0
                insts_to_close = list(v_pos.keys())  # 避免迭代中修改
                
                for inst in insts_to_close:
                    p = v_pos[inst]
                    side_cn = "多" if p["side"] == "long" else "空"
                    entry_px = float(p["entry"])
                    size = float(p.get("size", 0))
                    
                    # 获取当前价
                    try:
                        ticker = self.client.get_ticker(inst)
                        last_px = float(ticker["data"][0]["last"]) if ticker and ticker.get("data") else entry_px
                    except Exception:
                        last_px = entry_px
                    
                    # 计算 PnL (与 trader._dry_run_order 一致)
                    try:
                        ct_val = self.client.get_contract_val(inst)
                    except Exception:
                        ct_val = 0.01
                    notional = size * ct_val * entry_px
                    if p["side"] == "long":
                        pnl = (last_px - entry_px) / entry_px * notional
                    else:
                        pnl = (entry_px - last_px) / entry_px * notional
                    
                    total_pnl += pnl
                    emoji = "🟢" if pnl >= 0 else "🔴"
                    closed.append(f"{emoji} {inst} {side_cn}×{size:.0f} | PnL: {pnl:+.2f}U")
                    
                    # 从虚拟持仓中移除并结算
                    self.trader._virtual_position.pop(inst, None)
                    self.trader._virtual_balance += pnl
                    self.trader._virtual_pnl_total += pnl
                
                self.trader._save_virtual_state()
                
                self.notifier._send(
                    "🚨 <b>一键平仓</b>\n━━━━━━━━━━━━━━\n" +
                    "\n".join(closed) +
                    f"\n━━━━━━━━━━━━━━\n💰 总PnL: {total_pnl:+.2f}U\n⚖️ 余额: ${self.trader._virtual_balance:.2f}"
                )
                logger.warning(f"📱 用户通过 Telegram 一键平仓(DRY): {closed}")
            except Exception as e:
                self.notifier.send_text(f"❌ 平仓失败: {e}")
            return
        
        # === 实盘平仓 ===
        if not self.client:
            self.notifier.send_text("❌ 客户端未初始化")
            return
        
        try:
            result = self.client.get_positions()
            closed = []
            if result.get("data"):
                for p in result["data"]:
                    amt = float(p.get("pos", "0"))
                    if amt == 0:
                        continue
                    inst = p.get("instId")
                    side = "sell" if amt > 0 else "buy"
                    sz = str(abs(int(amt)))
                    try:
                        close_result = self.client.place_order(
                            inst_id=inst, td_mode="cross",
                            side=side, ord_type="market", sz=sz,
                            reduce_only=True
                        )
                        if close_result.get("code") == "0":
                            closed.append(f"✅ {inst} {'多' if amt > 0 else '空'}×{sz}")
                        else:
                            closed.append(f"❌ {inst}: {close_result.get('msg', '失败')}")
                    except Exception as e:
                        closed.append(f"❌ {inst}: {e}")
            
            if closed:
                self.notifier._send(
                    "🚨 <b>一键平仓</b>\n━━━━━━━━━━━━━━\n" + "\n".join(closed)
                )
                logger.warning(f"📱 用户通过 Telegram 一键平仓: {closed}")
            else:
                self.notifier.send_text("📭 当前无持仓")
        except Exception as e:
            self.notifier.send_text(f"❌ 平仓失败: {e}")
    
    def _cmd_market(self):
        """市场概览"""
        lines = ["🌍 <b>市场概览</b>", "━━━━━━━━━━━━━━"]
        
        # BTC/ETH 价格
        try:
            btc = self.client.get_ticker("BTC-USDT-SWAP")
            if btc.get("data"):
                btc_px = float(btc["data"][0]["last"])
                lines.append(f"₿ BTC: <b>${btc_px:,.0f}</b>")
        except Exception:
            pass
        
        try:
            eth = self.client.get_ticker("ETH-USDT-SWAP")
            if eth.get("data"):
                eth_px = float(eth["data"][0]["last"])
                lines.append(f"Ξ ETH: <b>${eth_px:,.2f}</b>")
        except Exception:
            pass
        
        # F&G + 情绪
        if self.sentiment:
            try:
                result = self.sentiment.analyze("ETH-USDT-SWAP")
                score = result.get("score", 0)
                fg = result.get("news", {}).get("fear_greed", {}).get("score")
                if fg is not None:
                    lines.append(f"😱 F&G: <b>{fg}</b>")
                if score:
                    lines.append(f"📊 ETH情绪评分: <b>{score:.0f}</b>/100")
            except Exception:
                pass
        
        # ADX
        try:
            from main import calc_adx_from_client
            adx = calc_adx_from_client(self.client, "ETH-USDT-SWAP")
            lines.append(f"📈 ETH ADX: <b>{adx:.0f}</b>")
        except Exception:
            pass
        
        lines.append(f"⏰ {time.strftime('%H:%M:%S')}")
        self.notifier._send("\n".join(lines))
    
    def _cmd_pnl(self):
        """今日盈亏"""
        try:
            if self.trader and self.trader.dry_run:
                state = self.trader.get_virtual_state()
                balance = state.get("balance", 0)
                lines = [
                    "📊 <b>账户盈亏</b>",
                    "━━━━━━━━━━━━━━",
                    f"💰 余额: <b>${balance:.2f}</b>",
                    f"📈 累计已实现: <b>{state['pnl_total']:+.2f}U</b>",
                    f"🧾 成交笔数: {state['trade_count']} 笔",
                    f"⏰ {time.strftime('%H:%M:%S')}",
                ]
                self.notifier._send("\n".join(lines))
                return

            from trade_stats import load_okx_fills, calculate_daily_report, format_daily_report_text
            bal = self.client.get_usdt_balance() if self.client else 0
            fills = load_okx_fills(self.client)
            if fills:
                report = calculate_daily_report(fills, balance=bal)
                text = format_daily_report_text(report)
                self.notifier._send(text)
            else:
                self.notifier.send_text(f"📊 今日无成交\n💰 余额: ${bal:.2f}")
        except Exception as e:
            self.notifier.send_text(f"❌ 盈亏查询失败: {e}")
    
    def _cmd_bias(self, text):
        """切换方向偏好: /bias long 或 /bias ETH short 或 /bias clear"""
        parts = text.strip().split()
        if len(parts) < 2:
            self.notifier.send_text(
                "用法:\n/bias long  - 所有币种偏做多\n/bias short - 所有币种偏做空\n"
                "/bias BTC long - BTC偏做多\n/bias ETH short - ETH偏做空\n/bias clear - 取消全部偏好"
            )
            return
        
        # 解析参数: /bias [INSTRUMENT] <direction>
        if len(parts) >= 3:
            # /bias ETH long  或  /bias BTC short
            coin = parts[1].upper()
            new_bias = parts[2].lower()
            target_insts = [f"{coin}-USDT-SWAP"]
        else:
            # /bias long  (all instruments)
            new_bias = parts[1].lower()
            target_insts = list(self.all_strategies.keys()) if self.all_strategies else ["ETH-USDT-SWAP"]
        
        if new_bias not in ("long", "short", "clear"):
            self.notifier.send_text("❌ 参数错误，用: long / short / clear")
            return
        
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            
            if "user_bias" not in config:
                config["user_bias"] = {}
            
            labels = []
            for inst in target_insts:
                if new_bias == "clear":
                    config["user_bias"].pop(inst, None)
                    labels.append(f"{inst} 恢复双向")
                else:
                    config["user_bias"][inst] = new_bias
                    labels.append(f"{inst} 偏{'做多' if new_bias == 'long' else '做空'}")
            
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            
            label_str = "\n".join(labels)
            self.notifier._send(f"🔄 <b>方向偏好已切换</b>\n{label_str}\n下次开仓生效")
            logger.info(f"📱 用户通过 Telegram 切换偏好: {labels}")
        except Exception as e:
            self.notifier.send_text(f"❌ 切换失败: {e}")
    
    def _cmd_trades(self):
        """最近交易记录"""
        csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trades.csv")
        try:
            with open(csv_path, "r", encoding="utf-8", newline="") as f:
                rows = list(csv.DictReader(f))

            if not rows:
                self.notifier.send_text("📭 暂无交易记录")
                return

            tail = rows[-5:]
            text = "📋 <b>最近交易</b>\n━━━━━━━━━━━━━━\n"

            for row in tail:
                ts = row.get("time", "")[:16]
                inst = row.get("inst_id", "?")
                side = row.get("side", "?")
                price = row.get("price", "?")
                size = row.get("size", "?")
                status = row.get("status", "?")
                pnl_pct = row.get("pnl_pct", "")
                reason = html.escape((row.get("action", "") or "")[:36])
                side_map = {
                    "buy": "买",
                    "sell": "卖",
                    "long": "多",
                    "short": "空",
                }
                side_label = side_map.get(side, side)
                size_label = size
                try:
                    if float(size) <= 0:
                        size_label = "未记录"
                except (TypeError, ValueError):
                    pass
                summary = html.escape(f"{ts} {inst} {side_label}@{price} × {size_label}")
                extra = f" | PnL {pnl_pct}%" if pnl_pct not in ("", "0", "0.00") else ""
                text += f"<code>{summary}</code>\n"
                text += f"状态: {html.escape(status)}{extra}\n"
                if reason:
                    text += f"原因: {reason}\n"

            self.notifier._send(text)
        except Exception as e:
            self.notifier.send_text(f"❌ 记录读取失败: {e}")
    
    def _cmd_help(self):
        """帮助"""
        self.notifier._send(
            "🤖 <b>OKX Bot 命令</b>\n"
            "━━━━━━━━━━━━━━\n"
            "📊 /status  - 系统状态\n"
            "📈 /pos     - 当前持仓\n"
            "🌍 /market  - 市场概览\n"
            "💰 /pnl     - 今日盈亏\n"
            "📋 /trades  - 最近交易\n"
            "━━━━━━━━━━━━━━\n"
            "⏸️ /stop    - 暂停交易\n"
            "▶️ /start   - 恢复交易\n"
            "🚨 /close   - 一键平仓\n"
            "🔄 /bias long|short|clear - 切 ETH 偏好\n"
            "━━━━━━━━━━━━━━\n"
            "📝 /log     - 最近日志\n"
            "/help    - 本帮助"
        )
