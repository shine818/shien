"""
OKX WebSocket 实时行情引擎 v2
替代轮询模式: K线收盘即触发策略分析

功能:
1. 订阅多币种 1H K线 — 收盘时自动回调策略 (via /ws/v5/business)
2. 订阅实时 Ticker — 持仓中持续检查追踪止盈 (via /ws/v5/public)
3. 自动重连 (断线 5s 后重连)
4. 支持代理

OKX WebSocket 文档:
  K线频道: wss://ws.okx.com:8443/ws/v5/business  ← candle1H 等
  Ticker频道: wss://ws.okx.com:8443/ws/v5/public  ← tickers 等
"""
import json
import time
import logging
import threading
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import websocket
except ImportError:
    logger.error("请安装: pip install websocket-client")
    raise


class OKXWebSocketFeed:
    """
    OKX 实时行情推送 v2

    v2 修复: K线使用 /ws/v5/business 端点 (OKX 要求)
    """

    WS_PUBLIC = "wss://ws.okx.com:8443/ws/v5/public"
    WS_BUSINESS = "wss://ws.okx.com:8443/ws/v5/business"
    RECONNECT_DELAY = 5
    PING_INTERVAL = 25
    PING_TIMEOUT = 20

    def __init__(self,
                 instruments: List[str],
                 on_candle_close: Optional[Callable] = None,
                 on_price_update: Optional[Callable] = None,
                 proxy: Optional[Dict] = None,
                 bar: str = "1H",
                 price_throttle: float = 5.0):
        self.instruments = instruments
        self.on_candle_close = on_candle_close
        self.on_price_update = on_price_update
        self.bar = bar
        self.price_throttle = price_throttle

        # 代理
        self._proxy_host = None
        self._proxy_port = None
        if proxy:
            proxy_url = proxy.get("http") or proxy.get("https")
            if proxy_url:
                parts = proxy_url.replace("http://", "").replace("https://", "").split(":")
                self._proxy_host = parts[0]
                self._proxy_port = int(parts[1]) if len(parts) > 1 else 7890

        # 状态
        self._ws_business = None   # K线连接
        self._ws_public = None     # Ticker连接
        self._thread_business = None
        self._thread_public = None
        self._running = False
        self._business_connected = False
        self._public_connected = False
        self._last_price_cb = {}
        self._reconnect_count_business = 0
        self._reconnect_count_public = 0
        # 健康心跳: 记录最后收到消息的时间
        self._last_msg_time = {"business": 0.0, "public": 0.0}

    def start(self):
        """后台线程启动双 WebSocket"""
        if self._running:
            return
        self._running = True

        # K线连接 (business)
        if self.on_candle_close:
            self._thread_business = threading.Thread(
                target=self._run_forever,
                args=("business",),
                daemon=True
            )
            self._thread_business.start()
            logger.info(f"📡 WebSocket 启动 | {len(self.instruments)} 个币种 | bar={self.bar}")

        # Ticker连接 (public)
        if self.on_price_update:
            self._thread_public = threading.Thread(
                target=self._run_forever,
                args=("public",),
                daemon=True
            )
            self._thread_public.start()

    def stop(self):
        self._running = False
        for ws in (self._ws_business, self._ws_public):
            if ws:
                try:
                    ws.close()
                except Exception:
                    pass
        logger.info("📡 WebSocket 已停止")

    @property
    def is_connected(self):
        """K线连接是否活跃 (核心判断依据)"""
        if self.on_candle_close:
            return self._business_connected
        return self._public_connected

    def is_healthy(self, timeout: float = 120) -> bool:
        """检查 WebSocket 是否健康 (超过 timeout 秒没收到消息 → 不健康)"""
        if not self.is_connected:
            return False
        now = time.time()
        # 检查 business 连接 (K线)
        if self.on_candle_close:
            last = self._last_msg_time.get("business", 0)
            if last > 0 and (now - last) > timeout:
                return False
        # 检查 public 连接 (Ticker, 更频繁所以超时更短)
        if self.on_price_update:
            last = self._last_msg_time.get("public", 0)
            if last > 0 and (now - last) > timeout:
                return False
        return True

    def force_reconnect(self):
        """强制重连所有 WebSocket (供外部调用)"""
        logger.warning("📡 强制重连 WebSocket...")
        for ws in (self._ws_business, self._ws_public):
            if ws:
                try:
                    ws.close()
                except Exception:
                    pass

    def _get_proxy_kwargs(self):
        if self._proxy_host:
            return {
                "http_proxy_host": self._proxy_host,
                "http_proxy_port": self._proxy_port,
                "proxy_type": "http",
            }
        return {}

    # ─── 连接循环 ───

    def _run_forever(self, conn_type: str):
        """主循环: 连接 → 订阅 → 监听 → 断线重连"""
        while self._running:
            try:
                if conn_type == "business":
                    url = self.WS_BUSINESS
                    logger.info(f"📡 连接 K线 WebSocket: {url}")
                else:
                    url = self.WS_PUBLIC
                    logger.info(f"📡 连接 Ticker WebSocket: {url}")

                ws = websocket.WebSocketApp(
                    url,
                    on_message=lambda ws, msg: self._on_message(ws, msg, conn_type),
                    on_error=lambda ws, err: self._on_error(ws, err, conn_type),
                    on_close=lambda ws, code, msg: self._on_close(ws, code, msg, conn_type),
                    on_open=lambda ws: self._on_open(ws, conn_type),
                )

                if conn_type == "business":
                    self._ws_business = ws
                else:
                    self._ws_public = ws

                proxy_kwargs = self._get_proxy_kwargs()
                if proxy_kwargs:
                    logger.info(f"📡 代理: {self._proxy_host}:{self._proxy_port} (HTTP CONNECT)")

                ws.run_forever(
                    ping_interval=self.PING_INTERVAL,
                    ping_timeout=self.PING_TIMEOUT,
                    **proxy_kwargs
                )

            except Exception as e:
                logger.error(f"📡 WebSocket({conn_type}) 异常: {e}")

            # 断线
            if conn_type == "business":
                self._business_connected = False
                self._reconnect_count_business += 1
                count = self._reconnect_count_business
            else:
                self._public_connected = False
                self._reconnect_count_public += 1
                count = self._reconnect_count_public

            if self._running:
                delay = min(self.RECONNECT_DELAY * (2 ** min(count, 5)), 120)
                logger.warning(f"📡 {delay:.0f}s 后重连 {conn_type} (第{count}次, 指数退避)")
                time.sleep(delay)

    def _on_open(self, ws, conn_type: str):
        """连接成功 → 订阅频道"""
        if conn_type == "business":
            self._business_connected = True
            self._reconnect_count_business = 0
            logger.info("📡 K线 WebSocket 已连接 (/ws/v5/business)")

            # 订阅 K线收盘
            candle_args = [{"channel": f"candle{self.bar}", "instId": inst}
                           for inst in self.instruments]
            ws.send(json.dumps({"op": "subscribe", "args": candle_args}))
            logger.info(f"📡 订阅 K线: {self.bar} × {len(self.instruments)} 币种")

        else:
            self._public_connected = True
            self._reconnect_count_public = 0
            logger.info("📡 Ticker WebSocket 已连接 (/ws/v5/public)")

            # 订阅实时 Ticker
            ticker_args = [{"channel": "tickers", "instId": inst}
                           for inst in self.instruments]
            ws.send(json.dumps({"op": "subscribe", "args": ticker_args}))
            logger.info(f"📡 订阅 Ticker: {len(self.instruments)} 币种")

    def _on_message(self, ws, message, conn_type: str):
        """收到消息"""
        try:
            data = json.loads(message)
            # 更新健康心跳时间
            self._last_msg_time[conn_type] = time.time()

            # 订阅确认
            if data.get("event") == "subscribe":
                ch = data.get("arg", {}).get("channel", "?")
                inst = data.get("arg", {}).get("instId", "?")
                logger.info(f"📡 订阅成功: {ch} / {inst} ({conn_type})")
                return

            if data.get("event") == "error":
                logger.error(f"📡 订阅错误({conn_type}): {data}")
                return

            # 数据推送
            arg = data.get("arg", {})
            channel = arg.get("channel", "")
            inst_id = arg.get("instId", "")
            items = data.get("data", [])

            if not items:
                return

            # ─── K线收盘 ───
            if channel.startswith("candle") and self.on_candle_close:
                for item in items:
                    # OKX K线格式: [ts, o, h, l, c, vol, volCcy, volCcyQuote, confirm]
                    # confirm = "1" 表示这根K线已收盘
                    confirm = item[-1] if len(item) > 8 else item[6] if len(item) > 6 else "0"
                    if str(confirm) == "1":
                        logger.info(f"🕐 K线收盘 | {inst_id} | "
                                    f"O={item[1]} H={item[2]} L={item[3]} C={item[4]} V={item[5]}")
                        try:
                            self.on_candle_close(inst_id, {
                                "ts": item[0],
                                "open": float(item[1]),
                                "high": float(item[2]),
                                "low": float(item[3]),
                                "close": float(item[4]),
                                "vol": float(item[5]),
                            })
                        except Exception as e:
                            logger.error(f"策略回调异常: {e}")

            # ─── 实时价格 (Ticker) ───
            elif channel == "tickers" and self.on_price_update:
                for item in items:
                    price = float(item.get("last", 0))
                    if price <= 0:
                        continue

                    # 节流
                    now = time.time()
                    last = self._last_price_cb.get(inst_id, 0)
                    if now - last < self.price_throttle:
                        continue
                    self._last_price_cb[inst_id] = now

                    try:
                        self.on_price_update(inst_id, price, item.get("ts"))
                    except Exception as e:
                        logger.error(f"价格回调异常: {e}")

        except json.JSONDecodeError:
            pass
        except Exception as e:
            logger.error(f"📡 消息处理异常({conn_type}): {e}")

    def _on_error(self, ws, error, conn_type: str):
        logger.error(f"📡 WebSocket({conn_type}) 错误: {error}")

    def _on_close(self, ws, close_status_code, close_msg, conn_type: str):
        if conn_type == "business":
            self._business_connected = False
        else:
            self._public_connected = False
        logger.warning(f"📡 WebSocket({conn_type}) 断开: code={close_status_code} msg={close_msg}")

    def get_status(self):
        return {
            "connected": self.is_connected,
            "business_connected": self._business_connected,
            "public_connected": self._public_connected,
            "instruments": self.instruments,
            "bar": self.bar,
            "reconnect_business": self._reconnect_count_business,
            "reconnect_public": self._reconnect_count_public,
        }
