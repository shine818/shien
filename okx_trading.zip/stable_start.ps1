param(
    [switch]$Restart,
    [switch]$StatusOnly,
    [ValidateSet("both", "ma", "grid")]
    [string]$Strategy = "both",
    [switch]$NoWs
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$LogsDir = Join-Path $Root "logs"
$StatusPath = Join-Path $Root "runtime_status.json"
New-Item -ItemType Directory -Force -Path $LogsDir | Out-Null

function Get-OkxPythonProcesses {
    Get-CimInstance Win32_Process |
        Where-Object {
            $_.Name -like "python*" -and
            $_.CommandLine -match "(^|[\s`"])watchdog\.py([\s`"]|$)"  # 只匹配 watchdog，main.py 由 watchdog 管理
        }
}

function Get-RunMode {
    param([object[]]$Processes)

    if ($Processes | Where-Object { $_.CommandLine -match "(^|[\s`"])watchdog\.py([\s`"]|$)" }) {
        return "watchdog"
    }
    if ($Processes | Where-Object { $_.CommandLine -match "(^|[\s`"])main\.py([\s`"]|$)" }) {
        return "direct_main"
    }
    return "none"
}

function Convert-CreationDate {
    param([object]$Value)

    if ($null -eq $Value) {
        return $null
    }
    if ($Value -is [datetime]) {
        return $Value.ToString("o")
    }
    return [string]$Value
}

function Write-RunStatus {
    param(
        [string]$Status,
        [string]$Message,
        [object[]]$Processes = @(),
        [Nullable[int]]$WatchdogPid = $null,
        [string]$StdoutLog = "",
        [string]$StderrLog = ""
    )

    $payload = [ordered]@{
        timestamp = (Get-Date).ToString("o")
        cwd = $Root
        status = $Status
        message = $Message
        current_run_mode = Get-RunMode -Processes $Processes
        intended_start_mode = if ($NoWs) { "watchdog_no_ws" } else { "watchdog_ws" }
        strategy = $Strategy
        watchdog_pid = $WatchdogPid
        stdout_log = $StdoutLog
        stderr_log = $StderrLog
        important_files = [ordered]@{
            handoff = "AGENT_HANDOFF.md"
            trading_log = "trading.log"
            watchdog_log = "watchdog.log"
            watchdog_heartbeat = "watchdog_heartbeat.txt"
            dry_run_state = "dry_run_state.json"
            restart_log = "restart_log.txt"
        }
        processes = @(
            foreach ($p in $Processes) {
                [ordered]@{
                    pid = $p.ProcessId
                    command_line = $p.CommandLine
                    creation_date = Convert-CreationDate -Value $p.CreationDate
                }
            }
        )
    }

    $payload | ConvertTo-Json -Depth 8 | Set-Content -Path $StatusPath -Encoding UTF8
}

function Stop-OkxProcesses {
    param([object[]]$Processes)

    if ($Processes.Count -eq 0) {
        Write-Host "No watchdog process to stop."
        return
    }
    
    # 只停止 watchdog，main.py 由 watchdog 自己管理
    foreach ($p in $Processes) {
        Write-Host "Stopping Watchdog PID $($p.ProcessId)"
        $result = Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        if ($LASTEXITCODE -ne 0 -and $result -eq $null) {
            Write-Host "  WARNING: Failed to stop PID $($p.ProcessId)"
        } else {
            Write-Host "  Stopped PID $($p.ProcessId)"
        }
    }
    
    # 等待 watchdog 完全退出
    Start-Sleep -Seconds 3
    
    # 验证 watchdog 已停止
    $remaining = @(Get-OkxPythonProcesses)
    if ($remaining.Count -gt 0) {
        Write-Host "WARNING: $($remaining.Count) watchdog still running:"
        foreach ($p in $remaining) {
            Write-Host "  PID $($p.ProcessId): $($p.CommandLine)"
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 2
    }
    
    $still_remaining = @(Get-OkxPythonProcesses)
    if ($still_remaining.Count -gt 0) {
        Write-Host "ERROR: Cannot stop watchdog!"
    } else {
        Write-Host "Watchdog stopped successfully."
    }
}

if (-not (Test-Path (Join-Path $Root "config.json"))) {
    Write-RunStatus -Status "failed" -Message "config.json not found"
    throw "config.json not found in $Root"
}

$existing = @(Get-OkxPythonProcesses)

if ($StatusOnly) {
    if ($existing.Count -gt 0) {
        Write-RunStatus -Status "running" -Message "Existing OKX python process found" -Processes $existing
        $existing | Select-Object ProcessId, CommandLine, CreationDate | Format-List
    } else {
        Write-RunStatus -Status "stopped" -Message "No OKX python process found"
        Write-Host "No OKX python process found."
    }
    exit 0
}

if ($existing.Count -gt 0 -and -not $Restart) {
    Write-RunStatus -Status "already_running" -Message "Existing process found; not starting a duplicate" -Processes $existing
    Write-Host "Existing OKX process found. Not starting a duplicate."
    $existing | Select-Object ProcessId, CommandLine, CreationDate | Format-List
    Write-Host "Use .\stable_start.ps1 -Restart only when you intentionally want watchdog to take over."
    exit 0
}

if ($Restart -and $existing.Count -gt 0) {
    Write-Host "Stopping existing watchdog process..."
    Stop-OkxProcesses -Processes $existing
    Start-Sleep -Seconds 3
    
    # 额外检查：确保没有残留的 main.py 进程（可能由之前的 watchdog 启动但未清理）
    $main_procs = @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -like "python*" -and $_.CommandLine -match "main\.py"
    })
    if ($main_procs.Count -gt 0) {
        Write-Host "WARNING: Found $($main_procs.Count) orphaned main.py process(es), killing..."
        foreach ($p in $main_procs) {
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
            Write-Host "  Stopped PID $($p.ProcessId)"
        }
        Start-Sleep -Seconds 2
    }
    
    # 最终验证
    $all_procs = @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -like "python*" -and ($_.CommandLine -match "main\.py" -or $_.CommandLine -match "watchdog\.py")
    })
    if ($all_procs.Count -gt 0) {
        Write-Host "WARNING: $($all_procs.Count) process(es) still running:"
        foreach ($p in $all_procs) {
            Write-Host "  PID $($p.ProcessId): $($p.CommandLine)"
        }
    }
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-RunStatus -Status "failed" -Message "python command not found"
    throw "python command not found"
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$stdoutLog = Join-Path $LogsDir "stable_start_$stamp.out.log"
$stderrLog = Join-Path $LogsDir "stable_start_$stamp.err.log"

$watchdogArgs = @("watchdog.py", "--strategy", $Strategy)
if ($NoWs) {
    $watchdogArgs += "--no-ws"
}

$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$proc = Start-Process `
    -FilePath $python.Source `
    -ArgumentList $watchdogArgs `
    -WorkingDirectory $Root `
    -WindowStyle Hidden `
    -RedirectStandardOutput $stdoutLog `
    -RedirectStandardError $stderrLog `
    -PassThru

Start-Sleep -Seconds 5

if ($proc.HasExited) {
    Write-RunStatus -Status "failed" -Message "watchdog exited immediately" -WatchdogPid $proc.Id -StdoutLog $stdoutLog -StderrLog $stderrLog
    Write-Host "Watchdog exited immediately. Check $stderrLog"
    exit 1
}

$running = @(Get-OkxPythonProcesses)
Write-RunStatus -Status "started" -Message "watchdog started" -Processes $running -WatchdogPid $proc.Id -StdoutLog $stdoutLog -StderrLog $stderrLog

Write-Host "OKX watchdog started."
Write-Host "Watchdog PID: $($proc.Id)"
Write-Host "Status file: $StatusPath"
Write-Host "Stdout log: $stdoutLog"
Write-Host "Stderr log: $stderrLog"
