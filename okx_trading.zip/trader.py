"""
交易执行引擎 v2.0
协调 API 客户端、策略和风控模块，完成下单和盈亏记录
v2: 智能限价单 + 金字塔加仓 + 时间过滤
"""
import os
import csv
import time
import json
import logging
from datetime import datetime, timezone
from typing import List, Optional
from strategies.base import Signal, TradeAction
from okx_client import OKXClient
from risk_manager import RiskManager

logger = logging.getLogger(__name__)

CSV_PATH = "trades.csv"
STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dry_run_state.json")


# 活跃交易时段 (UTC)
ACTIVE_HOURS = {
    "asia":  (0, 8),    # 亚盘 00:00-08:00 UTC
    "us":    (14, 21),   # 美盘 14:00-21:00 UTC
}
REDUCED_HOURS = (8, 14)  # 欧盘过渡: 仓位减半


class Trader:
    """交易执行引擎 v2.1 (支持 dry-run 模拟模式)"""

    def __init__(self, client: OKXClient, risk_manager: RiskManager,
                 notifier=None, guard=None, use_limit=True, pyramid_enabled=True,
                 time_filter=True, limit_timeout=30, dry_run=False,
                 dry_run_balance=100.0):
        self.client = client
        self.risk_manager = risk_manager
        self.notifier = notifier
        self.guard = guard  # PositionGuard 安全守卫
        self.active_orders = []
        self.trade_history = []
        self.use_limit = use_limit
        self.pyramid_enabled = pyramid_enabled
        self.time_filter = time_filter
        self.limit_timeout = limit_timeout      # 限价单超时秒数
        self.dry_run = dry_run                  # 模拟模式 (不下真单)
        
        # 🧪 Dry-run 虚拟账户
        self._virtual_balance = dry_run_balance
        self._virtual_position = {}  # {inst_id: {"side": "long"/"short", "entry": px, "size": sz}}
        self._virtual_pnl_total = 0.0
        self._virtual_trade_count = 0
        self._virtual_ord_counter = 0
        
        # 金字塔状态 {inst_id: {"entries": [...], "direction": "long"/"short"}}
        self.pyramid_state = {}
        self._trade_counter = 0  # 当日交易计数
        self._seen_algo_ids = set()  # 已记录的止盈止损委托 ID
        
        if dry_run:
            self._load_virtual_state()
            logger.info(f"🧪 DRY-RUN 模拟模式启用 | 虚拟余额: ${self._virtual_balance:.2f}")
        
        self._init_csv()

    def _load_virtual_state(self):
        """从 JSON 文件加载虚拟账户状态"""
        if os.path.exists(STATE_PATH):
            try:
                with open(STATE_PATH, "r", encoding="utf-8") as f:
                    state = json.load(f)
                self._virtual_balance = state.get("balance", self._virtual_balance)
                self._virtual_position = state.get("position", {})
                self._virtual_pnl_total = state.get("pnl_total", 0.0)
                self._virtual_trade_count = state.get("trade_count", 0)
                self._virtual_ord_counter = state.get("ord_counter", 0)
                self._backfill_virtual_protection()
                logger.info(f"📥 已加载虚拟账户持久化状态 | 余额: ${self._virtual_balance:.2f}")
            except Exception as e:
                logger.warning(f"⚠️ 虚拟账户状态加载失败: {e}")

    def _backfill_virtual_protection(self):
        """从本地交易记录补齐旧 dry-run 持仓缺失的 SL/TP。"""
        if not self._virtual_position or not os.path.exists(CSV_PATH):
            return
        try:
            with open(CSV_PATH, "r", newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        except Exception as e:
            logger.warning(f"⚠️ 虚拟仓位保护价补齐失败: {e}")
            return

        changed = False
        for inst_id, position in self._virtual_position.items():
            if position.get("sl_price") and position.get("tp_price"):
                continue
            side = position.get("side")
            entry = float(position.get("entry", 0) or 0)
            expected_side = "buy" if side == "long" else "sell"
            for row in reversed(rows):
                if row.get("inst_id") != inst_id or row.get("side") != expected_side:
                    continue
                try:
                    row_price = float(row.get("price", "0") or "0")
                except (TypeError, ValueError):
                    row_price = 0
                if entry > 0 and row_price > 0 and abs(row_price - entry) / entry > 0.001:
                    continue
                try:
                    sl_price = float(row.get("sl_price", "0") or "0")
                    tp_price = float(row.get("tp_price", "0") or "0")
                except (TypeError, ValueError):
                    continue
                if sl_price > 0:
                    position["sl_price"] = sl_price
                    changed = True
                if tp_price > 0:
                    position["tp_price"] = tp_price
                    changed = True
                break

        if changed:
            self._save_virtual_state()
            logger.info("🧪 已从交易记录补齐 dry-run 持仓 SL/TP")

    def _save_virtual_state(self):
        """保存虚拟账户状态到 JSON 文件"""
        try:
            state = {
                "balance": self._virtual_balance,
                "position": self._virtual_position,
                "pnl_total": self._virtual_pnl_total,
                "trade_count": self._virtual_trade_count,
                "ord_counter": self._virtual_ord_counter,
                "last_update": datetime.now().isoformat()
            }
            with open(STATE_PATH, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"⚠️ 虚拟账户状态保存失败: {e}")

    # ─── 虚拟账户管理接口 ───

    def get_virtual_state(self) -> dict:
        """获取当前虚拟账户数据"""
        return {
            "balance": self._virtual_balance,
            "position": self._virtual_position,
            "pnl_total": self._virtual_pnl_total,
            "trade_count": self._virtual_trade_count
        }

    def calculate_virtual_upl(self) -> tuple[float, list]:
        """计算 dry-run 持仓当前未实现盈亏。"""
        total_upl = 0.0
        details = []
        if not self.dry_run or not self._virtual_position:
            return total_upl, details

        for inst_id, position in self._virtual_position.items():
            try:
                ticker = self.client.get_ticker(inst_id)
                if not ticker or not ticker.get("data"):
                    continue
                last_px = float(ticker["data"][0]["last"])
                entry_px = float(position["entry"])
                size = float(position.get("size", 0))
                try:
                    ct_val = self.client.get_contract_val(inst_id)
                except Exception:
                    ct_val = 0.01
                notional = size * ct_val * entry_px
                if position["side"] == "long":
                    pnl = (last_px - entry_px) / entry_px * notional
                else:
                    pnl = (entry_px - last_px) / entry_px * notional
                total_upl += pnl
                details.append((inst_id, position["side"], pnl, last_px))
            except Exception:
                continue
        return total_upl, details

    def get_virtual_equity(self) -> float:
        """返回 dry-run 当前净值: 已实现余额 + 未实现盈亏。"""
        total_upl, _ = self.calculate_virtual_upl()
        return self._virtual_balance + total_upl

    def reset_virtual_account(self, initial_balance: float = 134.0):
        """彻底重置虚拟账户"""
        self._virtual_balance = initial_balance
        self._virtual_position = {}
        self._virtual_pnl_total = 0.0
        self._virtual_trade_count = 0
        self._virtual_ord_counter = 0
        self._save_virtual_state()
        logger.info(f"♻️ 虚拟账户已重置: 余额=${initial_balance}, 持仓已清空")
        return True

    def set_virtual_balance(self, amount: float):
        """手动设置虚拟余额"""
        self._virtual_balance = amount
        self._save_virtual_state()
        logger.info(f"💰 虚拟余额已手动调整为: ${amount}")
        return True

    REVIEW_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "复盘记录.md")

    def _log_review(self, direction: str, entry_price: float, close_price: float,
                    pnl_pct: float, reason: str):
        """自动写入复盘记录"""
        try:
            self._trade_counter += 1
            now = datetime.now().strftime("%H:%M")
            status = "✅" if pnl_pct > 0 else ("❌" if pnl_pct < 0 else "⚪")
            pnl_str = f"{pnl_pct:+.2f}%"

            # 提取简短原因
            short_reason = reason[:30] if reason else "—"

            line = (f"| {now} | **{direction}** | ${entry_price:,.2f} | "
                    f"${close_price:,.2f} | {pnl_str} {status} | {short_reason} |\n")

            # 追加到文件
            if os.path.exists(self.REVIEW_PATH):
                with open(self.REVIEW_PATH, "r", encoding="utf-8") as f:
                    content = f.read()

                # 找到当日交易汇总表格末尾插入
                marker = "*最后更新:"
                if marker in content:
                    content = content.replace(marker, line + "\n" + marker)
                else:
                    content += f"\n{line}"

                with open(self.REVIEW_PATH, "w", encoding="utf-8") as f:
                    f.write(content)

            logger.info(f"📝 复盘记录已更新: {direction} {pnl_str} | {short_reason}")
        except Exception as e:
            logger.warning(f"⚠️ 复盘记录写入失败: {e}")

    def _init_csv(self):
        if not os.path.exists(CSV_PATH):
            with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "time", "action", "inst_id", "side", "price",
                    "size", "ord_id", "sl_price", "tp_price",
                    "pnl_pct", "vol_ratio", "rsi", "atr", "status"
                ])

    def _log_trade_csv(self, action: TradeAction, ord_id: str, status: str,
                       pnl_pct: float = 0, vol_ratio: float = 0,
                       rsi: float = 0, atr: float = 0,
                       executed_size=None):
        try:
            size_to_log = executed_size if executed_size is not None else action.size
            with open(CSV_PATH, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    time.strftime("%Y-%m-%d %H:%M:%S"),
                    action.reason, action.inst_id,
                    action.signal.value, action.price, size_to_log,
                    ord_id, action.sl_price, action.tp_price,
                    f"{pnl_pct:.2f}", f"{vol_ratio:.2f}",
                    f"{rsi:.1f}", f"{atr:.6f}", status
                ])
        except Exception as e:
            logger.error(f"CSV 写入失败: {e}")

    # ─── 时间过滤 ───

    def _get_time_factor(self) -> float:
        """
        根据当前 UTC 时间返回仓位系数:
        - 活跃时段 (亚盘/美盘): 1.0
        - 过渡时段 (欧盘): 0.5
        - 不建议时段: 0.3
        """
        if not self.time_filter:
            return 1.0
        utc_hour = datetime.now(timezone.utc).hour
        for name, (start, end) in ACTIVE_HOURS.items():
            if start <= utc_hour < end:
                return 1.0
        if REDUCED_HOURS[0] <= utc_hour < REDUCED_HOURS[1]:
            return 0.5
        return 0.3

    def _get_time_label(self) -> str:
        utc_hour = datetime.now(timezone.utc).hour
        for name, (start, end) in ACTIVE_HOURS.items():
            if start <= utc_hour < end:
                return f"✅ {name.upper()}"
        if REDUCED_HOURS[0] <= utc_hour < REDUCED_HOURS[1]:
            return "⚠️ 过渡"
        return "🔇 低活跃"

    # ─── 金字塔加仓 ───

    def _calc_pyramid_size(self, action: TradeAction, current_price: float) -> str:
        """
        金字塔仓位:
        - 第1笔: 40% 仓位 (信号触发)
        - 第2笔: 30% 仓位 (价格朝有利方向走了)
        - 第3笔: 30% 仓位 (继续走)
        已满3笔 → 不再加仓
        """
        if not self.pyramid_enabled:
            return action.size

        inst = action.inst_id
        direction = "long" if action.signal == Signal.BUY else "short"

        # 平仓信号 → 清除金字塔状态
        if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT):
            self.pyramid_state.pop(inst, None)
            return action.size

        state = self.pyramid_state.get(inst)

        if state is None or state["direction"] != direction:
            # 新方向 → 第一笔 40%
            base_size = max(1, int(int(action.size) * 0.4))
            self.pyramid_state[inst] = {
                "direction": direction,
                "entries": [current_price],
                "base_full_size": int(action.size)
            }
            logger.info(f"🔺 金字塔 #{1} | {direction} | size={base_size} (40%)")
            return str(base_size)

        entries = state["entries"]
        if len(entries) >= 3:
            logger.info(f"🔺 金字塔已满 3 笔, 不再加仓")
            return "0"  # 不加仓

        # 检查是否朝有利方向移动
        last_entry = entries[-1]
        if direction == "long" and current_price <= last_entry:
            return "0"
        if direction == "short" and current_price >= last_entry:
            return "0"

        # 第2/3笔: 30% 仓位
        add_size = max(1, int(state["base_full_size"] * 0.3))
        entries.append(current_price)
        step = len(entries)
        logger.info(f"🔺 金字塔 #{step} | {direction} | size={add_size} (30%)")
        return str(add_size)

    # ─── 智能下单 ───

    def _smart_order(self, action: TradeAction, side: str,
                     current_balance: float, time_factor: float,
                     skip_pyramid: bool = False, skip_limit_timeout: bool = False):
        """智能下单: 限价单优先 + 时间系数调整"""
        
        # 时间系数调仓
        orig_size = int(action.size)
        adjusted_size = max(1, int(orig_size * time_factor))
        if time_factor < 1.0:
            logger.info(f"⏰ 时间系数={time_factor:.1f} | 仓位 {orig_size}→{adjusted_size}")
        
        # 金字塔加仓 (网格策略跳过)
        current_price = action.price if action.price > 0 else self.client.get_current_price(action.inst_id)
        if current_price and self.pyramid_enabled and not skip_pyramid:
            pyramid_size = self._calc_pyramid_size(action, current_price)
            if pyramid_size == "0":
                return  # 不需要加仓
            adjusted_size = max(1, int(int(pyramid_size) * time_factor))

        # 决定订单类型: 限价单优先 (maker 费率更低)
        if self.use_limit and action.price > 0:
            ord_type = "limit"
            px = str(action.price)
        elif self.use_limit and current_price:
            # 无指定价格 → 用当前价做限价单 (微调以确保成交)
            if side == "buy":
                px = str(round(current_price * 1.001, 6))  # 高0.1%确保成交
            else:
                px = str(round(current_price * 0.999, 6))  # 低0.1%确保成交
            ord_type = "limit"
        else:
            ord_type = "market"
            px = None

        # ─── 平仓前: 获取入场均价用于 PnL 计算 ───
        close_entry_price = 0.0
        if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT):
            if self.dry_run:
                # 🧪 Dry-run: 从虚拟持仓获取入场价
                vpos = self._virtual_position.get(action.inst_id)
                if vpos:
                    close_entry_price = vpos.get("entry", 0.0)
            else:
                try:
                    pos_result = self.client.get_positions(inst_id=action.inst_id)
                    if pos_result.get("code") == "0" and pos_result.get("data"):
                        for p in pos_result["data"]:
                            if float(p.get("pos", "0")) != 0:
                                close_entry_price = float(p.get("avgPx", "0"))
                                break
                except Exception:
                    pass

        # 平仓时使用 reduceOnly 防止反向开仓
        is_close = action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT)

        # 🧪 Dry-run: 拦截真实下单，虚拟执行
        if self.dry_run:
            result = self._dry_run_order(action, side, adjusted_size, current_price)
        else:
            result = self.client.place_order(
                inst_id=action.inst_id,
                td_mode="cross",
                side=side,
                ord_type=ord_type,
                sz=str(adjusted_size),
                px=px,
                reduce_only=is_close,
            )

        if result.get("code") == "0":
            ord_id = result["data"][0]["ordId"]
            fee_type = "maker" if ord_type == "limit" else "taker"
            logger.info(f"✅ {fee_type}单成功 | {action.reason} | ID:{ord_id} | sz={adjusted_size}")

            # ─── 组合风控同步 (v5.0) ───
            if not is_close:
                try:
                    ct_val = self.client.get_contract_val(action.inst_id)
                    size_usdt = float(adjusted_size) * ct_val * (current_price or action.price)
                    direction = "long" if side == "buy" else "short"
                    self.risk_manager.register_position(
                        inst_id=action.inst_id,
                        direction=direction,
                        size_usdt=size_usdt,
                        entry_price=(current_price or action.price),
                        stop_loss=action.sl_price
                    )
                except Exception as e:
                    logger.warning(f"⚠️ 组合风控持仓注册失败: {e}")
            else:
                self.risk_manager.unregister_position(action.inst_id)

            # 下止盈止损 (分两单: OKX conditional 不支持同时 SL+TP)
            if action.sl_price > 0:
                try:
                    close_side = "sell" if side == "buy" else "buy"
                    sl_result = self.client.place_stop_order(
                        inst_id=action.inst_id,
                        td_mode="cross",
                        side=close_side,
                        sz=str(adjusted_size),
                        sl_trigger_px=str(action.sl_price),
                    )
                    if sl_result.get("code") == "0":
                        logger.info(f"🛡️ 止损已挂 | SL={action.sl_price}")
                    else:
                        logger.warning(f"⚠️ 止损挂单失败: {sl_result.get('msg')}")
                except Exception as e:
                    logger.warning(f"⚠️ 止损挂单异常: {e}")

            if action.tp_price > 0:
                try:
                    close_side = "sell" if side == "buy" else "buy"
                    tp_result = self.client.place_stop_order(
                        inst_id=action.inst_id,
                        td_mode="cross",
                        side=close_side,
                        sz=str(adjusted_size),
                        tp_trigger_px=str(action.tp_price),
                    )
                    if tp_result.get("code") == "0":
                        logger.info(f"🎯 止盈已挂 | TP={action.tp_price}")
                    else:
                        logger.warning(f"⚠️ 止盈挂单失败: {tp_result.get('msg')}")
                except Exception as e:
                    logger.warning(f"⚠️ 止盈挂单异常: {e}")

            if self.notifier:
                try:
                    self.notifier.send_order_success(
                        action_reason=action.reason,
                        signal_type=action.signal.value,
                        inst_id=action.inst_id,
                        price=action.price or current_price,
                        size=adjusted_size,
                        ord_id=ord_id,
                        sl_price=action.sl_price,
                        tp_price=action.tp_price,
                        balance=current_balance if current_balance > 0 else 0
                    )
                except Exception as e:
                    logger.error(f"通知失败: {e}")

            # ─── 计算实际 PnL% (平仓交易) ───
            actual_pnl_pct = 0.0
            close_price = action.price or current_price or 0
            if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT) and close_entry_price > 0 and close_price > 0:
                if action.signal == Signal.CLOSE_LONG:
                    actual_pnl_pct = (close_price - close_entry_price) / close_entry_price * 100
                else:  # CLOSE_SHORT
                    actual_pnl_pct = (close_entry_price - close_price) / close_entry_price * 100
                logger.info(f"💰 平仓盈亏: {actual_pnl_pct:+.2f}% | 入场={close_entry_price:.2f} → 平仓={close_price:.2f}")

                # 记录实际平仓亏损到风控 (以实际止损为准)
                if actual_pnl_pct < 0 and close_entry_price > 0:
                    loss_amount = abs(actual_pnl_pct / 100) * close_entry_price * float(action.size) * 0.1  # 合约面值
                    self.risk_manager.record_trade_loss(loss_amount)

            self._log_trade_csv(
                action,
                ord_id,
                "success",
                pnl_pct=actual_pnl_pct,
                executed_size=adjusted_size,
            )

            # ─── 自动复盘记录 (每笔平仓交易) ───
            if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT):
                direction = "做多" if action.signal == Signal.CLOSE_LONG else "做空"
                self._log_review(direction, close_entry_price, close_price, actual_pnl_pct, action.reason)

            if self.guard and not self.dry_run:
                self.guard.record_success()
            self.trade_history.append({
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "action": action.reason,
                "ordId": ord_id,
                "fee_type": fee_type,
                "pnl_pct": actual_pnl_pct,
                "status": "success"
            })

            # ─── 平仓后取消残留的止盈止损委托 ───
            if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT):
                try:
                    cancelled = self.client.cancel_algo_orders(action.inst_id)
                    if cancelled:
                        logger.info(f"🧹 平仓后已取消 {len(cancelled)} 个止盈止损委托 | {action.inst_id}")
                    else:
                        logger.info(f"✅ 平仓后无残留止盈止损委托 | {action.inst_id}")
                except Exception as e:
                    logger.warning(f"⚠️ 取消止盈止损委托异常: {e}")
            
            # ─── 限价单超时检测: 30s未成交→取消→转市价 ───
            # 网格策略跳过: 网格挂单应留在订单簿上等待自然成交
            # Dry-run: 跳过限价单超时检测
            if not self.dry_run and ord_type == "limit" and self.limit_timeout > 0 and not skip_limit_timeout:
                time.sleep(self.limit_timeout)
                try:
                    order_info = self.client._request("GET", "/api/v5/trade/order", 
                                                      params={"instId": action.inst_id, "ordId": ord_id})
                    if order_info.get("code") == "0" and order_info.get("data"):
                        state = order_info["data"][0].get("state", "")
                        if state in ("live", "partially_filled"):
                            # 未完全成交 → 取消 → 转市价
                            logger.warning(f"⏰ 限价单 {self.limit_timeout}s 未成交 (state={state})")
                            self.client._request("POST", "/api/v5/trade/cancel-order",
                                                  body={"instId": action.inst_id, "ordId": ord_id})
                            logger.info(f"❌ 已取消限价单 {ord_id}")
                            
                            # 转市价单
                            mkt_result = self.client.place_order(
                                inst_id=action.inst_id,
                                td_mode="cross",
                                side=side,
                                ord_type="market",
                                sz=str(adjusted_size),
                                sl_trigger_px=str(action.sl_price) if action.sl_price > 0 else None,
                                tp_trigger_px=str(action.tp_price) if action.tp_price > 0 else None
                            )
                            if mkt_result.get("code") == "0":
                                new_id = mkt_result["data"][0]["ordId"]
                                logger.info(f"✅ 转市价单成功 | ID:{new_id}")
                                # 补记 CSV (防止平仓记录丢失)
                                self._log_trade_csv(
                                    action,
                                    new_id,
                                    "success",
                                    pnl_pct=actual_pnl_pct,
                                    executed_size=adjusted_size,
                                )
                            else:
                                logger.error(f"❌ 转市价单失败: {mkt_result.get('msg')}")
                        else:
                            logger.info(f"✅ 限价单已成交 (state={state})")
                except Exception as e:
                    logger.error(f"限价单状态检查失败: {e}")
        else:
            error_msg = result.get("msg", "未知错误")
            logger.error(f"❌ 下单失败 [{action.reason}]: {error_msg}")
            if self.notifier:
                try:
                    self.notifier.send_order_failed(action.reason, error_msg)
                except Exception:
                    pass
            self._log_trade_csv(action, "", "failed")
            if self.guard:
                self.guard.record_failure(error_msg)

    # ─── 主执行 ───

    def execute_actions(self, actions: List[TradeAction],
                        skip_pyramid: bool = False,
                        skip_limit_timeout: bool = False,
                        strategies: dict = None):
        if not actions:
            return

        if self.dry_run:
            current_balance = self._virtual_balance
        else:
            current_balance = self.client.get_usdt_balance()
        if not self.dry_run and not self.risk_manager.is_risk_ok(current_balance):
            # 风控拦截时也要释放执行锁
            self._release_action_locks(actions, strategies)
            return

        time_factor = self._get_time_factor()
        time_label = self._get_time_label()

        for action in actions:
            logger.info(f"执行: {action.reason} | 时段: {time_label}")

            side = ""
            if action.signal == Signal.BUY:
                side = "buy"
            elif action.signal == Signal.SELL:
                side = "sell"
            elif action.signal == Signal.CLOSE_LONG:
                side = "sell"
            elif action.signal == Signal.CLOSE_SHORT:
                side = "buy"

            if not side:
                continue

            self._smart_order(action, side, current_balance, time_factor,
                            skip_pyramid=skip_pyramid,
                            skip_limit_timeout=skip_limit_timeout)
            time.sleep(0.5)

        # 执行完毕 → 释放所有相关策略的执行锁
        self._release_action_locks(actions, strategies)

    def _release_action_locks(self, actions: List[TradeAction], strategies: dict = None):
        """释放策略执行锁 (防重复订单, 教训#43/#44)"""
        if not strategies:
            return
        for action in actions:
            inst = action.inst_id
            for stype, strat in strategies.get(inst, []):
                if hasattr(strat, 'reset_action_lock'):
                    strat.reset_action_lock()

    # ─── 交所端止损止盈检测 ───

    def check_algo_fills(self, instruments: list, strategies: dict = None):
        """
        检测 OKX 交所端触发的止损止盈委托，记录到 CSV 和日志。
        解决: 交所自动触发的 SL/TP 在机器人日志中不可见的问题。
        """
        if self.dry_run:
            return
        try:
            for inst in instruments:
                result = self.client._request('GET', '/api/v5/trade/orders-algo-history',
                    params={'instId': inst, 'ordType': 'conditional', 'state': 'effective', 'limit': '5'})
                if result.get('code') != '0' or not result.get('data'):
                    continue

                for algo in result['data']:
                    algo_id = algo.get('algoId', '')
                    if algo_id in self._seen_algo_ids:
                        continue

                    # 检查触发时间 (只处理最近 10 分钟内的)
                    trig_time = int(algo.get('triggerTime', '0'))
                    if trig_time == 0:
                        self._seen_algo_ids.add(algo_id)
                        continue
                    age_sec = (time.time() * 1000 - trig_time) / 1000
                    if age_sec > 600:  # 超过 10 分钟的跳过
                        self._seen_algo_ids.add(algo_id)
                        continue

                    sl_px = algo.get('slTriggerPx', '')
                    tp_px = algo.get('tpTriggerPx', '')
                    side = algo.get('side', '')
                    sz = algo.get('sz', '1')

                    if sl_px:
                        label = f"🚨 交所止损触发 | SL={sl_px}"
                        close_type = "止损"
                    elif tp_px:
                        label = f"🎯 交所止盈触发 | TP={tp_px}"
                        close_type = "止盈"
                    else:
                        self._seen_algo_ids.add(algo_id)
                        continue

                    # 查关联的实际成交单
                    fill_px = float(sl_px or tp_px)
                    ord_list = algo.get('ordIdList', [])
                    if ord_list:
                        try:
                            ord_info = self.client._request('GET', '/api/v5/trade/order',
                                params={'instId': inst, 'ordId': ord_list[0]})
                            if ord_info.get('data'):
                                fill_px = float(ord_info['data'][0].get('avgPx', fill_px))
                        except Exception:
                            pass

                    logger.warning(f"{label} | {inst} | side={side} | 成交={fill_px} | algoId={algo_id}")

                    # 记录到 CSV
                    try:
                        with open(CSV_PATH, 'a', newline='', encoding='utf-8') as f:
                            writer = csv.writer(f)
                            writer.writerow([
                                time.strftime('%Y-%m-%d %H:%M:%S'),
                                f"🚨 交所{close_type} @{fill_px:.2f}",
                                inst, side, fill_px, sz,
                                algo_id, sl_px or 0, tp_px or 0,
                                '0.00', '0.00', '0.0', '0.000000', 'algo_triggered'
                            ])
                    except Exception as e:
                        logger.error(f"CSV 写入失败: {e}")

                    # 通知
                    if self.notifier:
                        try:
                            self.notifier._send(
                                f"🚨 <b>交所{close_type}触发</b>\n"
                                f"━━━━━━━━━━━━━━\n"
                                f"💰 {inst}\n"
                                f"📍 {close_type}价: {sl_px or tp_px}\n"
                                f"📈 成交价: {fill_px:.2f}\n"
                                f"⏰ {time.strftime('%H:%M:%S')}"
                            )
                        except Exception:
                            pass

                    # 重置策略持仓状态
                    if strategies:
                        for stype, strat in strategies.get(inst, []):
                            if hasattr(strat, 'has_position'):
                                strat.has_position = False
                                strat.entry_direction = None
                                strat.entry_price = 0
                                strat.entry_size = '0'
                                if hasattr(strat, '_peak_pnl'):
                                    strat._peak_pnl = 0

                    self._seen_algo_ids.add(algo_id)

        except Exception as e:
            logger.warning(f"⚠️ 止损止盈检测异常: {e}")

    # ─── Dry-run 虚拟下单 ───

    def _dry_run_order(self, action: TradeAction, side: str,
                       adjusted_size: int, current_price: float) -> dict:
        """模拟下单: 不走 API，虚拟执行并记录"""
        self._virtual_ord_counter += 1
        ord_id = f"DRY-{self._virtual_ord_counter:06d}"
        fill_px = current_price or action.price
        inst = action.inst_id

        # 获取合约面值
        try:
            ct_val = self.client.get_contract_val(inst)
        except Exception:
            ct_val = 0.01  # ETH 默认

        notional = adjusted_size * ct_val * fill_px

        if action.signal in (Signal.CLOSE_LONG, Signal.CLOSE_SHORT):
            # 平仓: 计算虚拟盈亏
            vpos = self._virtual_position.pop(inst, None)
            if vpos:
                entry_px = vpos["entry"]
                if vpos["side"] == "long":
                    pnl = (fill_px - entry_px) / entry_px * notional
                else:
                    pnl = (entry_px - fill_px) / entry_px * notional
                self._virtual_balance += pnl
                self._virtual_pnl_total += pnl
                logger.info(f"🧪 DRY-RUN 平仓 | {inst} {vpos['side']} | "
                            f"入场={entry_px:.2f} → 平仓={fill_px:.2f} | "
                            f"PnL={pnl:+.4f}U | 虚拟余额=${self._virtual_balance:.2f}")
        else:
            # 开仓: 记录虚拟持仓
            vside = "long" if action.signal == Signal.BUY else "short"
            self._virtual_position[inst] = {
                "side": vside,
                "entry": fill_px,
                "size": adjusted_size,
                "sl_price": action.sl_price,
                "tp_price": action.tp_price,
            }
            logger.info(f"🧪 DRY-RUN 开仓 | {inst} {vside} @{fill_px:.2f} | "
                        f"sz={adjusted_size} | SL={action.sl_price} TP={action.tp_price} | "
                        f"虚拟余额=${self._virtual_balance:.2f}")

        self._virtual_trade_count += 1
        self._save_virtual_state()

        # 返回假的成功响应 (与 OKX API 格式一致)
        return {"code": "0", "data": [{"ordId": ord_id}]}

    def check_virtual_sl_tp(self, inst_id: str, current_price: float,
                             strategies: dict = None) -> bool:
        """🧪 Dry-run SL/TP 模拟: 检查虚拟持仓是否触及止损止盈"""
        if not self.dry_run or inst_id not in self._virtual_position:
            return False
        vpos = self._virtual_position[inst_id]
        sl = vpos.get("sl_price", 0)
        tp = vpos.get("tp_price", 0)
        side = vpos["side"]
        triggered = False
        reason = ""

        if side == "long":
            if sl > 0 and current_price <= sl:
                triggered = True
                reason = f"🚨 DRY-RUN 止损触发 SL={sl}"
            elif tp > 0 and current_price >= tp:
                triggered = True
                reason = f"🎯 DRY-RUN 止盈触发 TP={tp}"
        else:  # short
            if sl > 0 and current_price >= sl:
                triggered = True
                reason = f"🚨 DRY-RUN 止损触发 SL={sl}"
            elif tp > 0 and current_price <= tp:
                triggered = True
                reason = f"🎯 DRY-RUN 止盈触发 TP={tp}"

        if triggered:
            entry_px = vpos["entry"]
            size = vpos.get("size", 1)
            try:
                ct_val = self.client.get_contract_val(inst_id)
            except Exception:
                ct_val = 0.01
            notional = size * ct_val * entry_px
            if side == "long":
                pnl = (current_price - entry_px) / entry_px * notional
            else:
                pnl = (entry_px - current_price) / entry_px * notional

            self._virtual_position.pop(inst_id, None)
            self._virtual_balance += pnl
            self._virtual_pnl_total += pnl
            self._virtual_trade_count += 1
            self._save_virtual_state()

            logger.warning(f"🧪 {reason} | {inst_id} {side} | "
                           f"入场={entry_px:.2f} → 触发={current_price:.2f} | "
                           f"PnL={pnl:+.4f}U | 虚拟余额=${self._virtual_balance:.2f}")

            # 重置策略持仓状态
            if strategies:
                for stype, strat in strategies.get(inst_id, []):
                    if hasattr(strat, 'has_position'):
                        strat.has_position = False
                        strat.entry_direction = None
                        strat.entry_price = 0
                        strat.entry_size = '0'
                        if hasattr(strat, '_peak_pnl'):
                            strat._peak_pnl = 0

            # 通知
            if self.notifier:
                try:
                    pnl_emoji = "🟢" if pnl >= 0 else "🔴"
                    self.notifier._send(
                        f"{reason}\n"
                        f"━━━━━━━━━━━━━━\n"
                        f"💰 {inst_id} {side}\n"
                        f"📍 入场: {entry_px:.2f} → 触发: {current_price:.2f}\n"
                        f"{pnl_emoji} PnL: <b>{pnl:+.2f}U</b>\n"
                        f"⚖️ 余额: ${self._virtual_balance:.2f}"
                    )
                except Exception:
                    pass
            return True
        return False

    def get_virtual_status(self) -> dict:
        """获取 dry-run 虚拟账户状态"""
        return {
            "模式": "🧪 DRY-RUN 模拟",
            "虚拟余额": f"${self._virtual_balance:.2f}",
            "累计盈亏": f"${self._virtual_pnl_total:+.2f}",
            "交易次数": self._virtual_trade_count,
            "当前持仓": {k: f"{v['side']} @{v['entry']:.2f}" for k, v in self._virtual_position.items()} or "空仓",
        }

    def get_summary(self):
        maker_count = sum(1 for t in self.trade_history if t.get("fee_type") == "maker")
        taker_count = sum(1 for t in self.trade_history if t.get("fee_type") == "taker")
        summary = {
            "活跃订单": len(self.active_orders),
            "历史交易量": len(self.trade_history),
            "maker单": maker_count,
            "taker单": taker_count,
            "时间系数": self._get_time_factor(),
            "时段": self._get_time_label(),
            "金字塔状态": {k: len(v["entries"]) for k, v in self.pyramid_state.items()},
        }
        if self.dry_run:
            summary.update(self.get_virtual_status())
        return summary
