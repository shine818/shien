"""
看门狗自检脚本 — 由 Windows 任务计划程序调用
检查 watchdog.py 是否在运行, 如果不在就启动它

配置方法:
1. Win+R → taskschd.msc → 创建基本任务
2. 名称: OKX_Watchdog_Check
3. 触发器: 每天 + 每隔 10 分钟重复
4. 操作: 启动程序
   程序: pythonw
   参数: "C:\\Users\\15031\\Desktop\\shine\\shine\\okx\\check_watchdog.py"
   起始目录: C:\\Users\\15031\\Desktop\\shine\\shine\\okx
5. 勾选: "计算机启动时运行"
"""
import os
import sys
import json
import subprocess
import time
from datetime import datetime

OKX_DIR = os.path.dirname(os.path.abspath(__file__))
HEARTBEAT_FILE = os.path.join(OKX_DIR, "watchdog_heartbeat.txt")
WATCHDOG_SCRIPT = os.path.join(OKX_DIR, "watchdog.py")
CHECK_LOG = os.path.join(OKX_DIR, "check_log.txt")


def log(msg):
    with open(CHECK_LOG, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat()} | {msg}\n")


def is_watchdog_running():
    """检查 watchdog 心跳文件"""
    if not os.path.exists(HEARTBEAT_FILE):
        return False
    
    try:
        with open(HEARTBEAT_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # 检查心跳时间 (超过 2 分钟视为死亡)
        ts = data.get("timestamp", "")
        if not ts:
            return False
        
        heartbeat_time = datetime.fromisoformat(ts)
        age = (datetime.now() - heartbeat_time).total_seconds()
        
        if age > 120:  # 2 分钟没更新
            log(f"心跳过期: {age:.0f}s ago")
            return False
        
        if data.get("status") != "running":
            log(f"状态异常: {data.get('status')}")
            return False
        
        return True
    
    except Exception as e:
        log(f"心跳读取失败: {e}")
        return False


def start_watchdog():
    """启动 watchdog.py"""
    try:
        # 用 pythonw 在后台启动, 无窗口
        subprocess.Popen(
            [sys.executable, WATCHDOG_SCRIPT, "--strategy", "both"],
            cwd=OKX_DIR,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        log("✅ 看门狗已重新启动")
        return True
    except Exception as e:
        log(f"❌ 看门狗启动失败: {e}")
        return False


if __name__ == "__main__":
    if is_watchdog_running():
        # 一切正常, 静默退出
        pass
    else:
        log("⚠️ 看门狗未运行, 正在启动...")
        start_watchdog()
