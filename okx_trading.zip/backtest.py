"""
回测引擎 v2.0
拉取历史 K 线数据，模拟 MACross 策略的信号和盈亏
新增: 手续费+滑点模拟、分页拉取扩大数据量、参数网格搜索
"""
import json
import time
import os
import statistics
from datetime import datetime
from typing import List, Dict, Tuple, Optional

RESULT_DIR = os.path.dirname(os.path.abspath(__file__))


def fetch_extended_candles(client, inst_id: str, bar: str, total: int = 1000) -> List:
    """分页拉取更多历史K线"""
    all_candles = []
    after = ""
    pages = (total // 100) + 1

    for i in range(pages):
        params = {"instId": inst_id, "bar": bar, "limit": "100"}
        if after:
            params["after"] = after

        result = client._request("GET", "/api/v5/market/history-candles", params=params)
        if result.get("code") != "0" or not result.get("data"):
            break

        data = result["data"]
        if not data:
            break

        all_candles.extend(data)
        after = data[-1][0]  # 最后一根K线的时间戳
        time.sleep(0.2)  # 避免频率限制

        if len(data) < 100:
            break

    all_candles.reverse()
    return all_candles


def run_backtest(client, inst_id: str = "DOGE-USDT-SWAP", bar: str = "1H",
                 fast: int = 7, slow: int = 25,
                 atr_sl: float = 1.5, atr_tp: float = 4.5,
                 fee_rate: float = 0.0006, slippage: float = 0.0002,
                 extended: bool = True, verbose: bool = True) -> Optional[Dict]:
    """
    运行回测 v2.0
    新增参数:
        fee_rate: 手续费率 (默认 0.06% taker)
        slippage: 滑点 (默认 0.02%)
        extended: 是否分页拉取更多数据
        verbose: 是否打印详情
    """
    if verbose:
        print(f"\n{'=' * 55}")
        print(f"📈 回测引擎 v2.0 {'[扩展数据]' if extended else ''}")
        print(f"交易对: {inst_id} | K线: {bar} | EMA: {fast}/{slow}")
        print(f"止损: {atr_sl}×ATR | 止盈: {atr_tp}×ATR")
        print(f"手续费: {fee_rate * 100:.2f}% | 滑点: {slippage * 100:.2f}%")
        print(f"{'=' * 55}\n")

    # 获取数据
    if extended:
        candles = fetch_extended_candles(client, inst_id, bar, total=1000)
    else:
        result = client.get_candles(inst_id, bar=bar, limit="300")
        if result.get("code") != "0" or not result.get("data"):
            print("❌ 获取历史数据失败")
            return None
        candles = result["data"]
        candles.reverse()

    if not candles:
        print("❌ 无K线数据")
        return None

    closes = [float(c[4]) for c in candles]
    highs = [float(c[2]) for c in candles]
    lows = [float(c[3]) for c in candles]
    volumes = [float(c[5]) for c in candles]
    timestamps = [c[0] for c in candles]

    if verbose:
        print(f"📊 数据量: {len(closes)} 根 K 线")

    # EMA 计算
    def calc_ema(prices, period):
        if len(prices) < period:
            return []
        mult = 2 / (period + 1)
        ema = [sum(prices[:period]) / period]
        for i in range(period, len(prices)):
            ema.append((prices[i] - ema[-1]) * mult + ema[-1])
        return ema

    # ATR 计算
    def calc_atr(h, l, c, period=14):
        trs = []
        for i in range(1, len(h)):
            tr = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
            trs.append(tr)
        if len(trs) < period:
            return sum(trs) / len(trs) if trs else 0
        return sum(trs[-period:]) / period

    # RSI
    def calc_rsi(prices, period=14):
        if len(prices) < period + 1:
            return 50
        changes = [prices[i] - prices[i - 1] for i in range(len(prices) - period, len(prices))]
        gains = [c for c in changes if c > 0]
        losses = [-c for c in changes if c < 0]
        ag = sum(gains) / period if gains else 0
        al = sum(losses) / period if losses else 0.0001
        return 100 - 100 / (1 + ag / al)

    # ADX (行情类型识别)
    def calc_adx(h, l, c, period=14):
        """计算 ADX 判断趋势强度: >25 趋势, <20 震荡"""
        if len(h) < period * 2:
            return 25  # 默认中性
        plus_dm, minus_dm, tr_list = [], [], []
        for i in range(1, len(h)):
            up = h[i] - h[i - 1]
            down = l[i - 1] - l[i]
            plus_dm.append(up if up > down and up > 0 else 0)
            minus_dm.append(down if down > up and down > 0 else 0)
            tr = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
            tr_list.append(tr)
        if len(tr_list) < period:
            return 25
        atr = sum(tr_list[-period:]) / period
        if atr == 0:
            return 25
        plus_di = (sum(plus_dm[-period:]) / period) / atr * 100
        minus_di = (sum(minus_dm[-period:]) / period) / atr * 100
        dx = abs(plus_di - minus_di) / (plus_di + minus_di + 0.0001) * 100
        return dx

    # 模拟交易
    fast_ema = calc_ema(closes, fast)
    slow_ema = calc_ema(closes, slow)

    trades = []
    position = None
    entry_price = 0
    initial_capital = 1000.0  # 模拟资金
    capital = initial_capital

    start_idx = slow + 2

    for i in range(start_idx, len(closes)):
        fi = i - fast
        si = i - slow

        if fi < 1 or si < 1 or fi >= len(fast_ema) or si >= len(slow_ema):
            continue

        cf = fast_ema[fi]
        pf = fast_ema[fi - 1]
        cs = slow_ema[si]
        ps = slow_ema[si - 1]
        price = closes[i]

        rsi = calc_rsi(closes[:i + 1], 14)
        atr = calc_atr(highs[:i + 1], lows[:i + 1], closes[:i + 1], 14)

        golden = pf <= ps and cf > cs
        death = pf >= ps and cf < cs

        # 检查持仓止损止盈
        if position == "long" and atr > 0:
            sl = entry_price - atr * atr_sl
            tp = entry_price + atr * atr_tp
            if price <= sl:
                exit_price = price * (1 - slippage)  # 止损滑点
                fee_cost = exit_price * fee_rate * 2  # 开+平手续费
                pnl = (exit_price - entry_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200  # 净收益
                trades.append({"type": "止损平多", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
                position = None
            elif price >= tp:
                exit_price = price * (1 - slippage)
                pnl = (exit_price - entry_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200
                trades.append({"type": "止盈平多", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
                position = None

        elif position == "short" and atr > 0:
            sl = entry_price + atr * atr_sl
            tp = entry_price - atr * atr_tp
            if price >= sl:
                exit_price = price * (1 + slippage)
                pnl = (entry_price - exit_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200
                trades.append({"type": "止损平空", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
                position = None
            elif price <= tp:
                exit_price = price * (1 + slippage)
                pnl = (entry_price - exit_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200
                trades.append({"type": "止盈平空", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
                position = None

        # 新信号
        if golden and rsi > 50 and position != "long":
            if position == "short":
                exit_price = price * (1 + slippage)
                pnl = (entry_price - exit_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200
                trades.append({"type": "金叉平空", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
            entry_price = price * (1 + slippage)  # 追价滑点
            position = "long"

        elif death and rsi < 50 and position != "short":
            if position == "long":
                exit_price = price * (1 - slippage)
                pnl = (exit_price - entry_price) / entry_price * 100
                net_pnl = pnl - fee_rate * 200 - slippage * 200
                trades.append({"type": "死叉平多", "entry": entry_price, "exit": exit_price,
                               "pnl": pnl, "net_pnl": net_pnl, "fee_drag": fee_rate * 200})
            entry_price = price * (1 - slippage)
            position = "short"

    # 统计
    if not trades:
        if verbose:
            print("⚠️ 回测期间无交易信号")
        return None

    gross_pnls = [t["pnl"] for t in trades]
    net_pnls = [t["net_pnl"] for t in trades]
    wins = [p for p in net_pnls if p > 0]
    losses_list = [p for p in net_pnls if p < 0]

    total_gross = sum(gross_pnls)
    total_net = sum(net_pnls)
    total_fees = sum(t["fee_drag"] for t in trades)
    win_rate = len(wins) / len(net_pnls) * 100 if net_pnls else 0
    avg_win = sum(wins) / len(wins) if wins else 0
    avg_loss = sum(losses_list) / len(losses_list) if losses_list else 0

    # 最大回撤
    cumulative = 0
    peak = 0
    max_dd = 0
    for p in net_pnls:
        cumulative += p
        peak = max(peak, cumulative)
        dd = peak - cumulative
        max_dd = max(max_dd, dd)

    # 夏普比率
    if len(net_pnls) > 1 and statistics.stdev(net_pnls) > 0:
        sharpe = (sum(net_pnls) / len(net_pnls)) / statistics.stdev(net_pnls) * (252 ** 0.5)
    else:
        sharpe = 0

    # 最大连亏
    max_consec_loss = 0
    curr_streak = 0
    for p in net_pnls:
        if p < 0:
            curr_streak += 1
            max_consec_loss = max(max_consec_loss, curr_streak)
        else:
            curr_streak = 0

    # 盈亏比
    profit_factor = abs(avg_win / avg_loss) if avg_loss != 0 else float('inf')

    # ADX (趋势强度)
    adx = calc_adx(highs, lows, closes)

    if verbose:
        print(f"\n{'=' * 55}")
        print(f"📊 回测结果 {'v2.0 (含手续费+滑点)' }")
        print(f"{'=' * 55}")
        print(f"  总交易数:   {len(trades)}")
        print(f"  胜率:       {win_rate:.1f}%")
        print(f"  平均盈利:   {avg_win:.2f}%")
        print(f"  平均亏损:   {avg_loss:.2f}%")
        print(f"  盈亏比:     1:{profit_factor:.1f}" if avg_loss != 0 else "  盈亏比: ∞")
        print(f"  {'─' * 30}")
        print(f"  毛收益:     {total_gross:+.2f}%")
        print(f"  手续费损耗: -{total_fees:.2f}%")
        print(f"  净收益:     {total_net:+.2f}%")
        print(f"  {'─' * 30}")
        print(f"  最大回撤:   {max_dd:.2f}%")
        print(f"  最大连亏:   {max_consec_loss} 笔")
        print(f"  夏普比率:   {sharpe:.2f}")
        print(f"  ADX:        {adx:.1f} ({'趋势' if adx > 25 else '震荡'})")
        print(f"{'=' * 55}\n")

        print("交易明细:")
        for i, t in enumerate(trades):
            emoji = "✅" if t["net_pnl"] > 0 else "❌"
            print(f"  {emoji} #{i + 1} {t['type']} | 入={t['entry']:.4f} 出={t['exit']:.4f} | "
                  f"毛={t['pnl']:+.2f}% 净={t['net_pnl']:+.2f}%")

    result = {
        "trades": trades,
        "total_gross_pnl": total_gross,
        "total_net_pnl": total_net,
        "total_fee_drag": total_fees,
        "win_rate": win_rate,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "profit_factor": profit_factor,
        "max_drawdown": max_dd,
        "max_consecutive_loss": max_consec_loss,
        "sharpe": sharpe,
        "adx": adx,
        "params": {"fast": fast, "slow": slow, "atr_sl": atr_sl, "atr_tp": atr_tp},
        "timestamp": datetime.now().isoformat(),
        "inst_id": inst_id,
        "bar": bar,
        "data_count": len(closes),
    }

    # 保存结果到 JSON
    try:
        result_path = os.path.join(RESULT_DIR, "backtest_result.json")
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    return result


def grid_search(client, inst_id: str = "DOGE-USDT-SWAP", bar: str = "1H",
                fast_range: Tuple = (5, 10), slow_range: Tuple = (20, 35),
                atr_sl_range: Tuple = (1.0, 2.5), atr_tp_range: Tuple = (3.0, 6.0)):
    """
    参数网格搜索: 自动找最优 EMA + ATR 参数组合
    """
    print(f"\n{'=' * 55}")
    print(f"🔍 参数网格搜索")
    print(f"  快线范围: {fast_range} | 慢线范围: {slow_range}")
    print(f"  止损ATR: {atr_sl_range} | 止盈ATR: {atr_tp_range}")
    print(f"{'=' * 55}\n")

    results = []

    fast_values = range(fast_range[0], fast_range[1] + 1, 2)
    slow_values = range(slow_range[0], slow_range[1] + 1, 5)
    sl_values = [atr_sl_range[0] + i * 0.5 for i in range(int((atr_sl_range[1] - atr_sl_range[0]) / 0.5) + 1)]
    tp_values = [atr_tp_range[0] + i * 0.5 for i in range(int((atr_tp_range[1] - atr_tp_range[0]) / 0.5) + 1)]

    total = len(list(fast_values)) * len(list(slow_values)) * len(sl_values) * len(tp_values)
    print(f"共 {total} 种组合，开始搜索...\n")

    count = 0
    for fast in range(fast_range[0], fast_range[1] + 1, 2):
        for slow in range(slow_range[0], slow_range[1] + 1, 5):
            if fast >= slow:
                continue
            for sl in sl_values:
                for tp in tp_values:
                    count += 1
                    result = run_backtest(client, inst_id, bar, fast, slow, sl, tp,
                                          extended=True, verbose=False)
                    if result and result["total_net_pnl"] is not None:
                        results.append(result)
                        if count % 20 == 0:
                            print(f"  进度: {count}/{total}...")

    if not results:
        print("❌ 无有效回测结果")
        return None

    # 按夏普比率排序
    results.sort(key=lambda x: x["sharpe"], reverse=True)

    print(f"\n{'=' * 70}")
    print(f"🏆 Top 5 参数组合 (按夏普比率排序)")
    print(f"{'=' * 70}")
    print(f"{'排名':<4} {'EMA':<8} {'ATR_SL':<7} {'ATR_TP':<7} {'净收益':<9} {'胜率':<7} {'回撤':<7} {'夏普':<6}")
    print(f"{'─' * 70}")

    for i, r in enumerate(results[:5]):
        p = r["params"]
        print(f"  #{i + 1}  {p['fast']}/{p['slow']:<4} {p['atr_sl']:<7.1f} {p['atr_tp']:<7.1f} "
              f"{r['total_net_pnl']:+.2f}%   {r['win_rate']:.0f}%    {r['max_drawdown']:.1f}%  "
              f"{r['sharpe']:.2f}")

    best = results[0]
    print(f"\n🎯 推荐参数: EMA {best['params']['fast']}/{best['params']['slow']} | "
          f"SL {best['params']['atr_sl']}×ATR | TP {best['params']['atr_tp']}×ATR")

    # 保存结果到 JSON
    try:
        save_results = []
        for r in results[:10]:
            save_results.append({
                "params": r["params"],
                "total_net_pnl": r["total_net_pnl"],
                "win_rate": r["win_rate"],
                "max_drawdown": r["max_drawdown"],
                "sharpe": r["sharpe"],
                "profit_factor": r["profit_factor"],
                "trade_count": len(r["trades"]),
            })
        result_path = os.path.join(RESULT_DIR, "grid_search_result.json")
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "inst_id": inst_id,
                "bar": bar,
                "total_combinations": total,
                "valid_results": len(results),
                "top_results": save_results,
            }, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    return results[:5]


if __name__ == "__main__":
    from okx_client import OKXClient

    client = OKXClient()

    import sys
    if "--search" in sys.argv:
        grid_search(client)
    else:
        run_backtest(client, extended=True)
