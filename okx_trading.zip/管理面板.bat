@echo off
chcp 65001 >nul
title OKX Bot Manager
color 0A

:MENU
cls
echo.
echo  +======================================+
echo  :     OKX Trading Bot - Manager        :
echo  +======================================+
echo.
echo   [1] Check bot status
echo   [2] View recent logs (last 20 lines)
echo   [3] Check balance
echo   [4] Start bot
echo   [5] Stop bot
echo   [6] Restart bot
echo   [7] Git: view changes
echo   [8] Git: commit code
echo   [9] Git: rollback
echo   [0] Exit
echo.
set /p choice="Select: "

if "%choice%"=="1" goto STATUS
if "%choice%"=="2" goto LOGS
if "%choice%"=="3" goto BALANCE
if "%choice%"=="4" goto START
if "%choice%"=="5" goto STOP
if "%choice%"=="6" goto RESTART
if "%choice%"=="7" goto GIT_STATUS
if "%choice%"=="8" goto GIT_COMMIT
if "%choice%"=="9" goto GIT_ROLLBACK
if "%choice%"=="0" exit
goto MENU

:ENSURE_DEPS
echo.
echo Checking dependencies...
python -m pip install requests flask websocket-client -q 2>nul
if errorlevel 1 (
    echo [X] Dependency install failed
    pause
    exit /b 1
)
exit /b 0

:STATUS
echo.
echo ===== Bot Status =====
tasklist /fi "imagename eq python.exe" 2>nul | findstr /i python
if errorlevel 1 (
    echo [X] Bot is NOT running
) else (
    echo [OK] Bot is running
)
echo.
pause
goto MENU

:LOGS
echo.
echo ===== Recent Logs =====
powershell -Command "Get-Content '%~dp0trading.log' -Tail 20 -Encoding UTF8"
echo.
pause
goto MENU

:BALANCE
echo.
echo ===== Account Info =====
python "%~dp0check_pos.py"
echo.
pause
goto MENU

:START
echo.
echo Starting bot (watchdog + WebSocket mode)...
call :ENSURE_DEPS
if errorlevel 1 goto MENU
start "" cmd /c "cd /d %~dp0 && python watchdog.py --strategy both"
echo [OK] Started in new window
timeout /t 3 >nul
goto MENU

:STOP
echo.
echo Stopping bot...
powershell -Command "Get-Process python -ErrorAction SilentlyContinue | Where-Object { (Get-CimInstance Win32_Process -Filter """ProcessId=$($_.Id)""").CommandLine -match 'main.py|watchdog.py' } | Stop-Process -Force" 2>nul
echo [OK] Stopped
timeout /t 2 >nul
goto MENU

:RESTART
echo.
echo Restarting...
powershell -Command "Get-Process python -ErrorAction SilentlyContinue | Where-Object { (Get-CimInstance Win32_Process -Filter """ProcessId=$($_.Id)""").CommandLine -match 'main.py|watchdog.py' } | Stop-Process -Force" 2>nul
timeout /t 3 >nul
call :ENSURE_DEPS
if errorlevel 1 goto MENU
start "" cmd /c "cd /d %~dp0 && python watchdog.py --strategy both"
echo [OK] Restarted
timeout /t 3 >nul
goto MENU

:GIT_STATUS
echo.
echo ===== Git History (last 5) =====
git -C "%~dp0" log --oneline -5
echo.
echo ----- Changed Files -----
git -C "%~dp0" status --short
if errorlevel 0 (
    git -C "%~dp0" status --short | findstr /r "." >nul 2>nul
    if errorlevel 1 echo [Clean] No changes
)
echo.
pause
goto MENU

:GIT_COMMIT
echo.
set /p msg="Commit message: "
git -C "%~dp0" add -A
git -C "%~dp0" commit -m "%msg%"
echo.
echo [OK] Committed
pause
goto MENU

:GIT_ROLLBACK
echo.
echo WARNING: This will discard ALL uncommitted changes!
echo.
echo Recent versions:
git -C "%~dp0" log --oneline -5
echo.
set /p confirm="Rollback to last commit? (y/n): "
if /i "%confirm%"=="y" (
    git -C "%~dp0" checkout .
    echo [OK] Rolled back
) else (
    echo Cancelled
)
pause
goto MENU
