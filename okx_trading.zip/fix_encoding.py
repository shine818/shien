"""
Windows 控制台编码修复 · 全局模块
─────────────────────────────────
在所有入口脚本最顶部 import 此文件即可:
    import fix_encoding  # noqa: F401  (第一行)

修复内容:
1. 设置 PYTHONIOENCODING=utf-8 环境变量
2. 将 sys.stdout/stderr 替换为 UTF-8 编码的 TextIOWrapper
3. 配置 logging.StreamHandler 使用 UTF-8 以支持 emoji 字符

这样即使 Windows 控制台默认用 GBK/charmap, emoji (🟢🔴📡❌) 也不会崩溃
"""
import sys
import os
import io

# 设置环境变量 (影响子进程)
os.environ["PYTHONIOENCODING"] = "utf-8"
os.environ["PYTHONUTF8"] = "1"

# 替换 stdout/stderr 为 UTF-8 编码, errors='replace' 保证不崩溃
def _wrap_stream(stream):
    """将标准输出流包装为 UTF-8 编码"""
    if stream is None:
        return stream
    if hasattr(stream, 'buffer'):
        return io.TextIOWrapper(
            stream.buffer, encoding='utf-8', errors='replace',
            line_buffering=True
        )
    return stream

try:
    sys.stdout = _wrap_stream(sys.stdout)
    sys.stderr = _wrap_stream(sys.stderr)
except Exception:
    pass  # 某些环境下可能没有 buffer (如 IDLE)
