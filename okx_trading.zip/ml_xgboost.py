"""
XGBoost 交易信号预测器
用 OKX 历史 K 线数据训练，预测未来 1h 涨/跌方向

特征:
- RSI (14), MACD, ADX
- Bollinger Band 位置
- 成交量变化率
- 多空持仓比 (如可用)

输出: 0-100 的方向概率 (>60 做多, <40 做空, 40-60 不交易)
"""

import os
import time
import json
import pickle
import logging
import numpy as np

logger = logging.getLogger(__name__)

MODEL_PATH = os.path.join(os.path.dirname(__file__), "xgb_model.pkl")
FEATURES_META = os.path.join(os.path.dirname(__file__), "xgb_features.json")


class XGBSignalPredictor:
    """XGBoost 交易方向预测器"""

    def __init__(self, model_path: str = MODEL_PATH):
        self.model = None
        self.model_path = model_path
        self.feature_names = []
        self._load_model()

    def _load_model(self):
        """加载已训练的模型"""
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, "rb") as f:
                    data = pickle.load(f)
                    self.model = data["model"]
                    self.feature_names = data.get("features", [])
                    logger.info(f"🤖 XGBoost 模型已加载 ({len(self.feature_names)} 特征)")
            except Exception as e:
                logger.warning(f"⚠️ 加载模型失败: {e}")
        else:
            logger.info("🤖 XGBoost 模型未找到, 需要先训练 (python ml_xgboost.py train)")

    # ─── 特征工程 ───

    @staticmethod
    def _calc_rsi(closes, period=14):
        """RSI"""
        if len(closes) < period + 1:
            return 50.0
        deltas = [closes[i] - closes[i-1] for i in range(1, len(closes))]
        gains = [d if d > 0 else 0 for d in deltas]
        losses = [-d if d < 0 else 0 for d in deltas]

        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period

        for i in range(period, len(gains)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    @staticmethod
    def _calc_macd(closes, fast=12, slow=26, signal=9):
        """MACD (macd_line, signal_line, histogram)"""
        if len(closes) < slow + signal:
            return 0, 0, 0

        def ema(data, period):
            k = 2 / (period + 1)
            result = [data[0]]
            for v in data[1:]:
                result.append(result[-1] * (1 - k) + v * k)
            return result

        ema_fast = ema(closes, fast)
        ema_slow = ema(closes, slow)
        macd_line = [f - s for f, s in zip(ema_fast, ema_slow)]
        signal_line = ema(macd_line, signal)
        hist = macd_line[-1] - signal_line[-1]
        return macd_line[-1], signal_line[-1], hist

    @staticmethod
    def _calc_adx(highs, lows, closes, period=14):
        """ADX"""
        if len(highs) < period * 2:
            return 25.0
        tr_list, plus_dm, minus_dm = [], [], []
        for i in range(1, len(highs)):
            h, l, pc = highs[i], lows[i], closes[i-1]
            tr_list.append(max(h - l, abs(h - pc), abs(l - pc)))
            up = highs[i] - highs[i-1]
            dn = lows[i-1] - lows[i]
            plus_dm.append(up if up > dn and up > 0 else 0)
            minus_dm.append(dn if dn > up and dn > 0 else 0)

        def ema(data, p):
            result = [sum(data[:p]) / p]
            k = 1 / p
            for v in data[p:]:
                result.append(result[-1] * (1 - k) + v * k)
            return result

        atr = ema(tr_list, period)
        plus_di = [100*p/a if a > 0 else 0 for p, a in zip(ema(plus_dm, period), atr)]
        minus_di = [100*m/a if a > 0 else 0 for m, a in zip(ema(minus_dm, period), atr)]
        dx = [100*abs(p-m)/(p+m) if (p+m) > 0 else 0 for p, m in zip(plus_di, minus_di)]
        if len(dx) < period:
            return 25.0
        adx_vals = ema(dx, period)
        return adx_vals[-1]

    @staticmethod
    def _calc_bb_position(closes, period=20, num_std=2.0):
        """价格在 Bollinger Band 中的位置 (0=下轨, 0.5=中轨, 1=上轨)"""
        if len(closes) < period:
            return 0.5
        recent = closes[-period:]
        sma = sum(recent) / period
        std = (sum((p - sma) ** 2 for p in recent) / period) ** 0.5
        if std == 0:
            return 0.5
        upper = sma + num_std * std
        lower = sma - num_std * std
        pos = (closes[-1] - lower) / (upper - lower) if upper != lower else 0.5
        return max(0, min(1, pos))

    def extract_features(self, highs, lows, closes, volumes):
        """从 K 线数据提取特征向量"""
        if len(closes) < 30:
            return None

        rsi = self._calc_rsi(closes)
        macd, macd_sig, macd_hist = self._calc_macd(closes)
        adx = self._calc_adx(highs, lows, closes)
        bb_pos = self._calc_bb_position(closes)

        # 价格变化率
        pct_1h = (closes[-1] - closes[-2]) / closes[-2] * 100 if len(closes) >= 2 else 0
        pct_4h = (closes[-1] - closes[-5]) / closes[-5] * 100 if len(closes) >= 5 else 0
        pct_12h = (closes[-1] - closes[-13]) / closes[-13] * 100 if len(closes) >= 13 else 0

        # 成交量变化
        avg_vol = sum(volumes[-10:]) / 10 if len(volumes) >= 10 else 1
        vol_ratio = volumes[-1] / avg_vol if avg_vol > 0 else 1

        # ATR (波动率)
        atr_list = []
        for i in range(max(1, len(highs)-14), len(highs)):
            tr = max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1]))
            atr_list.append(tr)
        atr = sum(atr_list) / len(atr_list) if atr_list else 0
        atr_pct = atr / closes[-1] * 100 if closes[-1] > 0 else 0

        # K线形态
        body = closes[-1] - closes[-2] if len(closes) >= 2 else 0
        upper_shadow = highs[-1] - max(closes[-1], closes[-2]) if len(closes) >= 2 else 0
        lower_shadow = min(closes[-1], closes[-2]) - lows[-1] if len(closes) >= 2 else 0

        features = {
            "rsi": rsi,
            "macd": macd,
            "macd_hist": macd_hist,
            "adx": adx,
            "bb_position": bb_pos,
            "pct_1h": pct_1h,
            "pct_4h": pct_4h,
            "pct_12h": pct_12h,
            "vol_ratio": vol_ratio,
            "atr_pct": atr_pct,
            "body_ratio": body / closes[-1] * 100 if closes[-1] > 0 else 0,
            "upper_shadow": upper_shadow / closes[-1] * 100 if closes[-1] > 0 else 0,
            "lower_shadow": lower_shadow / closes[-1] * 100 if closes[-1] > 0 else 0,
        }

        return features

    # ─── 预测 ───

    def predict(self, highs, lows, closes, volumes) -> float:
        """
        预测方向概率 (0-100)
        > 60: 做多信号
        < 40: 做空信号
        40-60: 不交易
        """
        if not self.model:
            return 50.0  # 无模型, 返回中性

        features = self.extract_features(highs, lows, closes, volumes)
        if not features:
            return 50.0

        # 按训练时的特征顺序排列
        X = np.array([[features.get(f, 0) for f in self.feature_names]])
        prob = self.model.predict_proba(X)[0]

        # prob[1] = 上涨概率
        return round(prob[1] * 100, 1) if len(prob) > 1 else 50.0

    # ─── 训练 ───

    def train(self, client, inst_id="DOGE-USDT-SWAP", bars="1H", limit=300):
        """
        用 OKX 历史数据训练 XGBoost 模型
        - 拉取最近 300 根 1H K 线
        - 标签: 未来 1h 涨 (1) / 跌 (0)
        """
        try:
            import xgboost as xgb
            from sklearn.model_selection import train_test_split
            from sklearn.metrics import accuracy_score, classification_report
        except ImportError:
            logger.error("❌ 缺少依赖: pip install xgboost scikit-learn")
            return

        logger.info(f"📥 拉取 {inst_id} {bars} K线数据 ({limit} 根)...")
        candles = client._request("GET", "/api/v5/market/candles",
                                   params={"instId": inst_id, "bar": bars, "limit": str(limit)})
        if not candles.get("data"):
            logger.error("❌ 获取K线失败")
            return

        # OKX 返回倒序, 翻转
        raw = list(reversed(candles["data"]))
        opens = [float(c[1]) for c in raw]
        highs = [float(c[2]) for c in raw]
        lows = [float(c[3]) for c in raw]
        closes = [float(c[4]) for c in raw]
        volumes = [float(c[5]) for c in raw]

        logger.info(f"📊 获取 {len(closes)} 根K线 | 价格范围: {min(closes):.6f} - {max(closes):.6f}")

        # 构建训练集
        X_list, y_list = [], []
        lookback = 30  # 需要 30 根 K 线做特征

        for i in range(lookback, len(closes) - 1):
            h = highs[:i+1]
            l = lows[:i+1]
            c = closes[:i+1]
            v = volumes[:i+1]
            features = self.extract_features(h, l, c, v)
            if features is None:
                continue

            # 标签: 下一根 K 线是涨还是跌
            future_return = (closes[i+1] - closes[i]) / closes[i]
            label = 1 if future_return > 0.001 else 0  # 涨 0.1% 以上算看涨

            X_list.append(features)
            y_list.append(label)

        if len(X_list) < 50:
            logger.error(f"❌ 数据不足 ({len(X_list)} 条), 需要至少 50 条")
            return

        # 转换
        self.feature_names = list(X_list[0].keys())
        X = np.array([[f[k] for k in self.feature_names] for f in X_list])
        y = np.array(y_list)

        logger.info(f"📊 训练集: {len(X)} 条 | 涨: {sum(y)} | 跌: {len(y)-sum(y)} | 比率: {sum(y)/len(y):.1%}")

        # 划分训练/测试
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

        # XGBoost
        model = xgb.XGBClassifier(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.1,
            min_child_weight=3,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=42,
            use_label_encoder=False,
        )

        model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)

        # 评估
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        logger.info(f"✅ 模型训练完成 | 测试准确率: {acc:.1%}")
        print(f"\n{'='*50}")
        print(f"  XGBoost 训练结果")
        print(f"{'='*50}")
        print(f"  训练集: {len(X_train)} | 测试集: {len(X_test)}")
        print(f"  准确率: {acc:.1%}")
        print(f"\n  特征重要性:")

        importances = model.feature_importances_
        sorted_idx = np.argsort(importances)[::-1]
        for idx in sorted_idx[:8]:
            print(f"    {self.feature_names[idx]:15s}: {importances[idx]:.3f}")

        print(f"\n{classification_report(y_test, y_pred, target_names=['跌', '涨'])}")

        # 保存
        self.model = model
        with open(self.model_path, "wb") as f:
            pickle.dump({"model": model, "features": self.feature_names}, f)

        # 保存特征元数据
        with open(FEATURES_META, "w") as f:
            json.dump({
                "features": self.feature_names,
                "accuracy": float(acc),
                "train_size": len(X_train),
                "test_size": len(X_test),
                "train_time": time.strftime("%Y-%m-%d %H:%M"),
                "inst_id": inst_id,
            }, f, indent=2)

        logger.info(f"💾 模型已保存: {self.model_path}")
        return acc


if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from okx_client import OKXClient

    if len(sys.argv) > 1 and sys.argv[1] == "train":
        client = OKXClient("config.json")
        predictor = XGBSignalPredictor()
        predictor.train(client, inst_id="DOGE-USDT-SWAP", bars="1H", limit=300)
    else:
        print("用法: python ml_xgboost.py train")
        print("  拉取 DOGE 300 根 1H K 线训练 XGBoost 模型")
